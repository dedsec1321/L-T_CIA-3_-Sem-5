import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IJobAlert extends Document {
  _id: mongoose.Types.ObjectId;
  candidateId: mongoose.Types.ObjectId;
  title: string;
  keywords: string[];
  skills: string[];
  location?: string;
  employmentType?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const JobAlertSchema = new Schema<IJobAlert>(
  {
    candidateId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Candidate reference is required'],
      index: true,
    },
    title: {
      type: String,
      required: [true, 'Alert title is required'],
      trim: true,
    },
    keywords: {
      type: [String],
      default: [],
    },
    skills: {
      type: [String],
      default: [],
    },
    location: {
      type: String,
      trim: true,
    },
    employmentType: {
      type: String,
      enum: ['Any', 'Full-time', 'Part-time', 'Contract', 'Remote', 'Internship'],
      default: 'Any',
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

export const JobAlert: Model<IJobAlert> =
  mongoose.models.JobAlert || mongoose.model<IJobAlert>('JobAlert', JobAlertSchema);
