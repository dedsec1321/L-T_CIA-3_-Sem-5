import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IJobPosting extends Document {
  _id: mongoose.Types.ObjectId;
  companyId: mongoose.Types.ObjectId;
  recruiterId: mongoose.Types.ObjectId;
  title: string;
  description: string;
  skills: string[];
  location: string;
  employmentType: 'Full-time' | 'Part-time' | 'Contract' | 'Remote' | 'Internship';
  experienceRequired: string; // e.g. "0-2 years", "3-5 years"
  experienceYearsMin: number;
  salaryRange: {
    min: number;
    max: number;
    currency: string;
  };
  status: 'Draft' | 'Published' | 'Closed';
  createdAt: Date;
  updatedAt: Date;
}

const JobPostingSchema = new Schema<IJobPosting>(
  {
    companyId: {
      type: Schema.Types.ObjectId,
      ref: 'Company',
      required: [true, 'Company reference is required'],
      index: true,
    },
    recruiterId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Recruiter user reference is required'],
      index: true,
    },
    title: {
      type: String,
      required: [true, 'Job title is required'],
      trim: true,
      maxlength: [200, 'Title cannot exceed 200 characters'],
      index: true,
    },
    description: {
      type: String,
      required: [true, 'Job description is required'],
      trim: true,
    },
    skills: {
      type: [String],
      required: [true, 'At least one skill is required'],
      validate: {
        validator: (v: string[]) => Array.isArray(v) && v.length > 0,
        message: 'Job must require at least one skill',
      },
      index: true,
    },
    location: {
      type: String,
      required: [true, 'Job location is required'],
      trim: true,
      index: true,
    },
    employmentType: {
      type: String,
      enum: ['Full-time', 'Part-time', 'Contract', 'Remote', 'Internship'],
      required: [true, 'Employment type is required'],
      default: 'Full-time',
      index: true,
    },
    experienceRequired: {
      type: String,
      required: [true, 'Experience required is required'],
      default: '1-3 years',
    },
    experienceYearsMin: {
      type: Number,
      default: 0,
      min: 0,
      index: true,
    },
    salaryRange: {
      min: {
        type: Number,
        required: [true, 'Minimum salary is required'],
        min: 0,
      },
      max: {
        type: Number,
        required: [true, 'Maximum salary is required'],
        min: 0,
      },
      currency: {
        type: String,
        default: 'USD',
      },
    },
    status: {
      type: String,
      enum: ['Draft', 'Published', 'Closed'],
      default: 'Draft',
      index: true,
    },
  },
  { timestamps: true }
);

// Compound text index for search
JobPostingSchema.index({
  title: 'text',
  description: 'text',
  skills: 'text',
  location: 'text',
});

export const JobPosting: Model<IJobPosting> =
  mongoose.models.JobPosting || mongoose.model<IJobPosting>('JobPosting', JobPostingSchema);
