import mongoose, { Schema, Document, Model } from 'mongoose';

export type PipelineStage = 'Applied' | 'Shortlisted' | 'Interview' | 'Offered' | 'Hired' | 'Rejected';

export interface IStageHistory {
  stage: PipelineStage;
  changedAt: Date;
  changedBy: mongoose.Types.ObjectId;
  note?: string;
}

export interface IApplication extends Document {
  _id: mongoose.Types.ObjectId;
  jobId: mongoose.Types.ObjectId;
  candidateId: mongoose.Types.ObjectId;
  recruiterId: mongoose.Types.ObjectId;
  stage: PipelineStage;
  status: 'Active' | 'Withdrawn';
  coverNote?: string;
  stageHistory: IStageHistory[];
  appliedAt: Date;
  createdAt: Date;
  updatedAt: Date;
}

const StageHistorySchema = new Schema<IStageHistory>(
  {
    stage: {
      type: String,
      enum: ['Applied', 'Shortlisted', 'Interview', 'Offered', 'Hired', 'Rejected'],
      required: true,
    },
    changedAt: {
      type: Date,
      default: Date.now,
    },
    changedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    note: {
      type: String,
      trim: true,
    },
  },
  { _id: false }
);

const ApplicationSchema = new Schema<IApplication>(
  {
    jobId: {
      type: Schema.Types.ObjectId,
      ref: 'JobPosting',
      required: [true, 'Job reference is required'],
      index: true,
    },
    candidateId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Candidate reference is required'],
      index: true,
    },
    recruiterId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Recruiter reference is required'],
      index: true,
    },
    stage: {
      type: String,
      enum: ['Applied', 'Shortlisted', 'Interview', 'Offered', 'Hired', 'Rejected'],
      default: 'Applied',
      index: true,
    },
    status: {
      type: String,
      enum: ['Active', 'Withdrawn'],
      default: 'Active',
      index: true,
    },
    coverNote: {
      type: String,
      trim: true,
      maxlength: [1000, 'Cover note cannot exceed 1000 characters'],
    },
    stageHistory: {
      type: [StageHistorySchema],
      default: [],
    },
    appliedAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

// Enforce unique application per candidate per job
ApplicationSchema.index({ jobId: 1, candidateId: 1 }, { unique: true });

export const Application: Model<IApplication> =
  mongoose.models.Application || mongoose.model<IApplication>('Application', ApplicationSchema);
