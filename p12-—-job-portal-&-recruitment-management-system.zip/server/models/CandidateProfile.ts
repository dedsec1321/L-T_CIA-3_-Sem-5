import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IEducation {
  degree: string;
  institution: string;
  yearOfCompletion: number;
  fieldOfStudy?: string;
  grade?: string;
}

export interface ICandidateProfile extends Document {
  _id: mongoose.Types.ObjectId;
  userId: mongoose.Types.ObjectId;
  fullName: string;
  phone: string;
  location: string;
  skills: string[];
  education: IEducation[];
  experienceYears: number;
  experienceSummary: string;
  resumeSummary: string;
  resumeFileName?: string;
  portfolioUrl?: string;
  linkedinUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}

const EducationSchema = new Schema<IEducation>(
  {
    degree: { type: String, required: true, trim: true },
    institution: { type: String, required: true, trim: true },
    yearOfCompletion: { type: Number, required: true },
    fieldOfStudy: { type: String, trim: true },
    grade: { type: String, trim: true },
  },
  { _id: false }
);

const CandidateProfileSchema = new Schema<ICandidateProfile>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User reference is required'],
      unique: true,
      index: true,
    },
    fullName: {
      type: String,
      required: [true, 'Full name is required'],
      trim: true,
      maxlength: [100, 'Full name cannot exceed 100 characters'],
    },
    phone: {
      type: String,
      required: [true, 'Phone number is required'],
      trim: true,
    },
    location: {
      type: String,
      required: [true, 'Location is required'],
      trim: true,
    },
    skills: {
      type: [String],
      required: [true, 'At least one skill is required'],
      validate: {
        validator: (v: string[]) => Array.isArray(v) && v.length > 0,
        message: 'Please provide at least one skill',
      },
    },
    education: {
      type: [EducationSchema],
      default: [],
    },
    experienceYears: {
      type: Number,
      default: 0,
      min: [0, 'Experience years cannot be negative'],
    },
    experienceSummary: {
      type: String,
      required: [true, 'Experience summary is required'],
      trim: true,
    },
    resumeSummary: {
      type: String,
      required: [true, 'Resume summary is required'],
      trim: true,
    },
    resumeFileName: {
      type: String,
      default: 'Candidate_Resume_CV.pdf',
    },
    portfolioUrl: {
      type: String,
      trim: true,
    },
    linkedinUrl: {
      type: String,
      trim: true,
    },
  },
  { timestamps: true }
);

export const CandidateProfile: Model<ICandidateProfile> =
  mongoose.models.CandidateProfile ||
  mongoose.model<ICandidateProfile>('CandidateProfile', CandidateProfileSchema);
