import mongoose, { Schema, Document, Model } from 'mongoose';

export interface ICompany extends Document {
  _id: mongoose.Types.ObjectId;
  recruiterId: mongoose.Types.ObjectId;
  name: string;
  description: string;
  website?: string;
  location: string;
  industry: string;
  companySize?: string;
  logoUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}

const CompanySchema = new Schema<ICompany>(
  {
    recruiterId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Recruiter user ID is required'],
      index: true,
    },
    name: {
      type: String,
      required: [true, 'Company name is required'],
      trim: true,
      maxlength: [150, 'Company name cannot exceed 150 characters'],
      index: true,
    },
    description: {
      type: String,
      required: [true, 'Company description is required'],
      trim: true,
      maxlength: [3000, 'Description cannot exceed 3000 characters'],
    },
    website: {
      type: String,
      trim: true,
    },
    location: {
      type: String,
      required: [true, 'Location is required'],
      trim: true,
    },
    industry: {
      type: String,
      required: [true, 'Industry is required'],
      trim: true,
    },
    companySize: {
      type: String,
      enum: ['1-10', '11-50', '51-200', '201-500', '500+'],
      default: '11-50',
    },
    logoUrl: {
      type: String,
      trim: true,
    },
  },
  { timestamps: true }
);

export const Company: Model<ICompany> = mongoose.models.Company || mongoose.model<ICompany>('Company', CompanySchema);
