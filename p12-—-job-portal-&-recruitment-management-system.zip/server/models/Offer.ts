import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IOffer extends Document {
  _id: mongoose.Types.ObjectId;
  applicationId: mongoose.Types.ObjectId;
  jobId: mongoose.Types.ObjectId;
  candidateId: mongoose.Types.ObjectId;
  recruiterId: mongoose.Types.ObjectId;
  position: string;
  salary: number;
  currency: string;
  joiningDate: Date;
  offerStatus: 'Draft' | 'Sent' | 'Accepted' | 'Declined';
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

const OfferSchema = new Schema<IOffer>(
  {
    applicationId: {
      type: Schema.Types.ObjectId,
      ref: 'Application',
      required: [true, 'Application reference is required'],
      unique: true,
      index: true,
    },
    jobId: {
      type: Schema.Types.ObjectId,
      ref: 'JobPosting',
      required: [true, 'Job reference is required'],
      index: true,
    },
    candidateId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Candidate reference is required'],
      index: true,
    },
    recruiterId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Recruiter reference is required'],
      index: true,
    },
    position: {
      type: String,
      required: [true, 'Offer position title is required'],
      trim: true,
    },
    salary: {
      type: Number,
      required: [true, 'Offered salary amount is required'],
      min: [0, 'Salary must be positive'],
    },
    currency: {
      type: String,
      default: 'USD',
    },
    joiningDate: {
      type: Date,
      required: [true, 'Expected joining date is required'],
    },
    offerStatus: {
      type: String,
      enum: ['Draft', 'Sent', 'Accepted', 'Declined'],
      default: 'Draft',
      index: true,
    },
    notes: {
      type: String,
      trim: true,
    },
  },
  { timestamps: true }
);

export const Offer: Model<IOffer> =
  mongoose.models.Offer || mongoose.model<IOffer>('Offer', OfferSchema);
