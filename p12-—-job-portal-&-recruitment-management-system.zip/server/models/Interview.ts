import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IInterview extends Document {
  _id: mongoose.Types.ObjectId;
  applicationId: mongoose.Types.ObjectId;
  jobId: mongoose.Types.ObjectId;
  candidateId: mongoose.Types.ObjectId;
  recruiterId: mongoose.Types.ObjectId;
  scheduledAt: Date;
  mode: 'Online' | 'Offline';
  meetingLinkOrLocation: string;
  interviewer: string;
  feedback?: string;
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  createdAt: Date;
  updatedAt: Date;
}

const InterviewSchema = new Schema<IInterview>(
  {
    applicationId: {
      type: Schema.Types.ObjectId,
      ref: 'Application',
      required: [true, 'Application reference is required'],
      index: true,
    },
    jobId: {
      type: Schema.Types.ObjectId,
      ref: 'JobPosting',
      required: [true, 'Job reference is required'],
      index: true,
    },
    candidateId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Candidate reference is required'],
      index: true,
    },
    recruiterId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Recruiter reference is required'],
      index: true,
    },
    scheduledAt: {
      type: Date,
      required: [true, 'Interview schedule date and time is required'],
    },
    mode: {
      type: String,
      enum: ['Online', 'Offline'],
      default: 'Online',
    },
    meetingLinkOrLocation: {
      type: String,
      required: [true, 'Meeting link or physical location is required'],
      trim: true,
    },
    interviewer: {
      type: String,
      required: [true, 'Interviewer name/panel is required'],
      trim: true,
    },
    feedback: {
      type: String,
      trim: true,
    },
    status: {
      type: String,
      enum: ['Scheduled', 'Completed', 'Cancelled'],
      default: 'Scheduled',
      index: true,
    },
  },
  { timestamps: true }
);

export const Interview: Model<IInterview> =
  mongoose.models.Interview || mongoose.model<IInterview>('Interview', InterviewSchema);
