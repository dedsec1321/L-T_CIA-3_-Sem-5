import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';

let mongoMemoryServer: MongoMemoryServer | null = null;

export async function connectDB(): Promise<string> {
  // If already connected, return existing URI
  if (mongoose.connection.readyState >= 1) {
    return mongoose.connection.host;
  }

  const explicitUri = process.env.MONGODB_URI;

  if (explicitUri && !explicitUri.includes('<username>')) {
    try {
      console.log('Connecting to provided MongoDB URI...');
      await mongoose.connect(explicitUri, {
        serverSelectionTimeoutMS: 5000,
      });
      console.log('Connected successfully to MongoDB Atlas / Remote Cluster');
      return explicitUri;
    } catch (err: any) {
      console.warn(`Failed to connect to MONGODB_URI: ${err.message}. Falling back to embedded MongoDB Memory Server.`);
    }
  }

  // Fallback to embedded in-memory MongoDB
  try {
    console.log('Starting embedded MongoDB Server for seamless academic evaluation...');
    mongoMemoryServer = await MongoMemoryServer.create();
    const memoryUri = mongoMemoryServer.getUri();
    await mongoose.connect(memoryUri);
    console.log(`Connected to Embedded MongoDB at: ${memoryUri}`);
    return memoryUri;
  } catch (err: any) {
    console.error('Fatal: Could not initialize MongoDB instance:', err.message);
    throw err;
  }
}

export async function disconnectDB(): Promise<void> {
  if (mongoose.connection.readyState !== 0) {
    await mongoose.disconnect();
  }
  if (mongoMemoryServer) {
    await mongoMemoryServer.stop();
  }
}
