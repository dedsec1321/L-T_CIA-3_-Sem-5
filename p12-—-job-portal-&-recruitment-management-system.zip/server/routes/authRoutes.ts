import { Router } from 'express';
import { register, login, logout, getMe } from '../controllers/authController.js';
import { authenticate } from '../middleware/auth.js';
import { validateRequired } from '../middleware/validate.js';

const router = Router();

// Public routes
router.post('/register', validateRequired(['name', 'email', 'password']), register);
router.post('/login', validateRequired(['email', 'password']), login);
router.post('/logout', logout);

// Authenticated route
router.get('/me', authenticate, getMe);

export default router;
