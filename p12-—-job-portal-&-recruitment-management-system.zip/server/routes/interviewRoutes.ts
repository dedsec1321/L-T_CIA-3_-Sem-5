import { Router } from 'express';
import {
  scheduleInterview,
  updateInterview,
  updateInterviewStatus,
  getMyInterviews,
  getRecruiterInterviews,
} from '../controllers/interviewController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';
import { validateRequired, validateObjectId } from '../middleware/validate.js';

const router = Router();

// Candidate interviews
router.get('/my-interviews', authenticate, authorize('Candidate'), getMyInterviews);

// Recruiter interviews
router.get('/recruiter', authenticate, authorize('Recruiter', 'Admin'), getRecruiterInterviews);

router.post(
  '/',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateRequired(['applicationId', 'scheduledAt', 'meetingLinkOrLocation', 'interviewer']),
  scheduleInterview
);

router.put(
  '/:id',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateObjectId('id'),
  updateInterview
);

router.patch(
  '/:id/status',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateObjectId('id'),
  validateRequired(['status']),
  updateInterviewStatus
);

export default router;
