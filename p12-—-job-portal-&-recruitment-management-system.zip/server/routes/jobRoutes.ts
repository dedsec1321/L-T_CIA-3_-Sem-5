import { Router } from 'express';
import {
  createJob,
  getJobs,
  getJobById,
  getRecruiterJobs,
  updateJob,
  changeJobStatus,
  deleteJob,
} from '../controllers/jobController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';
import { validateRequired, validateObjectId } from '../middleware/validate.js';
import jwt from 'jsonwebtoken';
import { User } from '../models/User.js';

const router = Router();

// Optional auth helper to check if candidate is logged in on single job view
async function optionalAuth(req: any, res: any, next: any) {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      const JWT_SECRET = process.env.JWT_SECRET || 'academic_cia3_jwt_secret_key_2026_super_secure';
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      const user = await User.findById(decoded.id);
      if (user) req.user = user;
    }
  } catch {
    // Ignore error in optional auth
  }
  next();
}

// Public / Search routes
router.get('/', getJobs);

// Recruiter jobs route (must be before /:id)
router.get('/recruiter/my-jobs', authenticate, authorize('Recruiter', 'Admin'), getRecruiterJobs);

router.get('/:id', validateObjectId('id'), optionalAuth, getJobById);

// Recruiter job management
router.post(
  '/',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateRequired(['title', 'description', 'location', 'salaryMin', 'salaryMax']),
  createJob
);

router.put(
  '/:id',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateObjectId('id'),
  updateJob
);

router.patch(
  '/:id/status',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateObjectId('id'),
  validateRequired(['status']),
  changeJobStatus
);

router.delete(
  '/:id',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateObjectId('id'),
  deleteJob
);

export default router;
