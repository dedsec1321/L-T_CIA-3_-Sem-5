import { Router } from 'express';
import {
  applyForJob,
  getMyApplications,
  getApplicationById,
  getApplicantsForJob,
  getAllRecruiterApplicants,
  updateStage,
  withdrawApplication,
} from '../controllers/applicationController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';
import { validateRequired, validateObjectId } from '../middleware/validate.js';

const router = Router();

// Candidate routes
router.post(
  '/',
  authenticate,
  authorize('Candidate'),
  validateRequired(['jobId']),
  applyForJob
);

router.get('/my-applications', authenticate, authorize('Candidate'), getMyApplications);

// Recruiter routes
router.get('/job/:jobId', authenticate, authorize('Recruiter', 'Admin'), validateObjectId('jobId'), getApplicantsForJob);
router.get('/recruiter/all', authenticate, authorize('Recruiter', 'Admin'), getAllRecruiterApplicants);

// Single application details
router.get('/:id', authenticate, validateObjectId('id'), getApplicationById);

// Pipeline Stage Transition (MODULE 7)
router.put(
  '/:id/stage',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateObjectId('id'),
  validateRequired(['stage']),
  updateStage
);

router.patch(
  '/:id/stage',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateObjectId('id'),
  validateRequired(['stage']),
  updateStage
);

// Candidate withdraw route
router.patch(
  '/:id/withdraw',
  authenticate,
  authorize('Candidate'),
  validateObjectId('id'),
  withdrawApplication
);

export default router;
