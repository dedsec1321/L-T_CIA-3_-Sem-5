import { Router } from 'express';
import {
  createOffer,
  getRecruiterOffers,
  getMyOffers,
  respondToOffer,
} from '../controllers/offerController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';
import { validateRequired, validateObjectId } from '../middleware/validate.js';

const router = Router();

// Candidate endpoints
router.get('/my-offers', authenticate, authorize('Candidate'), getMyOffers);

router.patch(
  '/:id/respond',
  authenticate,
  authorize('Candidate'),
  validateObjectId('id'),
  validateRequired(['action']),
  respondToOffer
);

// Recruiter endpoints
router.get('/recruiter', authenticate, authorize('Recruiter', 'Admin'), getRecruiterOffers);

router.post(
  '/',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateRequired(['applicationId', 'position', 'salary', 'joiningDate']),
  createOffer
);

export default router;
