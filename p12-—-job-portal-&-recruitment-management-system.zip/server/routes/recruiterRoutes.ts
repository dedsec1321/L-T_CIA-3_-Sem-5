import { Router } from 'express';
import { getRecruiterDashboard } from '../controllers/recruiterDashboardController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';

const router = Router();

router.get('/dashboard', authenticate, authorize('Recruiter', 'Admin'), getRecruiterDashboard);

export default router;
