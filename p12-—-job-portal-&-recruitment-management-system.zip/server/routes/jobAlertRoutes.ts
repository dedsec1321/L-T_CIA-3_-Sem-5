import { Router } from 'express';
import { createAlert, getMyAlerts, deleteAlert, getMatchingJobs } from '../controllers/jobAlertController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';
import { validateRequired, validateObjectId } from '../middleware/validate.js';

const router = Router();

router.use(authenticate, authorize('Candidate'));

router.get('/', getMyAlerts);
router.get('/matches', getMatchingJobs);
router.post('/', validateRequired(['title']), createAlert);
router.delete('/:id', validateObjectId('id'), deleteAlert);

export default router;
