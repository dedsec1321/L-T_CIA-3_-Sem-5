import { Router } from 'express';
import {
  getAdminAnalytics,
  getAllUsers,
  toggleUserStatus,
  getAllCompaniesAdmin,
  getAllJobsAdmin,
} from '../controllers/adminController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';
import { validateObjectId } from '../middleware/validate.js';

const router = Router();

// Protect all admin routes
router.use(authenticate, authorize('Admin'));

router.get('/analytics', getAdminAnalytics);
router.get('/users', getAllUsers);
router.patch('/users/:id/status', validateObjectId('id'), toggleUserStatus);
router.get('/companies', getAllCompaniesAdmin);
router.get('/jobs', getAllJobsAdmin);

export default router;
