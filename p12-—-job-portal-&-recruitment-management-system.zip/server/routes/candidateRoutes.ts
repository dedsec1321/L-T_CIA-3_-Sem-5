import { Router } from 'express';
import { getMyProfile, upsertProfile, getCandidateById } from '../controllers/candidateController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';
import { validateRequired, validateObjectId } from '../middleware/validate.js';

const router = Router();

// Candidate profile endpoints
router.get('/profile', authenticate, authorize('Candidate'), getMyProfile);

router.post(
  '/profile',
  authenticate,
  authorize('Candidate'),
  validateRequired(['fullName', 'phone', 'location', 'experienceSummary', 'resumeSummary']),
  upsertProfile
);

router.put(
  '/profile',
  authenticate,
  authorize('Candidate'),
  validateRequired(['fullName', 'phone', 'location', 'experienceSummary', 'resumeSummary']),
  upsertProfile
);

// Recruiter / Admin inspection endpoint
router.get('/profile/:id', authenticate, authorize('Recruiter', 'Admin'), validateObjectId('id'), getCandidateById);

export default router;
