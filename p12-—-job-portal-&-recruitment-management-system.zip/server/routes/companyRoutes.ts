import { Router } from 'express';
import {
  createCompany,
  getMyCompany,
  getCompanyById,
  updateCompany,
  deleteCompany,
} from '../controllers/companyController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';
import { validateRequired, validateObjectId } from '../middleware/validate.js';

const router = Router();

// Public / viewable routes
router.get('/:id', validateObjectId('id'), getCompanyById);

// Recruiter routes
router.post(
  '/',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateRequired(['name', 'description', 'location', 'industry']),
  createCompany
);

router.get('/recruiter/my-company', authenticate, authorize('Recruiter'), getMyCompany);

router.put(
  '/:id',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateObjectId('id'),
  updateCompany
);

router.delete(
  '/:id',
  authenticate,
  authorize('Recruiter', 'Admin'),
  validateObjectId('id'),
  deleteCompany
);

export default router;
