import { Router } from 'express';
import { saveJob, unsaveJob, getSavedJobs } from '../controllers/savedJobController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';
import { validateObjectId } from '../middleware/validate.js';

const router = Router();

router.use(authenticate, authorize('Candidate'));

router.get('/', getSavedJobs);

router.post('/', (req, res, next) => {
  saveJob(req, res, next);
});

router.post('/:jobId', validateObjectId('jobId'), (req, res, next) => {
  req.body.jobId = req.params.jobId;
  saveJob(req, res, next);
});

router.delete('/:jobId', validateObjectId('jobId'), unsaveJob);

export default router;
