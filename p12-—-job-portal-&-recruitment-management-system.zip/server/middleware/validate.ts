import { Request, Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import { AppError } from './errorHandler.js';

export function validateRequired(fields: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const missing: string[] = [];
    for (const field of fields) {
      const val = req.body[field];
      if (val === undefined || val === null || (typeof val === 'string' && val.trim() === '')) {
        missing.push(field);
      }
    }
    if (missing.length > 0) {
      return next(
        new AppError(
          `Validation failed: Missing required field(s): ${missing.join(', ')}`,
          400,
          'MISSING_REQUIRED_FIELDS'
        )
      );
    }
    next();
  };
}

export function validateObjectId(...paramNames: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    for (const param of paramNames) {
      const val = req.params[param] || req.body[param] || req.query[param];
      if (val && !mongoose.Types.ObjectId.isValid(val as string)) {
        return next(
          new AppError(
            `Validation failed: '${param}' is not a valid 24-character hexadecimal ObjectId`,
            400,
            'INVALID_OBJECT_ID'
          )
        );
      }
    }
    next();
  };
}
