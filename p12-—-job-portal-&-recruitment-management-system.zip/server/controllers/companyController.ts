import { Response, NextFunction } from 'express';
import { Company } from '../models/Company.js';
import { JobPosting } from '../models/JobPosting.js';
import { AuthRequest } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

export async function createCompany(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = req.user!._id;
    const { name, description, website, location, industry, companySize, logoUrl } = req.body;

    if (!name || !description || !location || !industry) {
      throw new AppError('Name, description, location, and industry are required', 400, 'MISSING_FIELDS');
    }

    const existing = await Company.findOne({ recruiterId });
    if (existing) {
      throw new AppError('You have already registered a company profile. You can update your existing company instead.', 409, 'COMPANY_EXISTS');
    }

    const company = await Company.create({
      recruiterId,
      name: name.trim(),
      description: description.trim(),
      website: website?.trim(),
      location: location.trim(),
      industry: industry.trim(),
      companySize: companySize || '11-50',
      logoUrl: logoUrl?.trim() || 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=128&auto=format&fit=crop&q=80',
    });

    res.status(201).json({
      success: true,
      message: 'Company profile created successfully',
      data: company,
    });
  } catch (error) {
    next(error);
  }
}

export async function getMyCompany(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = req.user!._id;
    const company = await Company.findOne({ recruiterId });

    if (!company) {
      res.status(200).json({
        success: true,
        message: 'No company profile found for this recruiter yet.',
        data: null,
      });
      return;
    }

    // Include total active job count for this company
    const jobCount = await JobPosting.countDocuments({ companyId: company._id });

    res.status(200).json({
      success: true,
      data: {
        ...company.toObject(),
        jobCount,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getCompanyById(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const company = await Company.findById(id).populate('recruiterId', 'name email');

    if (!company) {
      throw new AppError('Company not found', 404, 'COMPANY_NOT_FOUND');
    }

    const jobs = await JobPosting.find({ companyId: company._id, status: 'Published' });

    res.status(200).json({
      success: true,
      data: {
        company,
        jobs,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function updateCompany(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const company = await Company.findById(id);

    if (!company) {
      throw new AppError('Company not found', 404, 'COMPANY_NOT_FOUND');
    }

    // Ownership check: must be recruiter owner or Admin
    if (req.user!.role !== 'Admin' && company.recruiterId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only update your own company profile.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    const { name, description, website, location, industry, companySize, logoUrl } = req.body;

    if (name) company.name = name.trim();
    if (description) company.description = description.trim();
    if (website !== undefined) company.website = website.trim();
    if (location) company.location = location.trim();
    if (industry) company.industry = industry.trim();
    if (companySize) company.companySize = companySize;
    if (logoUrl !== undefined) company.logoUrl = logoUrl.trim();

    await company.save();

    res.status(200).json({
      success: true,
      message: 'Company profile updated successfully',
      data: company,
    });
  } catch (error) {
    next(error);
  }
}

export async function deleteCompany(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const company = await Company.findById(id);

    if (!company) {
      throw new AppError('Company not found', 404, 'COMPANY_NOT_FOUND');
    }

    if (req.user!.role !== 'Admin' && company.recruiterId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only delete your own company profile.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    await Company.findByIdAndDelete(id);

    res.status(200).json({
      success: true,
      message: 'Company profile deleted successfully',
    });
  } catch (error) {
    next(error);
  }
}
