import { Response, NextFunction } from 'express';
import { JobAlert } from '../models/JobAlert.js';
import { JobPosting } from '../models/JobPosting.js';
import { AuthRequest } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

export async function createAlert(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const { title, keywords, skills, location, employmentType } = req.body;

    if (!title) {
      throw new AppError('Alert title is required', 400, 'MISSING_TITLE');
    }

    const alert = await JobAlert.create({
      candidateId,
      title: title.trim(),
      keywords: Array.isArray(keywords) ? keywords : (keywords || '').split(',').map((k: string) => k.trim()).filter(Boolean),
      skills: Array.isArray(skills) ? skills : (skills || '').split(',').map((s: string) => s.trim()).filter(Boolean),
      location: location?.trim(),
      employmentType: employmentType || 'Any',
      isActive: true,
    });

    res.status(201).json({
      success: true,
      message: 'Job alert preference created successfully',
      data: alert,
    });
  } catch (error) {
    next(error);
  }
}

export async function getMyAlerts(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const alerts = await JobAlert.find({ candidateId }).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: alerts,
    });
  } catch (error) {
    next(error);
  }
}

export async function deleteAlert(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const { id } = req.params;

    const alert = await JobAlert.findOneAndDelete({ _id: id, candidateId });
    if (!alert) {
      throw new AppError('Job alert not found or unauthorized', 404, 'ALERT_NOT_FOUND');
    }

    res.status(200).json({
      success: true,
      message: 'Job alert deleted successfully',
    });
  } catch (error) {
    next(error);
  }
}

export async function getMatchingJobs(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const alerts = await JobAlert.find({ candidateId, isActive: true });

    if (alerts.length === 0) {
      res.status(200).json({
        success: true,
        message: 'No active job alerts configured yet',
        data: [],
      });
      return;
    }

    // Build matching criteria across all candidate alerts
    const orConditions: any[] = [];

    alerts.forEach((alert) => {
      const cond: any = {};
      if (alert.skills && alert.skills.length > 0) {
        cond.skills = { $in: alert.skills };
      }
      if (alert.location && alert.location.trim()) {
        cond.location = new RegExp(alert.location.trim(), 'i');
      }
      if (alert.employmentType && alert.employmentType !== 'Any') {
        cond.employmentType = alert.employmentType;
      }
      if (alert.keywords && alert.keywords.length > 0) {
        cond.$or = alert.keywords.map((kw) => ({
          title: new RegExp(kw, 'i'),
        }));
      }
      if (Object.keys(cond).length > 0) {
        orConditions.push(cond);
      }
    });

    const query: any = { status: 'Published' };
    if (orConditions.length > 0) {
      query.$or = orConditions;
    }

    const matchedJobs = await JobPosting.find(query)
      .populate('companyId', 'name logoUrl location')
      .sort({ createdAt: -1 })
      .limit(20);

    res.status(200).json({
      success: true,
      data: matchedJobs,
    });
  } catch (error) {
    next(error);
  }
}
