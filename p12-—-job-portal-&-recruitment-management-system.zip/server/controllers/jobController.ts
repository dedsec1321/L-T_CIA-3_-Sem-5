import { Response, NextFunction } from 'express';
import { JobPosting } from '../models/JobPosting.js';
import { Company } from '../models/Company.js';
import { Application } from '../models/Application.js';
import { AuthRequest } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

export async function createJob(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = req.user!._id;

    // Find recruiter's company
    const company = await Company.findOne({ recruiterId });
    if (!company) {
      throw new AppError(
        'You must create a Company profile before posting jobs. Please set up your company in Company Profile.',
        400,
        'COMPANY_REQUIRED'
      );
    }

    const {
      title,
      description,
      skills,
      location,
      employmentType,
      experienceRequired,
      experienceYearsMin,
      salaryMin,
      salaryMax,
      currency,
      status,
    } = req.body;

    if (!title || !description || !location || !salaryMin || !salaryMax) {
      throw new AppError('Title, description, location, and salary range are required', 400, 'MISSING_FIELDS');
    }

    let parsedSkills: string[] = [];
    if (Array.isArray(skills)) {
      parsedSkills = skills;
    } else if (typeof skills === 'string') {
      parsedSkills = skills.split(',').map((s) => s.trim()).filter(Boolean);
    }

    if (parsedSkills.length === 0) {
      throw new AppError('At least one required skill must be provided', 400, 'SKILLS_REQUIRED');
    }

    const job = await JobPosting.create({
      companyId: company._id,
      recruiterId,
      title: title.trim(),
      description: description.trim(),
      skills: parsedSkills,
      location: location.trim(),
      employmentType: employmentType || 'Full-time',
      experienceRequired: experienceRequired || '1-3 years',
      experienceYearsMin: Number(experienceYearsMin) || 0,
      salaryRange: {
        min: Number(salaryMin),
        max: Number(salaryMax),
        currency: currency || 'USD',
      },
      status: status || 'Draft',
    });

    res.status(201).json({
      success: true,
      message: 'Job posting created successfully',
      data: job,
    });
  } catch (error) {
    next(error);
  }
}

export async function getJobs(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const {
      search,
      title,
      skill,
      location,
      employmentType,
      minSalary,
      maxSalary,
      experience,
      sortBy = 'newest',
      page = 1,
      limit = 10,
    } = req.query;

    const query: any = { status: 'Published' };

    // Search text or title
    if (search) {
      const searchRegex = new RegExp(String(search).trim(), 'i');
      query.$or = [
        { title: searchRegex },
        { skills: searchRegex },
        { location: searchRegex },
        { description: searchRegex },
      ];
    } else {
      if (title) {
        query.title = new RegExp(String(title).trim(), 'i');
      }
      if (skill) {
        query.skills = { $in: [new RegExp(String(skill).trim(), 'i')] };
      }
    }

    if (location && location !== 'All') {
      query.location = new RegExp(String(location).trim(), 'i');
    }

    if (employmentType && employmentType !== 'All') {
      query.employmentType = employmentType;
    }

    if (minSalary) {
      query['salaryRange.max'] = { $gte: Number(minSalary) };
    }

    if (maxSalary) {
      query['salaryRange.min'] = { $lte: Number(maxSalary) };
    }

    if (experience !== undefined && experience !== '') {
      query.experienceYearsMin = { $lte: Number(experience) };
    }

    // Sorting
    let sortOptions: any = { createdAt: -1 };
    if (sortBy === 'salaryHigh') {
      sortOptions = { 'salaryRange.max': -1 };
    } else if (sortBy === 'salaryLow') {
      sortOptions = { 'salaryRange.min': 1 };
    } else if (sortBy === 'oldest') {
      sortOptions = { createdAt: 1 };
    }

    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.min(50, Math.max(1, Number(limit) || 10));
    const skip = (pageNum - 1) * limitNum;

    const [jobs, total] = await Promise.all([
      JobPosting.find(query)
        .populate('companyId', 'name location industry logoUrl website')
        .populate('recruiterId', 'name email')
        .sort(sortOptions)
        .skip(skip)
        .limit(limitNum),
      JobPosting.countDocuments(query),
    ]);

    res.status(200).json({
      success: true,
      data: jobs,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum) || 1,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getJobById(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const job = await JobPosting.findById(id)
      .populate('companyId')
      .populate('recruiterId', 'name email');

    if (!job) {
      throw new AppError('Job posting not found', 404, 'JOB_NOT_FOUND');
    }

    let hasApplied = false;
    let applicationDetails = null;

    if (req.user && req.user.role === 'Candidate') {
      const app = await Application.findOne({ jobId: job._id, candidateId: req.user._id });
      if (app) {
        hasApplied = true;
        applicationDetails = app;
      }
    }

    res.status(200).json({
      success: true,
      data: {
        ...job.toObject(),
        hasApplied,
        applicationDetails,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getRecruiterJobs(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = req.user!._id;
    const jobs = await JobPosting.find({ recruiterId })
      .populate('companyId', 'name location logoUrl')
      .sort({ createdAt: -1 });

    // Attach application counts per job for recruiter convenience
    const jobsWithStats = await Promise.all(
      jobs.map(async (job) => {
        const totalApplicants = await Application.countDocuments({ jobId: job._id });
        const shortlisted = await Application.countDocuments({ jobId: job._id, stage: 'Shortlisted' });
        const interviewed = await Application.countDocuments({ jobId: job._id, stage: 'Interview' });
        const hired = await Application.countDocuments({ jobId: job._id, stage: 'Hired' });
        return {
          ...job.toObject(),
          stats: {
            totalApplicants,
            shortlisted,
            interviewed,
            hired,
          },
        };
      })
    );

    res.status(200).json({
      success: true,
      data: jobsWithStats,
    });
  } catch (error) {
    next(error);
  }
}

export async function updateJob(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const job = await JobPosting.findById(id);

    if (!job) {
      throw new AppError('Job posting not found', 404, 'JOB_NOT_FOUND');
    }

    // Ownership check: must be the job's recruiter or Admin
    if (req.user!.role !== 'Admin' && job.recruiterId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only update jobs you created.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    const {
      title,
      description,
      skills,
      location,
      employmentType,
      experienceRequired,
      experienceYearsMin,
      salaryMin,
      salaryMax,
      currency,
      status,
    } = req.body;

    if (title) job.title = title.trim();
    if (description) job.description = description.trim();
    if (location) job.location = location.trim();
    if (employmentType) job.employmentType = employmentType;
    if (experienceRequired) job.experienceRequired = experienceRequired;
    if (experienceYearsMin !== undefined) job.experienceYearsMin = Number(experienceYearsMin);
    if (status) job.status = status;

    if (skills) {
      job.skills = Array.isArray(skills)
        ? skills
        : skills.split(',').map((s: string) => s.trim()).filter(Boolean);
    }

    if (salaryMin !== undefined || salaryMax !== undefined) {
      job.salaryRange = {
        min: salaryMin !== undefined ? Number(salaryMin) : job.salaryRange.min,
        max: salaryMax !== undefined ? Number(salaryMax) : job.salaryRange.max,
        currency: currency || job.salaryRange.currency || 'USD',
      };
    }

    await job.save();

    res.status(200).json({
      success: true,
      message: 'Job posting updated successfully',
      data: job,
    });
  } catch (error) {
    next(error);
  }
}

export async function changeJobStatus(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['Draft', 'Published', 'Closed'].includes(status)) {
      throw new AppError('Status must be Draft, Published, or Closed', 400, 'INVALID_STATUS');
    }

    const job = await JobPosting.findById(id);
    if (!job) {
      throw new AppError('Job posting not found', 404, 'JOB_NOT_FOUND');
    }

    if (req.user!.role !== 'Admin' && job.recruiterId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only change status for your own jobs.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    job.status = status;
    await job.save();

    res.status(200).json({
      success: true,
      message: `Job status updated to ${status}`,
      data: job,
    });
  } catch (error) {
    next(error);
  }
}

export async function deleteJob(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const job = await JobPosting.findById(id);

    if (!job) {
      throw new AppError('Job posting not found', 404, 'JOB_NOT_FOUND');
    }

    if (req.user!.role !== 'Admin' && job.recruiterId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only delete your own jobs.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    await JobPosting.findByIdAndDelete(id);

    res.status(200).json({
      success: true,
      message: 'Job posting deleted successfully',
    });
  } catch (error) {
    next(error);
  }
}
