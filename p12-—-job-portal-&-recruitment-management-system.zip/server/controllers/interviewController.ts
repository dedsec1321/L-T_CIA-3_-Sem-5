import { Response, NextFunction } from 'express';
import { Interview } from '../models/Interview.js';
import { Application } from '../models/Application.js';
import { AuthRequest } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

export async function scheduleInterview(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = req.user!._id;
    const { applicationId, scheduledAt, mode, meetingLinkOrLocation, interviewer, feedback } = req.body;

    if (!applicationId || !scheduledAt || !meetingLinkOrLocation || !interviewer) {
      throw new AppError(
        'applicationId, scheduledAt, meetingLinkOrLocation, and interviewer are required',
        400,
        'MISSING_FIELDS'
      );
    }

    const application = await Application.findById(applicationId);
    if (!application) {
      throw new AppError('Application not found', 404, 'APPLICATION_NOT_FOUND');
    }

    // Ownership check
    if (req.user!.role !== 'Admin' && application.recruiterId.toString() !== recruiterId.toString()) {
      throw new AppError('Forbidden: You can only schedule interviews for your own job applicants.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    const interviewDate = new Date(scheduledAt);
    if (isNaN(interviewDate.getTime())) {
      throw new AppError('Invalid scheduled date/time provided.', 400, 'INVALID_DATE');
    }

    const interview = await Interview.create({
      applicationId: application._id,
      jobId: application.jobId,
      candidateId: application.candidateId,
      recruiterId,
      scheduledAt: interviewDate,
      mode: mode || 'Online',
      meetingLinkOrLocation: meetingLinkOrLocation.trim(),
      interviewer: interviewer.trim(),
      feedback: feedback?.trim(),
      status: 'Scheduled',
    });

    // If application was in 'Shortlisted' or 'Applied', advance it to 'Interview' stage!
    if (application.stage === 'Shortlisted') {
      application.stage = 'Interview';
      application.stageHistory.push({
        stage: 'Interview',
        changedAt: new Date(),
        changedBy: recruiterId,
        note: `Interview scheduled on ${interviewDate.toLocaleDateString()}`,
      });
      await application.save();
    }

    res.status(201).json({
      success: true,
      message: 'Interview scheduled successfully',
      data: interview,
    });
  } catch (error) {
    next(error);
  }
}

export async function updateInterview(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const interview = await Interview.findById(id);

    if (!interview) {
      throw new AppError('Interview record not found', 404, 'INTERVIEW_NOT_FOUND');
    }

    if (req.user!.role !== 'Admin' && interview.recruiterId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only update interviews you scheduled.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    const { scheduledAt, mode, meetingLinkOrLocation, interviewer, feedback, status } = req.body;

    if (scheduledAt) {
      const parsedDate = new Date(scheduledAt);
      if (isNaN(parsedDate.getTime())) {
        throw new AppError('Invalid scheduled date/time.', 400, 'INVALID_DATE');
      }
      interview.scheduledAt = parsedDate;
    }
    if (mode) interview.mode = mode;
    if (meetingLinkOrLocation) interview.meetingLinkOrLocation = meetingLinkOrLocation.trim();
    if (interviewer) interview.interviewer = interviewer.trim();
    if (feedback !== undefined) interview.feedback = feedback.trim();
    if (status) interview.status = status;

    await interview.save();

    res.status(200).json({
      success: true,
      message: 'Interview details updated successfully',
      data: interview,
    });
  } catch (error) {
    next(error);
  }
}

export async function updateInterviewStatus(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const { status, feedback } = req.body;

    if (!['Scheduled', 'Completed', 'Cancelled'].includes(status)) {
      throw new AppError('Status must be Scheduled, Completed, or Cancelled', 400, 'INVALID_STATUS');
    }

    const interview = await Interview.findById(id);
    if (!interview) {
      throw new AppError('Interview record not found', 404, 'INTERVIEW_NOT_FOUND');
    }

    if (req.user!.role !== 'Admin' && interview.recruiterId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only update interviews you scheduled.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    interview.status = status;
    if (feedback !== undefined) {
      interview.feedback = feedback.trim();
    }
    await interview.save();

    res.status(200).json({
      success: true,
      message: `Interview status updated to ${status}`,
      data: interview,
    });
  } catch (error) {
    next(error);
  }
}

export async function getMyInterviews(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const interviews = await Interview.find({ candidateId })
      .populate('jobId', 'title companyId')
      .populate('recruiterId', 'name email')
      .populate({
        path: 'jobId',
        populate: { path: 'companyId', select: 'name logoUrl' },
      })
      .sort({ scheduledAt: 1 });

    res.status(200).json({
      success: true,
      data: interviews,
    });
  } catch (error) {
    next(error);
  }
}

export async function getRecruiterInterviews(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = req.user!._id;
    const interviews = await Interview.find({ recruiterId })
      .populate('jobId', 'title')
      .populate('candidateId', 'name email')
      .sort({ scheduledAt: 1 });

    res.status(200).json({
      success: true,
      data: interviews,
    });
  } catch (error) {
    next(error);
  }
}
