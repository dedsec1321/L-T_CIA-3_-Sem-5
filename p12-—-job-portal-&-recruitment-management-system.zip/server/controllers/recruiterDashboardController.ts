import { Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import { JobPosting } from '../models/JobPosting.js';
import { Application } from '../models/Application.js';
import { Interview } from '../models/Interview.js';
import { Offer } from '../models/Offer.js';
import { AuthRequest } from '../middleware/auth.js';

export async function getRecruiterDashboard(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = new mongoose.Types.ObjectId(req.user!._id);

    // 1. Job metrics
    const [totalJobs, publishedJobs, draftJobs, closedJobs] = await Promise.all([
      JobPosting.countDocuments({ recruiterId }),
      JobPosting.countDocuments({ recruiterId, status: 'Published' }),
      JobPosting.countDocuments({ recruiterId, status: 'Draft' }),
      JobPosting.countDocuments({ recruiterId, status: 'Closed' }),
    ]);

    // 2. Applications by stage aggregation pipeline
    const stageAggregation = await Application.aggregate([
      { $match: { recruiterId } },
      {
        $group: {
          _id: '$stage',
          count: { $sum: 1 },
        },
      },
    ]);

    const stageMap: Record<string, number> = {
      Applied: 0,
      Shortlisted: 0,
      Interview: 0,
      Offered: 0,
      Hired: 0,
      Rejected: 0,
    };

    let totalApplications = 0;
    stageAggregation.forEach((item) => {
      if (item._id && stageMap[item._id] !== undefined) {
        stageMap[item._id] = item.count;
      }
      totalApplications += item.count;
    });

    // 3. Interview metrics
    const [totalInterviews, upcomingInterviews, completedInterviews] = await Promise.all([
      Interview.countDocuments({ recruiterId }),
      Interview.countDocuments({ recruiterId, status: 'Scheduled', scheduledAt: { $gte: new Date() } }),
      Interview.countDocuments({ recruiterId, status: 'Completed' }),
    ]);

    // 4. Offer metrics
    const [totalOffers, acceptedOffers, pendingOffers] = await Promise.all([
      Offer.countDocuments({ recruiterId }),
      Offer.countDocuments({ recruiterId, offerStatus: 'Accepted' }),
      Offer.countDocuments({ recruiterId, offerStatus: 'Sent' }),
    ]);

    // 5. Recent 8 applications with populated candidate and job info
    const recentApplications = await Application.find({ recruiterId })
      .populate('jobId', 'title location')
      .populate('candidateId', 'name email')
      .sort({ createdAt: -1 })
      .limit(8);

    res.status(200).json({
      success: true,
      data: {
        summary: {
          totalJobs,
          publishedJobs,
          draftJobs,
          closedJobs,
          totalApplications,
          hires: stageMap.Hired,
          totalInterviews,
          upcomingInterviews,
          completedInterviews,
          totalOffers,
          acceptedOffers,
          pendingOffers,
        },
        applicationsByStage: [
          { stage: 'Applied', count: stageMap.Applied },
          { stage: 'Shortlisted', count: stageMap.Shortlisted },
          { stage: 'Interview', count: stageMap.Interview },
          { stage: 'Offered', count: stageMap.Offered },
          { stage: 'Hired', count: stageMap.Hired },
          { stage: 'Rejected', count: stageMap.Rejected },
        ],
        recentApplications,
      },
    });
  } catch (error) {
    next(error);
  }
}
