import { Response, NextFunction } from 'express';
import { Offer } from '../models/Offer.js';
import { Application } from '../models/Application.js';
import { AuthRequest } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

export async function createOffer(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = req.user!._id;
    const { applicationId, position, salary, currency, joiningDate, offerStatus = 'Sent', notes } = req.body;

    if (!applicationId || !position || !salary || !joiningDate) {
      throw new AppError('applicationId, position, salary, and joiningDate are required', 400, 'MISSING_FIELDS');
    }

    const application = await Application.findById(applicationId);
    if (!application) {
      throw new AppError('Application not found', 404, 'APPLICATION_NOT_FOUND');
    }

    // Ownership check
    if (req.user!.role !== 'Admin' && application.recruiterId.toString() !== recruiterId.toString()) {
      throw new AppError('Forbidden: You can only create offers for your own applicants.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    // Eligibility check: Application should be at least at 'Interview' stage or 'Offered'
    if (!['Interview', 'Offered', 'Shortlisted'].includes(application.stage)) {
      throw new AppError(
        `Cannot issue an offer to an application currently in '${application.stage}' stage. Candidate must reach interview stage first.`,
        409,
        'INELIGIBLE_FOR_OFFER'
      );
    }

    const existingOffer = await Offer.findOne({ applicationId });
    if (existingOffer) {
      throw new AppError(
        'An offer letter has already been issued for this application. Please update the existing offer instead.',
        409,
        'OFFER_EXISTS'
      );
    }

    const parsedDate = new Date(joiningDate);
    if (isNaN(parsedDate.getTime())) {
      throw new AppError('Invalid joining date specified', 400, 'INVALID_DATE');
    }

    const offer = await Offer.create({
      applicationId: application._id,
      jobId: application.jobId,
      candidateId: application.candidateId,
      recruiterId,
      position: position.trim(),
      salary: Number(salary),
      currency: currency || 'USD',
      joiningDate: parsedDate,
      offerStatus,
      notes: notes?.trim(),
    });

    // If offer status is Sent, update application stage to 'Offered'
    if (offerStatus === 'Sent' && application.stage !== 'Offered') {
      application.stage = 'Offered';
      application.stageHistory.push({
        stage: 'Offered',
        changedAt: new Date(),
        changedBy: recruiterId,
        note: `Formal job offer sent: ${position} at ${currency || 'USD'} ${salary}`,
      });
      await application.save();
    }

    res.status(201).json({
      success: true,
      message: 'Employment offer created and sent successfully',
      data: offer,
    });
  } catch (error) {
    next(error);
  }
}

export async function getRecruiterOffers(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = req.user!._id;
    const offers = await Offer.find({ recruiterId })
      .populate('jobId', 'title location companyId')
      .populate('candidateId', 'name email')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: offers,
    });
  } catch (error) {
    next(error);
  }
}

export async function getMyOffers(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const offers = await Offer.find({ candidateId, offerStatus: { $in: ['Sent', 'Accepted', 'Declined'] } })
      .populate('jobId', 'title location')
      .populate('recruiterId', 'name email')
      .populate({
        path: 'jobId',
        populate: { path: 'companyId', select: 'name logoUrl location' },
      })
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: offers,
    });
  } catch (error) {
    next(error);
  }
}

export async function respondToOffer(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const { id } = req.params;
    const { action } = req.body; // 'accept' | 'decline'

    if (!['accept', 'decline'].includes(action)) {
      throw new AppError("Action must be 'accept' or 'decline'", 400, 'INVALID_ACTION');
    }

    const offer = await Offer.findById(id);
    if (!offer) {
      throw new AppError('Offer not found', 404, 'OFFER_NOT_FOUND');
    }

    if (offer.candidateId.toString() !== candidateId.toString()) {
      throw new AppError('Forbidden: You can only respond to offers addressed to you.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    if (offer.offerStatus !== 'Sent') {
      throw new AppError(`This offer is already marked as ${offer.offerStatus}.`, 409, 'OFFER_ALREADY_RESOLVED');
    }

    const application = await Application.findById(offer.applicationId);

    if (action === 'accept') {
      offer.offerStatus = 'Accepted';
      await offer.save();

      // Progress application stage to 'Hired'
      if (application) {
        application.stage = 'Hired';
        application.stageHistory.push({
          stage: 'Hired',
          changedAt: new Date(),
          changedBy: candidateId,
          note: 'Offer accepted by candidate. Candidate officially hired!',
        });
        await application.save();
      }

      res.status(200).json({
        success: true,
        message: 'Congratulations! You have accepted the job offer. Status updated to Hired.',
        data: offer,
      });
    } else {
      offer.offerStatus = 'Declined';
      await offer.save();

      if (application) {
        application.stageHistory.push({
          stage: application.stage,
          changedAt: new Date(),
          changedBy: candidateId,
          note: 'Offer declined by candidate.',
        });
        await application.save();
      }

      res.status(200).json({
        success: true,
        message: 'You have declined this job offer.',
        data: offer,
      });
    }
  } catch (error) {
    next(error);
  }
}
