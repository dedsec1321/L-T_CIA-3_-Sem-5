import { Response, NextFunction } from 'express';
import { User } from '../models/User.js';
import { Company } from '../models/Company.js';
import { JobPosting } from '../models/JobPosting.js';
import { Application } from '../models/Application.js';
import { Interview } from '../models/Interview.js';
import { Offer } from '../models/Offer.js';
import { AuthRequest } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

export async function getAdminAnalytics(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    // 1. User aggregations by role
    const userRoleStats = await User.aggregate([
      {
        $group: {
          _id: '$role',
          count: { $sum: 1 },
        },
      },
    ]);

    let totalCandidates = 0;
    let totalRecruiters = 0;
    let totalAdmins = 0;

    userRoleStats.forEach((stat) => {
      if (stat._id === 'Candidate') totalCandidates = stat.count;
      if (stat._id === 'Recruiter') totalRecruiters = stat.count;
      if (stat._id === 'Admin') totalAdmins = stat.count;
    });

    // 2. Company & Job metrics
    const [totalCompanies, jobStats] = await Promise.all([
      Company.countDocuments(),
      JobPosting.aggregate([
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 },
          },
        },
      ]),
    ]);

    let totalJobs = 0;
    let publishedJobs = 0;
    let draftJobs = 0;
    let closedJobs = 0;

    jobStats.forEach((stat) => {
      totalJobs += stat.count;
      if (stat._id === 'Published') publishedJobs = stat.count;
      if (stat._id === 'Draft') draftJobs = stat.count;
      if (stat._id === 'Closed') closedJobs = stat.count;
    });

    // 3. Application Pipeline Aggregation
    const appStageStats = await Application.aggregate([
      {
        $group: {
          _id: '$stage',
          count: { $sum: 1 },
        },
      },
    ]);

    const stageCounts: Record<string, number> = {
      Applied: 0,
      Shortlisted: 0,
      Interview: 0,
      Offered: 0,
      Hired: 0,
      Rejected: 0,
    };

    let totalApplications = 0;
    appStageStats.forEach((stat) => {
      if (stat._id && stageCounts[stat._id] !== undefined) {
        stageCounts[stat._id] = stat.count;
      }
      totalApplications += stat.count;
    });

    // 4. Interviews and Offers
    const [totalInterviews, totalOffers, acceptedOffers] = await Promise.all([
      Interview.countDocuments(),
      Offer.countDocuments(),
      Offer.countDocuments({ offerStatus: 'Accepted' }),
    ]);

    // 5. Hiring Funnel Computation
    // Cumulative or stage-based funnel:
    // Applications submitted -> Shortlisted+ -> Interview+ -> Offered+ -> Hired
    const funnelApplied = totalApplications;
    const funnelShortlisted = stageCounts.Shortlisted + stageCounts.Interview + stageCounts.Offered + stageCounts.Hired;
    const funnelInterview = stageCounts.Interview + stageCounts.Offered + stageCounts.Hired;
    const funnelOffered = stageCounts.Offered + stageCounts.Hired;
    const funnelHired = stageCounts.Hired;

    const funnel = [
      {
        step: 'Applied',
        count: funnelApplied,
        percentageOfTotal: 100,
        conversionFromPrevious: 100,
      },
      {
        step: 'Shortlisted',
        count: funnelShortlisted,
        percentageOfTotal: funnelApplied > 0 ? Math.round((funnelShortlisted / funnelApplied) * 100) : 0,
        conversionFromPrevious: funnelApplied > 0 ? Math.round((funnelShortlisted / funnelApplied) * 100) : 0,
      },
      {
        step: 'Interviewed',
        count: funnelInterview,
        percentageOfTotal: funnelApplied > 0 ? Math.round((funnelInterview / funnelApplied) * 100) : 0,
        conversionFromPrevious: funnelShortlisted > 0 ? Math.round((funnelInterview / funnelShortlisted) * 100) : 0,
      },
      {
        step: 'Offered',
        count: funnelOffered,
        percentageOfTotal: funnelApplied > 0 ? Math.round((funnelOffered / funnelApplied) * 100) : 0,
        conversionFromPrevious: funnelInterview > 0 ? Math.round((funnelOffered / funnelInterview) * 100) : 0,
      },
      {
        step: 'Hired',
        count: funnelHired,
        percentageOfTotal: funnelApplied > 0 ? Math.round((funnelHired / funnelApplied) * 100) : 0,
        conversionFromPrevious: funnelOffered > 0 ? Math.round((funnelHired / funnelOffered) * 100) : 0,
      },
    ];

    res.status(200).json({
      success: true,
      data: {
        users: {
          total: totalCandidates + totalRecruiters + totalAdmins,
          candidates: totalCandidates,
          recruiters: totalRecruiters,
          admins: totalAdmins,
        },
        companies: {
          total: totalCompanies,
        },
        jobs: {
          total: totalJobs,
          published: publishedJobs,
          draft: draftJobs,
          closed: closedJobs,
        },
        applications: {
          total: totalApplications,
          byStage: stageCounts,
          hires: stageCounts.Hired,
          rejections: stageCounts.Rejected,
        },
        interviews: {
          total: totalInterviews,
        },
        offers: {
          total: totalOffers,
          accepted: acceptedOffers,
        },
        funnel,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getAllUsers(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { role, search, page = 1, limit = 20 } = req.query;
    const filter: any = {};

    if (role && role !== 'All') {
      filter.role = role;
    }

    if (search) {
      const searchRegex = new RegExp(String(search).trim(), 'i');
      filter.$or = [{ name: searchRegex }, { email: searchRegex }];
    }

    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.min(100, Math.max(1, Number(limit) || 20));
    const skip = (pageNum - 1) * limitNum;

    const [users, total] = await Promise.all([
      User.find(filter).select('-password').sort({ createdAt: -1 }).skip(skip).limit(limitNum),
      User.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: users,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum) || 1,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function toggleUserStatus(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const user = await User.findById(id);

    if (!user) {
      throw new AppError('User not found', 404, 'USER_NOT_FOUND');
    }

    // Do not allow deactivating self
    if (user._id.toString() === req.user!._id.toString()) {
      throw new AppError('Cannot toggle status of currently logged-in administrator account', 400, 'SELF_TOGGLE_PROHIBITED');
    }

    user.isActive = !user.isActive;
    await user.save();

    res.status(200).json({
      success: true,
      message: `User account has been ${user.isActive ? 'activated' : 'deactivated'}.`,
      data: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        isActive: user.isActive,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getAllCompaniesAdmin(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const companies = await Company.find().populate('recruiterId', 'name email').sort({ createdAt: -1 });

    const enriched = await Promise.all(
      companies.map(async (comp) => {
        const jobCount = await JobPosting.countDocuments({ companyId: comp._id });
        return {
          ...comp.toObject(),
          jobCount,
        };
      })
    );

    res.status(200).json({
      success: true,
      data: enriched,
    });
  } catch (error) {
    next(error);
  }
}

export async function getAllJobsAdmin(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const jobs = await JobPosting.find()
      .populate('companyId', 'name location logoUrl')
      .populate('recruiterId', 'name email')
      .sort({ createdAt: -1 });

    const enriched = await Promise.all(
      jobs.map(async (job) => {
        const applicantsCount = await Application.countDocuments({ jobId: job._id });
        return {
          ...job.toObject(),
          applicantsCount,
        };
      })
    );

    res.status(200).json({
      success: true,
      data: enriched,
    });
  } catch (error) {
    next(error);
  }
}
