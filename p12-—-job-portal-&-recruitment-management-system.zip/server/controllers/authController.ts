import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../models/User.js';
import { CandidateProfile } from '../models/CandidateProfile.js';
import { Company } from '../models/Company.js';
import { AppError } from '../middleware/errorHandler.js';
import { AuthRequest } from '../middleware/auth.js';

const JWT_SECRET = process.env.JWT_SECRET || 'academic_cia3_jwt_secret_key_2026_super_secure';

function generateToken(userId: string, email: string, role: string, name: string): string {
  return jwt.sign(
    { id: userId, email, role, name },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

export async function register(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      throw new AppError('Name, email, and password are required', 400, 'MISSING_FIELDS');
    }

    if (password.length < 6) {
      throw new AppError('Password must be at least 6 characters long', 400, 'WEAK_PASSWORD');
    }

    // Role validation: Public registration only allows Candidate or Recruiter. Admin is created via seed or admin invite.
    const chosenRole = role || 'Candidate';
    if (chosenRole === 'Admin') {
      throw new AppError('Administrator registration is restricted. Please use the seeded admin credentials or administrative invite.', 403, 'ADMIN_REGISTRATION_RESTRICTED');
    }
    if (!['Candidate', 'Recruiter'].includes(chosenRole)) {
      throw new AppError('Invalid role. Supported registration roles are: Candidate, Recruiter', 400, 'INVALID_ROLE');
    }

    const existingUser = await User.findOne({ email: email.toLowerCase().trim() });
    if (existingUser) {
      throw new AppError('An account with this email address already exists. Please login.', 409, 'EMAIL_EXISTS');
    }

    const newUser = await User.create({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password,
      role: chosenRole,
    });

    const token = generateToken(newUser._id.toString(), newUser.email, newUser.role, newUser.name);

    res.status(201).json({
      success: true,
      message: `${chosenRole} account registered successfully`,
      data: {
        token,
        user: {
          id: newUser._id,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function login(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      throw new AppError('Email and password are required', 400, 'MISSING_CREDENTIALS');
    }

    const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');
    if (!user) {
      throw new AppError('Invalid email or password. Please verify your credentials.', 401, 'INVALID_CREDENTIALS');
    }

    if (!user.isActive) {
      throw new AppError('Your account has been deactivated. Please contact support/administrator.', 403, 'ACCOUNT_DEACTIVATED');
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      throw new AppError('Invalid email or password. Please verify your credentials.', 401, 'INVALID_CREDENTIALS');
    }

    const token = generateToken(user._id.toString(), user.email, user.role, user.name);

    res.status(200).json({
      success: true,
      message: 'Logged in successfully',
      data: {
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function logout(req: Request, res: Response): Promise<void> {
  // Stateless JWT logout (client will clear token from storage)
  res.status(200).json({
    success: true,
    message: 'Logged out successfully',
  });
}

export async function getMe(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      throw new AppError('User not authenticated', 401, 'UNAUTHORIZED');
    }

    let extraData: any = {};
    if (req.user.role === 'Candidate') {
      const profile = await CandidateProfile.findOne({ userId: req.user._id });
      extraData.profile = profile;
    } else if (req.user.role === 'Recruiter') {
      const company = await Company.findOne({ recruiterId: req.user._id });
      extraData.company = company;
    }

    res.status(200).json({
      success: true,
      message: 'Current authenticated user profile fetched successfully',
      data: {
        user: {
          id: req.user._id,
          name: req.user.name,
          email: req.user.email,
          role: req.user.role,
          isActive: req.user.isActive,
          createdAt: req.user.createdAt,
        },
        ...extraData,
      },
    });
  } catch (error) {
    next(error);
  }
}
