import { Response, NextFunction } from 'express';
import { CandidateProfile } from '../models/CandidateProfile.js';
import { AuthRequest } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

export async function getMyProfile(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const userId = req.user!._id;
    const profile = await CandidateProfile.findOne({ userId });

    res.status(200).json({
      success: true,
      data: profile,
    });
  } catch (error) {
    next(error);
  }
}

export async function upsertProfile(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const userId = req.user!._id;
    const {
      fullName,
      phone,
      location,
      skills,
      education,
      experienceYears,
      experienceSummary,
      resumeSummary,
      resumeFileName,
      portfolioUrl,
      linkedinUrl,
    } = req.body;

    if (!fullName || !phone || !location || !experienceSummary || !resumeSummary) {
      throw new AppError(
        'Full name, phone, location, experience summary, and resume summary are required',
        400,
        'MISSING_FIELDS'
      );
    }

    let parsedSkills: string[] = [];
    if (Array.isArray(skills)) {
      parsedSkills = skills;
    } else if (typeof skills === 'string') {
      parsedSkills = skills.split(',').map((s) => s.trim()).filter(Boolean);
    }

    if (parsedSkills.length === 0) {
      throw new AppError('At least one skill is required in candidate profile', 400, 'SKILLS_REQUIRED');
    }

    const profileData = {
      userId,
      fullName: fullName.trim(),
      phone: phone.trim(),
      location: location.trim(),
      skills: parsedSkills,
      education: Array.isArray(education) ? education : [],
      experienceYears: Number(experienceYears) || 0,
      experienceSummary: experienceSummary.trim(),
      resumeSummary: resumeSummary.trim(),
      resumeFileName: resumeFileName?.trim() || 'Candidate_Resume.pdf',
      portfolioUrl: portfolioUrl?.trim(),
      linkedinUrl: linkedinUrl?.trim(),
    };

    const profile = await CandidateProfile.findOneAndUpdate(
      { userId },
      { $set: profileData },
      { new: true, upsert: true, runValidators: true }
    );

    res.status(200).json({
      success: true,
      message: 'Candidate profile saved successfully',
      data: profile,
    });
  } catch (error) {
    next(error);
  }
}

export async function getCandidateById(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    // id could be candidateProfile _id or userId
    let profile = await CandidateProfile.findById(id).populate('userId', 'name email');
    if (!profile) {
      profile = await CandidateProfile.findOne({ userId: id }).populate('userId', 'name email');
    }

    if (!profile) {
      throw new AppError('Candidate profile not found', 404, 'PROFILE_NOT_FOUND');
    }

    res.status(200).json({
      success: true,
      data: profile,
    });
  } catch (error) {
    next(error);
  }
}
