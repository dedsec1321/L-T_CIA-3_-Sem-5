import { Response, NextFunction } from 'express';
import { SavedJob } from '../models/SavedJob.js';
import { JobPosting } from '../models/JobPosting.js';
import { AuthRequest } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

export async function saveJob(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const { jobId } = req.body;

    if (!jobId) {
      throw new AppError('jobId is required', 400, 'MISSING_JOB_ID');
    }

    const job = await JobPosting.findById(jobId);
    if (!job) {
      throw new AppError('Job not found', 404, 'JOB_NOT_FOUND');
    }

    const existing = await SavedJob.findOne({ candidateId, jobId });
    if (existing) {
      throw new AppError('This job is already in your saved jobs list.', 409, 'JOB_ALREADY_SAVED');
    }

    const saved = await SavedJob.create({ candidateId, jobId });

    res.status(201).json({
      success: true,
      message: 'Job bookmarked/saved successfully',
      data: saved,
    });
  } catch (error) {
    next(error);
  }
}

export async function unsaveJob(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const { jobId } = req.params;

    const result = await SavedJob.findOneAndDelete({ candidateId, jobId });
    if (!result) {
      throw new AppError('Saved job record not found.', 404, 'SAVED_JOB_NOT_FOUND');
    }

    res.status(200).json({
      success: true,
      message: 'Job removed from saved jobs list',
    });
  } catch (error) {
    next(error);
  }
}

export async function getSavedJobs(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const savedJobs = await SavedJob.find({ candidateId })
      .populate({
        path: 'jobId',
        populate: { path: 'companyId', select: 'name logoUrl location industry' },
      })
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: savedJobs,
    });
  } catch (error) {
    next(error);
  }
}
