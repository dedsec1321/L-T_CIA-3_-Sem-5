import { Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import { Application, PipelineStage } from '../models/Application.js';
import { JobPosting } from '../models/JobPosting.js';
import { CandidateProfile } from '../models/CandidateProfile.js';
import { AuthRequest } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

// Server-side strict pipeline transition state machine
const ALLOWED_STAGE_TRANSITIONS: Record<PipelineStage, PipelineStage[]> = {
  Applied: ['Shortlisted', 'Rejected'],
  Shortlisted: ['Interview', 'Rejected'],
  Interview: ['Offered', 'Rejected'],
  Offered: ['Hired', 'Rejected'],
  Hired: [], // Terminal stage
  Rejected: [], // Terminal stage
};

export async function applyForJob(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const { jobId, coverNote } = req.body;

    if (!jobId) {
      throw new AppError('jobId is required to submit an application', 400, 'MISSING_JOB_ID');
    }

    // 1. Verify candidate has completed profile
    const profile = await CandidateProfile.findOne({ userId: candidateId });
    if (!profile) {
      throw new AppError(
        'Please complete your Candidate Profile (skills, experience, education, resume metadata) before applying for jobs.',
        400,
        'PROFILE_INCOMPLETE'
      );
    }

    // 2. Verify job exists and is Published
    const job = await JobPosting.findById(jobId);
    if (!job) {
      throw new AppError('The requested job posting does not exist.', 404, 'JOB_NOT_FOUND');
    }

    if (job.status !== 'Published') {
      throw new AppError(
        `Applications are closed for this job. Current status: ${job.status}`,
        400,
        'JOB_NOT_ACCEPTING_APPLICATIONS'
      );
    }

    // 3. Verify candidate hasn't already applied (check unique constraint)
    const existingApplication = await Application.findOne({ jobId: job._id, candidateId });
    if (existingApplication) {
      throw new AppError(
        'You have already submitted an application for this job posting. Duplicate applications are prohibited.',
        409,
        'DUPLICATE_APPLICATION'
      );
    }

    // 4. Create new application
    const application = await Application.create({
      jobId: job._id,
      candidateId,
      recruiterId: job.recruiterId,
      stage: 'Applied',
      status: 'Active',
      coverNote: coverNote?.trim(),
      stageHistory: [
        {
          stage: 'Applied',
          changedAt: new Date(),
          changedBy: candidateId,
          note: 'Application submitted by candidate.',
        },
      ],
      appliedAt: new Date(),
    });

    res.status(201).json({
      success: true,
      message: 'Application submitted successfully to pipeline',
      data: application,
    });
  } catch (error) {
    next(error);
  }
}

export async function getMyApplications(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const candidateId = req.user!._id;
    const applications = await Application.find({ candidateId })
      .populate({
        path: 'jobId',
        populate: { path: 'companyId', select: 'name logoUrl location website' },
      })
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: applications,
    });
  } catch (error) {
    next(error);
  }
}

export async function getApplicationById(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const application = await Application.findById(id)
      .populate('jobId')
      .populate('candidateId', 'name email')
      .populate('stageHistory.changedBy', 'name role');

    if (!application) {
      throw new AppError('Application not found', 404, 'APPLICATION_NOT_FOUND');
    }

    // Ownership check: Candidate owner OR Recruiter owner of job OR Admin
    const isCandidateOwner = application.candidateId._id.toString() === req.user!._id.toString();
    const isRecruiterOwner = application.recruiterId.toString() === req.user!._id.toString();
    const isAdmin = req.user!.role === 'Admin';

    if (!isCandidateOwner && !isRecruiterOwner && !isAdmin) {
      throw new AppError('Forbidden: You do not have permission to view this application.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    // Also populate candidate profile if viewed by recruiter or admin
    let candidateProfile = null;
    if (isRecruiterOwner || isAdmin) {
      candidateProfile = await CandidateProfile.findOne({ userId: application.candidateId._id });
    }

    res.status(200).json({
      success: true,
      data: {
        application,
        candidateProfile,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getApplicantsForJob(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { jobId } = req.params;
    const job = await JobPosting.findById(jobId);

    if (!job) {
      throw new AppError('Job posting not found', 404, 'JOB_NOT_FOUND');
    }

    if (req.user!.role !== 'Admin' && job.recruiterId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only view applicants for your own jobs.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    const { stage } = req.query;
    const filter: any = { jobId: job._id };
    if (stage && stage !== 'All') {
      filter.stage = stage;
    }

    const applications = await Application.find(filter)
      .populate('candidateId', 'name email')
      .sort({ createdAt: -1 });

    // Attach candidate profile preview to each application
    const enriched = await Promise.all(
      applications.map(async (app) => {
        const profile = await CandidateProfile.findOne({ userId: app.candidateId._id });
        return {
          ...app.toObject(),
          candidateProfile: profile,
        };
      })
    );

    res.status(200).json({
      success: true,
      data: enriched,
    });
  } catch (error) {
    next(error);
  }
}

export async function getAllRecruiterApplicants(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const recruiterId = req.user!._id;
    const { stage, jobId } = req.query;

    const filter: any = { recruiterId };
    if (stage && stage !== 'All') {
      filter.stage = stage;
    }
    if (jobId && jobId !== 'All') {
      filter.jobId = jobId;
    }

    const applications = await Application.find(filter)
      .populate('jobId', 'title location employmentType companyId')
      .populate('candidateId', 'name email')
      .sort({ createdAt: -1 });

    const enriched = await Promise.all(
      applications.map(async (app) => {
        const profile = await CandidateProfile.findOne({ userId: app.candidateId?._id });
        return {
          ...app.toObject(),
          candidateProfile: profile,
        };
      })
    );

    res.status(200).json({
      success: true,
      data: enriched,
    });
  } catch (error) {
    next(error);
  }
}

// MODULE 7: Applicant Pipeline Workflow Stage Transition
export async function updateStage(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const { stage, note } = req.body;

    if (!stage) {
      throw new AppError('Target stage is required', 400, 'STAGE_REQUIRED');
    }

    const application = await Application.findById(id);
    if (!application) {
      throw new AppError('Application not found', 404, 'APPLICATION_NOT_FOUND');
    }

    // Ownership check: Recruiter for this job OR Admin
    if (req.user!.role !== 'Admin' && application.recruiterId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only transition applicants for your own jobs.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    const currentStage = application.stage as PipelineStage;
    const targetStage = stage as PipelineStage;

    if (currentStage === targetStage) {
      res.status(200).json({
        success: true,
        message: `Application is already at stage '${targetStage}'`,
        data: application,
      });
      return;
    }

    // Server-side transition validation
    const allowedNextStages = ALLOWED_STAGE_TRANSITIONS[currentStage] || [];
    if (!allowedNextStages.includes(targetStage)) {
      throw new AppError(
        `Invalid pipeline transition: Cannot transition application from '${currentStage}' to '${targetStage}'. Valid transitions from '${currentStage}' are: [${allowedNextStages.join(', ') || 'None (Terminal stage)'}].`,
        409,
        'INVALID_PIPELINE_TRANSITION'
      );
    }

    // Update stage and push to history
    application.stage = targetStage;
    application.stageHistory.push({
      stage: targetStage,
      changedAt: new Date(),
      changedBy: req.user!._id,
      note: note?.trim() || `Moved to ${targetStage}`,
    });

    await application.save();

    res.status(200).json({
      success: true,
      message: `Applicant pipeline stage successfully updated to '${targetStage}'`,
      data: application,
    });
  } catch (error) {
    next(error);
  }
}

export async function withdrawApplication(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params;
    const application = await Application.findById(id);

    if (!application) {
      throw new AppError('Application not found', 404, 'APPLICATION_NOT_FOUND');
    }

    if (application.candidateId.toString() !== req.user!._id.toString()) {
      throw new AppError('Forbidden: You can only withdraw your own applications.', 403, 'FORBIDDEN_OWNERSHIP');
    }

    if (application.stage === 'Hired') {
      throw new AppError('Cannot withdraw an application that has already been Hired.', 400, 'CANNOT_WITHDRAW_HIRED');
    }

    application.status = 'Withdrawn';
    application.stageHistory.push({
      stage: application.stage,
      changedAt: new Date(),
      changedBy: req.user!._id,
      note: 'Application withdrawn by candidate.',
    });

    await application.save();

    res.status(200).json({
      success: true,
      message: 'Application withdrawn successfully',
      data: application,
    });
  } catch (error) {
    next(error);
  }
}
