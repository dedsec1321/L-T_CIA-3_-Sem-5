import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { User } from '../models/User.js';
import { Company } from '../models/Company.js';
import { JobPosting } from '../models/JobPosting.js';
import { CandidateProfile } from '../models/CandidateProfile.js';
import { Application } from '../models/Application.js';
import { Interview } from '../models/Interview.js';
import { SavedJob } from '../models/SavedJob.js';
import { JobAlert } from '../models/JobAlert.js';
import { Offer } from '../models/Offer.js';
import { connectDB } from '../config/db.js';

export async function seedDatabase(force = false): Promise<any> {
  const userCount = await User.countDocuments();
  if (userCount > 0 && !force) {
    console.log(`Database already has ${userCount} users. Skipping seed.`);
    return { skipped: true, userCount };
  }

  console.log('Seeding initial academic CIA-3 demo dataset...');

  // Clean existing collections if forcing seed
  if (force) {
    await Promise.all([
      User.deleteMany({}),
      Company.deleteMany({}),
      JobPosting.deleteMany({}),
      CandidateProfile.deleteMany({}),
      Application.deleteMany({}),
      Interview.deleteMany({}),
      SavedJob.deleteMany({}),
      JobAlert.deleteMany({}),
      Offer.deleteMany({}),
    ]);
  }

  // 1. Create Users (pass raw password so User.pre('save') hashes it once)
  const admin = await User.create({
    name: 'Dr. Eleanor Vance (Admin)',
    email: 'admin@jobportal.edu',
    password: 'Admin@123',
    role: 'Admin',
    isActive: true,
  });

  const recruiter1 = await User.create({
    name: 'Sarah Jenkins',
    email: 'sarah.recruiter@techcorp.com',
    password: 'Recruiter@123',
    role: 'Recruiter',
    isActive: true,
  });

  const recruiter2 = await User.create({
    name: 'David Thorne',
    email: 'david.hr@cloudscale.io',
    password: 'Recruiter@123',
    role: 'Recruiter',
    isActive: true,
  });

  const candidate1 = await User.create({
    name: 'Alex Rivera',
    email: 'alex.candidate@university.edu',
    password: 'Candidate@123',
    role: 'Candidate',
    isActive: true,
  });

  const candidate2 = await User.create({
    name: 'Priya Patel',
    email: 'priya.patel@engineering.edu',
    password: 'Candidate@123',
    role: 'Candidate',
    isActive: true,
  });

  const candidate3 = await User.create({
    name: 'Marcus Vance',
    email: 'marcus.vance@techgrads.org',
    password: 'Candidate@123',
    role: 'Candidate',
    isActive: true,
  });

  // 2. Create Companies
  const company1 = await Company.create({
    recruiterId: recruiter1._id,
    name: 'NexusTech Solutions',
    description:
      'NexusTech Solutions is an industry leader in enterprise cloud platforms, developer automation tooling, and scalable full-stack software development.',
    website: 'https://nexustech.example.com',
    location: 'San Francisco, CA (Hybrid / Remote)',
    industry: 'Software & Cloud Services',
    companySize: '201-500',
    logoUrl: 'https://images.unsplash.com/photo-1542744094-3a31f272c490?w=128&auto=format&fit=crop&q=80',
  });

  const company2 = await Company.create({
    recruiterId: recruiter2._id,
    name: 'CloudScale Systems',
    description:
      'CloudScale Systems builds mission-critical DevOps orchestration platforms, Kubernetes telemetry pipelines, and high-performance backend infrastructure.',
    website: 'https://cloudscale.example.com',
    location: 'Austin, TX (Remote Friendly)',
    industry: 'DevOps & Telemetry Infrastructure',
    companySize: '51-200',
    logoUrl: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=128&auto=format&fit=crop&q=80',
  });

  // 3. Create Job Postings
  const job1 = await JobPosting.create({
    companyId: company1._id,
    recruiterId: recruiter1._id,
    title: 'Full Stack MERN Developer',
    description:
      'We are looking for an ambitious Full Stack Developer proficient in React, Node.js, Express, MongoDB, and TypeScript. You will architect RESTful microservices, optimize database schemas, and develop responsive, component-driven client interfaces.',
    skills: ['React', 'Node.js', 'Express', 'MongoDB', 'TypeScript', 'REST APIs'],
    location: 'San Francisco, CA (Remote)',
    employmentType: 'Full-time',
    experienceRequired: '2-4 years',
    experienceYearsMin: 2,
    salaryRange: { min: 95000, max: 135000, currency: 'USD' },
    status: 'Published',
  });

  const job2 = await JobPosting.create({
    companyId: company1._id,
    recruiterId: recruiter1._id,
    title: 'Senior Frontend React Engineer',
    description:
      'Join our core UX design systems team. Responsible for crafting lightning-fast, accessible web dashboards with modern React 19, Tailwind CSS, motion animations, and state orchestration.',
    skills: ['React', 'Tailwind CSS', 'TypeScript', 'Next.js', 'State Management'],
    location: 'New York, NY (Hybrid)',
    employmentType: 'Full-time',
    experienceRequired: '3-5 years',
    experienceYearsMin: 3,
    salaryRange: { min: 110000, max: 150000, currency: 'USD' },
    status: 'Published',
  });

  const job3 = await JobPosting.create({
    companyId: company2._id,
    recruiterId: recruiter2._id,
    title: 'DevOps & Cloud Infrastructure Engineer',
    description:
      'Seeking a DevOps practitioner to maintain high-availability Kubernetes clusters, configure CI/CD delivery pipelines, and enforce zero-trust security postures across AWS and GCP.',
    skills: ['AWS', 'Docker', 'Kubernetes', 'CI/CD', 'Terraform', 'Linux'],
    location: 'Austin, TX (Remote)',
    employmentType: 'Full-time',
    experienceRequired: '2-5 years',
    experienceYearsMin: 2,
    salaryRange: { min: 105000, max: 145000, currency: 'USD' },
    status: 'Published',
  });

  const job4 = await JobPosting.create({
    companyId: company2._id,
    recruiterId: recruiter2._id,
    title: 'Data Platform Engineer',
    description:
      'Architect resilient data ingestion pipelines, manage MongoDB and PostgreSQL databases, and build real-time stream aggregation for analytical intelligence.',
    skills: ['Python', 'MongoDB', 'PostgreSQL', 'Kafka', 'ETL', 'Docker'],
    location: 'Seattle, WA',
    employmentType: 'Contract',
    experienceRequired: '1-3 years',
    experienceYearsMin: 1,
    salaryRange: { min: 85000, max: 120000, currency: 'USD' },
    status: 'Published',
  });

  const job5 = await JobPosting.create({
    companyId: company1._id,
    recruiterId: recruiter1._id,
    title: 'Junior Web Applications Intern (Draft)',
    description: 'Upcoming summer internship program focusing on modern web standards and API design.',
    skills: ['JavaScript', 'HTML5', 'CSS3', 'Git'],
    location: 'Remote',
    employmentType: 'Internship',
    experienceRequired: '0-1 years',
    experienceYearsMin: 0,
    salaryRange: { min: 45000, max: 60000, currency: 'USD' },
    status: 'Draft',
  });

  // 4. Create Candidate Profiles
  const profile1 = await CandidateProfile.create({
    userId: candidate1._id,
    fullName: 'Alex Rivera',
    phone: '+1 (415) 555-0192',
    location: 'San Francisco, CA',
    skills: ['React', 'Node.js', 'Express', 'MongoDB', 'TypeScript', 'Tailwind CSS', 'Docker'],
    education: [
      {
        degree: 'B.S. in Computer Science',
        institution: 'University of California, Berkeley',
        yearOfCompletion: 2023,
        fieldOfStudy: 'Software Systems & Distributed Computing',
        grade: '3.8 GPA (Dean’s Honors)',
      },
    ],
    experienceYears: 2,
    experienceSummary:
      'Full-stack software developer with 2+ years of hands-on experience developing modular microservices, RESTful APIs in Node/Express, and high-performance React frontends.',
    resumeSummary:
      'Proactive full-stack engineer with proven capability delivering end-to-end web applications. Skilled in MERN stack, database indexing, JWT security, and agile CI/CD delivery.',
    resumeFileName: 'Alex_Rivera_Software_Engineer_Resume.pdf',
    portfolioUrl: 'https://alexrivera-portfolio.dev',
    linkedinUrl: 'https://linkedin.com/in/alex-rivera-dev',
  });

  const profile2 = await CandidateProfile.create({
    userId: candidate2._id,
    fullName: 'Priya Patel',
    phone: '+1 (512) 555-7821',
    location: 'Austin, TX',
    skills: ['AWS', 'Docker', 'Kubernetes', 'Linux', 'Python', 'CI/CD', 'Terraform', 'Node.js'],
    education: [
      {
        degree: 'B.Tech in Information Technology',
        institution: 'Texas A&M University',
        yearOfCompletion: 2022,
        fieldOfStudy: 'Cloud Computing & Cyber Operations',
        grade: '3.9 GPA',
      },
    ],
    experienceYears: 3,
    experienceSummary:
      'DevOps specialist specializing in infrastructure-as-code, Docker containerization, Kubernetes cluster maintenance, and automated testing pipelines.',
    resumeSummary:
      'Cloud DevOps engineer passionate about site reliability, zero-downtime deployment, and scalable infrastructure automation.',
    resumeFileName: 'Priya_Patel_DevOps_Resume.pdf',
    portfolioUrl: 'https://priyapatel.cloud',
    linkedinUrl: 'https://linkedin.com/in/priya-patel-cloud',
  });

  const profile3 = await CandidateProfile.create({
    userId: candidate3._id,
    fullName: 'Marcus Vance',
    phone: '+1 (206) 555-4433',
    location: 'Seattle, WA',
    skills: ['React', 'TypeScript', 'Next.js', 'GraphQL', 'Tailwind CSS', 'Redux', 'Jest'],
    education: [
      {
        degree: 'B.S. in Software Engineering',
        institution: 'University of Washington',
        yearOfCompletion: 2024,
        fieldOfStudy: 'Human-Computer Interaction',
        grade: '3.7 GPA',
      },
    ],
    experienceYears: 1,
    experienceSummary:
      'Frontend-focused engineer passionate about accessible interfaces, component libraries, design systems, and state management.',
    resumeSummary: 'Frontend developer proficient in React 19, TypeScript, and modern UI engineering.',
    resumeFileName: 'Marcus_Vance_Frontend_Resume.pdf',
    portfolioUrl: 'https://marcusvance.me',
    linkedinUrl: 'https://linkedin.com/in/marcus-vance-ui',
  });

  // 5. Create Applications along different pipeline stages
  // App 1: Alex -> Job 1 (Offered Stage)
  const app1 = await Application.create({
    jobId: job1._id,
    candidateId: candidate1._id,
    recruiterId: recruiter1._id,
    stage: 'Offered',
    status: 'Active',
    coverNote:
      'I am very excited about NexusTech Solutions. My background in MongoDB indexing and Express RESTful design aligns closely with your architecture.',
    appliedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
    stageHistory: [
      {
        stage: 'Applied',
        changedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
        changedBy: candidate1._id,
        note: 'Application submitted by candidate.',
      },
      {
        stage: 'Shortlisted',
        changedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
        changedBy: recruiter1._id,
        note: 'Strong portfolio and relevant MERN experience. Shortlisted for technical round.',
      },
      {
        stage: 'Interview',
        changedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
        changedBy: recruiter1._id,
        note: 'Technical assessment passed with flying colors.',
      },
      {
        stage: 'Offered',
        changedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        changedBy: recruiter1._id,
        note: 'Official employment offer extended to candidate.',
      },
    ],
  });

  // App 2: Priya -> Job 3 (Interview Stage)
  const app2 = await Application.create({
    jobId: job3._id,
    candidateId: candidate2._id,
    recruiterId: recruiter2._id,
    stage: 'Interview',
    status: 'Active',
    coverNote:
      'With 3 years deploying Dockerized workloads and Terraform modules, I can immediately step in to streamline CloudScale’s infrastructure.',
    appliedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
    stageHistory: [
      {
        stage: 'Applied',
        changedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
        changedBy: candidate2._id,
        note: 'Application submitted by candidate.',
      },
      {
        stage: 'Shortlisted',
        changedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        changedBy: recruiter2._id,
        note: 'Impressive Kubernetes and AWS certifications.',
      },
      {
        stage: 'Interview',
        changedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        changedBy: recruiter2._id,
        note: 'Scheduled for system architecture interview.',
      },
    ],
  });

  // App 3: Marcus -> Job 2 (Shortlisted Stage)
  const app3 = await Application.create({
    jobId: job2._id,
    candidateId: candidate3._id,
    recruiterId: recruiter1._id,
    stage: 'Shortlisted',
    status: 'Active',
    coverNote: 'Excited about design systems and modern React engineering at NexusTech.',
    appliedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    stageHistory: [
      {
        stage: 'Applied',
        changedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        changedBy: candidate3._id,
        note: 'Application submitted by candidate.',
      },
      {
        stage: 'Shortlisted',
        changedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        changedBy: recruiter1._id,
        note: 'Clean GitHub portfolio and React skills.',
      },
    ],
  });

  // App 4: Alex -> Job 2 (Applied Stage)
  const app4 = await Application.create({
    jobId: job2._id,
    candidateId: candidate1._id,
    recruiterId: recruiter1._id,
    stage: 'Applied',
    status: 'Active',
    coverNote: 'Applying for the Senior Frontend position to further focus on UI performance.',
    appliedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    stageHistory: [
      {
        stage: 'Applied',
        changedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        changedBy: candidate1._id,
        note: 'Application submitted by candidate.',
      },
    ],
  });

  // 6. Create Interviews
  await Interview.create({
    applicationId: app2._id,
    jobId: job3._id,
    candidateId: candidate2._id,
    recruiterId: recruiter2._id,
    scheduledAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // In 3 days
    mode: 'Online',
    meetingLinkOrLocation: 'https://meet.google.com/xyz-qwe-rty',
    interviewer: 'David Thorne & Senior DevOps Lead',
    feedback: 'Pre-interview assessment scored 95/100.',
    status: 'Scheduled',
  });

  await Interview.create({
    applicationId: app1._id,
    jobId: job1._id,
    candidateId: candidate1._id,
    recruiterId: recruiter1._id,
    scheduledAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
    mode: 'Online',
    meetingLinkOrLocation: 'https://meet.google.com/abc-nexu-tech',
    interviewer: 'Sarah Jenkins & Lead Architect',
    feedback: 'Candidate displayed exceptional clarity in REST API design and Mongoose aggregation models.',
    status: 'Completed',
  });

  // 7. Create Offer
  await Offer.create({
    applicationId: app1._id,
    jobId: job1._id,
    candidateId: candidate1._id,
    recruiterId: recruiter1._id,
    position: 'Full Stack MERN Developer',
    salary: 115000,
    currency: 'USD',
    joiningDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    offerStatus: 'Sent',
    notes: 'Includes full medical/dental benefits, 401(k) matching, and annual educational stipend.',
  });

  // 8. Create Saved Jobs
  await SavedJob.create({
    candidateId: candidate1._id,
    jobId: job3._id,
  });
  await SavedJob.create({
    candidateId: candidate2._id,
    jobId: job1._id,
  });

  // 9. Create Job Alerts
  await JobAlert.create({
    candidateId: candidate1._id,
    title: 'Full Stack & MERN Remote Roles',
    keywords: ['Full Stack', 'MERN', 'Backend'],
    skills: ['Node.js', 'React', 'MongoDB'],
    location: 'Remote',
    employmentType: 'Full-time',
    isActive: true,
  });

  await JobAlert.create({
    candidateId: candidate2._id,
    title: 'DevOps & Cloud Systems',
    keywords: ['DevOps', 'Cloud', 'Kubernetes'],
    skills: ['AWS', 'Docker'],
    location: 'Austin',
    employmentType: 'Full-time',
    isActive: true,
  });

  console.log('Seeding completed successfully!');
  return {
    success: true,
    users: 6,
    companies: 2,
    jobs: 5,
    applications: 4,
    interviews: 2,
    offers: 1,
  };
}

// Standalone execution support: node server/seed/seed.js
if (process.argv[1]?.includes('seed')) {
  connectDB()
    .then(() => seedDatabase(true))
    .then(() => {
      console.log('Seed script finished.');
      process.exit(0);
    })
    .catch((err) => {
      console.error('Seed script failed:', err);
      process.exit(1);
    });
}
