import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { connectDB } from './server/config/db.js';
import { seedDatabase } from './server/seed/seed.js';
import { errorHandler } from './server/middleware/errorHandler.js';

// Route imports
import authRoutes from './server/routes/authRoutes.js';
import companyRoutes from './server/routes/companyRoutes.js';
import jobRoutes from './server/routes/jobRoutes.js';
import candidateRoutes from './server/routes/candidateRoutes.js';
import applicationRoutes from './server/routes/applicationRoutes.js';
import interviewRoutes from './server/routes/interviewRoutes.js';
import savedJobRoutes from './server/routes/savedJobRoutes.js';
import jobAlertRoutes from './server/routes/jobAlertRoutes.js';
import offerRoutes from './server/routes/offerRoutes.js';
import recruiterRoutes from './server/routes/recruiterRoutes.js';
import adminRoutes from './server/routes/adminRoutes.js';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body Parser
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Connect Database
  try {
    const mongoUri = await connectDB();
    console.log(`Database connected (${mongoUri})`);
    // Seed initial academic CIA-3 demo dataset if empty
    await seedDatabase(false);
  } catch (err: any) {
    console.error('Database connection error during boot:', err.message);
  }

  // API Health Check & Info
  app.get('/api/health', (req, res) => {
    res.json({
      success: true,
      message: 'Job Portal & Recruitment Management System API operational',
      version: '1.0.0 (CIA-3 Academic Edition)',
      timestamp: new Date().toISOString(),
    });
  });

  // Database manual re-seed endpoint for academic testing
  app.post('/api/seed/reset', async (req, res, next) => {
    try {
      const result = await seedDatabase(true);
      res.json({
        success: true,
        message: 'Database reset and re-seeded with demo records successfully',
        data: result,
      });
    } catch (error) {
      next(error);
    }
  });

  // Mount API modules
  app.use('/api/auth', authRoutes);
  app.use('/api/companies', companyRoutes);
  app.use('/api/jobs', jobRoutes);
  app.use('/api/candidate', candidateRoutes);
  app.use('/api/applications', applicationRoutes);
  app.use('/api/interviews', interviewRoutes);
  app.use('/api/saved-jobs', savedJobRoutes);
  app.use('/api/job-alerts', jobAlertRoutes);
  app.use('/api/offers', offerRoutes);
  app.use('/api/recruiter', recruiterRoutes);
  app.use('/api/admin', adminRoutes);

  // Centralized Error Handling Middleware for all API routes
  app.use(errorHandler);

  // Vite development middleware or production static asset server
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Job Portal server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal Server Startup Error:', err);
});
