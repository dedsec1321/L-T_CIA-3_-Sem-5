import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { api, setStoredAuth, clearStoredAuth, getStoredToken, getStoredUser } from '../services/api';

interface Notification {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  loading: boolean;
  notifications: Notification[];
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, role: UserRole) => Promise<void>;
  logout: () => void;
  quickLogin: (targetRole: 'Admin' | 'Recruiter' | 'Candidate') => Promise<void>;
  notify: (type: 'success' | 'error' | 'info', message: string) => void;
  dismissNotification: (id: string) => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(getStoredUser());
  const [token, setToken] = useState<string | null>(getStoredToken());
  const [loading, setLoading] = useState<boolean>(true);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const notify = (type: 'success' | 'error' | 'info', message: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setNotifications((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== id));
    }, 4500);
  };

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const refreshUser = async () => {
    try {
      if (!token) {
        setLoading(false);
        return;
      }
      const res = await api.auth.me();
      if (res.success && res.data) {
        setUser(res.data);
        setStoredAuth(token, res.data);
      }
    } catch {
      // Token expired or invalid
      logout();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, []);

  const login = async (email: string, password: string) => {
    const res = await api.auth.login({ email, password });
    if (res.success && res.data) {
      setToken(res.data.token);
      setUser(res.data.user);
      setStoredAuth(res.data.token, res.data.user);
      notify('success', `Welcome back, ${res.data.user.name} (${res.data.user.role})`);
    }
  };

  const register = async (name: string, email: string, password: string, role: UserRole) => {
    const res = await api.auth.register({ name, email, password, role });
    if (res.success && res.data) {
      setToken(res.data.token);
      setUser(res.data.user);
      setStoredAuth(res.data.token, res.data.user);
      notify('success', `Account created successfully as ${role}!`);
    }
  };

  const logout = () => {
    clearStoredAuth();
    setToken(null);
    setUser(null);
    notify('info', 'Logged out successfully');
  };

  const quickLogin = async (targetRole: 'Admin' | 'Recruiter' | 'Candidate') => {
    try {
      let email = '';
      let password = '';
      if (targetRole === 'Admin') {
        email = 'admin@jobportal.edu';
        password = 'Admin@123';
      } else if (targetRole === 'Recruiter') {
        email = 'sarah.recruiter@techcorp.com';
        password = 'Recruiter@123';
      } else {
        email = 'alex.candidate@university.edu';
        password = 'Candidate@123';
      }
      await login(email, password);
    } catch (err: any) {
      notify('error', err.message || 'Quick login failed');
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        role: user?.role || null,
        isAuthenticated: !!user && !!token,
        loading,
        notifications,
        login,
        register,
        logout,
        quickLogin,
        notify,
        dismissNotification,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
