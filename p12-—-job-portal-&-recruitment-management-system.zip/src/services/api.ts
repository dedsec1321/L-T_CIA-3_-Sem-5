import {
  User,
  Company,
  JobPosting,
  CandidateProfile,
  Application,
  Interview,
  SavedJobItem,
  JobAlertItem,
  OfferItem,
  RecruiterDashboardData,
  AdminAnalyticsData,
  ApplicationStage,
} from '../types';

const TOKEN_KEY = 'job_portal_token';
const USER_KEY = 'job_portal_user';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredAuth(token: string, user: User): void {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function clearStoredAuth(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

export function getStoredUser(): User | null {
  const data = localStorage.getItem(USER_KEY);
  if (!data) return null;
  try {
    return JSON.parse(data);
  } catch {
    return null;
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(endpoint, {
    ...options,
    headers,
  });

  const body = await res.json().catch(() => ({}));

  if (!res.ok) {
    const errorMsg = body.message || `Request failed with HTTP status ${res.status}`;
    const err = new Error(errorMsg) as any;
    err.status = res.status;
    err.errorCode = body.errorCode;
    throw err;
  }

  return body;
}

export const api = {
  // Auth
  auth: {
    login: (credentials: { email: string; password: string }) =>
      request<{ success: boolean; data: { token: string; user: User } }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      }),
    register: (userData: { name: string; email: string; password: string; role: string }) =>
      request<{ success: boolean; data: { token: string; user: User } }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
      }),
    me: () => request<{ success: boolean; data: User }>('/api/auth/me'),
  },

  // Jobs
  jobs: {
    list: (params: Record<string, any> = {}) => {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') query.append(k, String(v));
      });
      return request<{ success: boolean; data: JobPosting[]; pagination: any }>(`/api/jobs?${query.toString()}`);
    },
    getById: (id: string) => request<{ success: boolean; data: JobPosting }>(`/api/jobs/${id}`),
    getMyJobs: () => request<{ success: boolean; data: JobPosting[] }>('/api/jobs/recruiter/my-jobs'),
    create: (data: any) =>
      request<{ success: boolean; data: JobPosting }>('/api/jobs', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    update: (id: string, data: any) =>
      request<{ success: boolean; data: JobPosting }>(`/api/jobs/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    changeStatus: (id: string, status: string) =>
      request<{ success: boolean; data: JobPosting }>(`/api/jobs/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      }),
    delete: (id: string) =>
      request<{ success: boolean; message: string }>(`/api/jobs/${id}`, {
        method: 'DELETE',
      }),
  },

  // Company
  company: {
    getMyCompany: () => request<{ success: boolean; data: Company | null }>('/api/companies/recruiter/my-company'),
    getById: (id: string) => request<{ success: boolean; data: Company }>(`/api/companies/${id}`),
    create: (data: any) =>
      request<{ success: boolean; data: Company }>('/api/companies', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    update: (id: string, data: any) =>
      request<{ success: boolean; data: Company }>(`/api/companies/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
  },

  // Candidate
  candidate: {
    getProfile: () => request<{ success: boolean; data: CandidateProfile | null }>('/api/candidate/profile'),
    updateProfile: (data: any) =>
      request<{ success: boolean; data: CandidateProfile }>('/api/candidate/profile', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    getById: (id: string) => request<{ success: boolean; data: CandidateProfile }>(`/api/candidate/profile/${id}`),
  },

  // Applications & Pipeline
  applications: {
    apply: (jobId: string, coverNote?: string) =>
      request<{ success: boolean; data: Application }>('/api/applications', {
        method: 'POST',
        body: JSON.stringify({ jobId, coverNote }),
      }),
    getMyApplications: () => request<{ success: boolean; data: Application[] }>('/api/applications/my-applications'),
    getApplicantsForJob: (jobId: string) =>
      request<{ success: boolean; data: Application[] }>(`/api/applications/job/${jobId}`),
    getAllRecruiterApplicants: (stage?: string) => {
      const q = stage && stage !== 'All' ? `?stage=${stage}` : '';
      return request<{ success: boolean; data: Application[] }>(`/api/applications/recruiter/all${q}`);
    },
    updateStage: (id: string, stage: ApplicationStage, note?: string) =>
      request<{ success: boolean; message: string; data: Application }>(`/api/applications/${id}/stage`, {
        method: 'PUT',
        body: JSON.stringify({ stage, note }),
      }),
    withdraw: (id: string) =>
      request<{ success: boolean; message: string; data: Application }>(`/api/applications/${id}/withdraw`, {
        method: 'PATCH',
      }),
  },

  // Interviews
  interviews: {
    getMyInterviews: () => request<{ success: boolean; data: Interview[] }>('/api/interviews/my-interviews'),
    getRecruiterInterviews: () => request<{ success: boolean; data: Interview[] }>('/api/interviews/recruiter'),
    schedule: (data: any) =>
      request<{ success: boolean; data: Interview }>('/api/interviews', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    updateStatus: (id: string, status: string, feedback?: string) =>
      request<{ success: boolean; data: Interview }>(`/api/interviews/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status, feedback }),
      }),
  },

  // Saved Jobs
  savedJobs: {
    list: () => request<{ success: boolean; data: SavedJobItem[] }>('/api/saved-jobs'),
    save: (jobId: string) =>
      request<{ success: boolean; data: SavedJobItem }>('/api/saved-jobs', {
        method: 'POST',
        body: JSON.stringify({ jobId }),
      }),
    unsave: (jobId: string) =>
      request<{ success: boolean; message: string }>(`/api/saved-jobs/${jobId}`, {
        method: 'DELETE',
      }),
  },

  // Job Alerts
  jobAlerts: {
    list: () => request<{ success: boolean; data: JobAlertItem[] }>('/api/job-alerts'),
    matches: () => request<{ success: boolean; data: JobPosting[] }>('/api/job-alerts/matches'),
    create: (data: any) =>
      request<{ success: boolean; data: JobAlertItem }>('/api/job-alerts', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    delete: (id: string) =>
      request<{ success: boolean; message: string }>(`/api/job-alerts/${id}`, {
        method: 'DELETE',
      }),
  },

  // Offers
  offers: {
    getMyOffers: () => request<{ success: boolean; data: OfferItem[] }>('/api/offers/my-offers'),
    getRecruiterOffers: () => request<{ success: boolean; data: OfferItem[] }>('/api/offers/recruiter'),
    create: (data: any) =>
      request<{ success: boolean; data: OfferItem }>('/api/offers', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    respond: (id: string, action: 'accept' | 'decline') =>
      request<{ success: boolean; message: string; data: OfferItem }>(`/api/offers/${id}/respond`, {
        method: 'PATCH',
        body: JSON.stringify({ action }),
      }),
  },

  // Recruiter Dashboard
  recruiter: {
    getDashboard: () => request<{ success: boolean; data: RecruiterDashboardData }>('/api/recruiter/dashboard'),
  },

  // Admin
  admin: {
    getAnalytics: () => request<{ success: boolean; data: AdminAnalyticsData }>('/api/admin/analytics'),
    getUsers: (params: Record<string, any> = {}) => {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') query.append(k, String(v));
      });
      return request<{ success: boolean; data: User[]; pagination: any }>(`/api/admin/users?${query.toString()}`);
    },
    toggleUserStatus: (id: string) =>
      request<{ success: boolean; message: string; data: any }>(`/api/admin/users/${id}/status`, {
        method: 'PATCH',
      }),
    getCompanies: () => request<{ success: boolean; data: Company[] }>('/api/admin/companies'),
    getJobs: () => request<{ success: boolean; data: JobPosting[] }>('/api/admin/jobs'),
    resetDatabase: () =>
      request<{ success: boolean; message: string; data: any }>('/api/seed/reset', {
        method: 'POST',
      }),
  },
};
