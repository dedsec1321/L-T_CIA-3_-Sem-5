import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { ToastContainer } from './components/ToastContainer';
import { AuthModal } from './components/auth/AuthModal';

// Candidate Views
import { JobBoardView } from './components/candidate/JobBoardView';
import { MyApplicationsView } from './components/candidate/MyApplicationsView';
import { CandidateProfileView } from './components/candidate/CandidateProfileView';
import { JobAlertsView } from './components/candidate/JobAlertsView';
import { OffersAndInterviewsView } from './components/candidate/OffersAndInterviewsView';

// Recruiter Views
import { RecruiterDashboardView } from './components/recruiter/RecruiterDashboardView';
import { ApplicantPipelineView } from './components/recruiter/ApplicantPipelineView';
import { RecruiterJobsView } from './components/recruiter/RecruiterJobsView';
import { InterviewManagementView } from './components/recruiter/InterviewManagementView';
import { OfferManagementView } from './components/recruiter/OfferManagementView';
import { CompanyProfileView } from './components/recruiter/CompanyProfileView';

// Admin Views
import { AdminAnalyticsView } from './components/admin/AdminAnalyticsView';
import { AdminUserManagementView } from './components/admin/AdminUserManagementView';
import { AdminPlatformOverviewView } from './components/admin/AdminPlatformOverviewView';

import { Application } from './types';
import { Shield, Sparkles, CheckCircle2, Terminal } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, role, loading, quickLogin } = useAuth();
  const [currentTab, setCurrentTab] = useState<string>('candidate-jobs');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [preselectedApp, setPreselectedApp] = useState<Application | null>(null);

  // Sync tab when user role changes
  useEffect(() => {
    if (role === 'Recruiter') {
      if (!currentTab.startsWith('recruiter-')) {
        setCurrentTab('recruiter-dashboard');
      }
    } else if (role === 'Admin') {
      if (!currentTab.startsWith('admin-')) {
        setCurrentTab('admin-analytics');
      }
    } else if (role === 'Candidate') {
      if (!currentTab.startsWith('candidate-')) {
        setCurrentTab('candidate-jobs');
      }
    }
  }, [role]);

  // When clicking schedule interview from pipeline
  const handleScheduleInterviewFor = (app: Application) => {
    setPreselectedApp(app);
    setCurrentTab('recruiter-interviews');
  };

  // When clicking issue offer from pipeline
  const handleIssueOfferFor = (app: Application) => {
    setPreselectedApp(app);
    setCurrentTab('recruiter-offers');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenAuth={() => setIsAuthModalOpen(true)}
      />

      <main className="flex-1">
        {/* Candidate Tabs */}
        {currentTab === 'candidate-jobs' && <JobBoardView />}
        {currentTab === 'candidate-apps' && <MyApplicationsView />}
        {currentTab === 'candidate-profile' && <CandidateProfileView />}
        {currentTab === 'candidate-alerts' && <JobAlertsView />}
        {currentTab === 'candidate-offers' && <OffersAndInterviewsView />}

        {/* Recruiter Tabs */}
        {currentTab === 'recruiter-dashboard' && (
          <RecruiterDashboardView
            onNavigateToPipeline={() => setCurrentTab('recruiter-pipeline')}
            onNavigateToJobs={() => setCurrentTab('recruiter-jobs')}
          />
        )}
        {currentTab === 'recruiter-pipeline' && (
          <ApplicantPipelineView
            onScheduleInterviewFor={handleScheduleInterviewFor}
            onIssueOfferFor={handleIssueOfferFor}
          />
        )}
        {currentTab === 'recruiter-jobs' && <RecruiterJobsView />}
        {currentTab === 'recruiter-interviews' && (
          <InterviewManagementView
            preselectedApp={preselectedApp}
            onClearPreselectedApp={() => setPreselectedApp(null)}
          />
        )}
        {currentTab === 'recruiter-offers' && (
          <OfferManagementView
            preselectedApp={preselectedApp}
            onClearPreselectedApp={() => setPreselectedApp(null)}
          />
        )}
        {currentTab === 'recruiter-company' && <CompanyProfileView />}

        {/* Admin Tabs */}
        {currentTab === 'admin-analytics' && <AdminAnalyticsView />}
        {currentTab === 'admin-users' && <AdminUserManagementView />}
        {currentTab === 'admin-directory' && <AdminPlatformOverviewView />}
      </main>

      {/* Academic CIA-3 Technical Footer */}
      <footer className="bg-slate-900 border-t border-slate-800/80 text-xs text-slate-400 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <div className="font-semibold text-slate-200 flex items-center justify-center sm:justify-start gap-2">
              <Shield className="w-4 h-4 text-indigo-400" />
              CIA-3 Academic Project: Job Portal & Recruitment Management System
            </div>
            <div className="text-[11px] text-slate-400">
              Domain: HR Tech &bull; Architecture: MVC REST API &bull; Database: MongoDB Atlas (Mongoose ODM)
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px]">
            <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300 font-mono">
              JWT + bcryptjs
            </span>
            <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300 font-mono">
              Server-Side RBAC
            </span>
            <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300 font-mono">
              State Machine (5-Stage)
            </span>
          </div>
        </div>
      </footer>

      {/* Global Notifications and Auth Modal */}
      <ToastContainer />
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
