export type UserRole = 'Candidate' | 'Recruiter' | 'Admin';

export interface User {
  id: string;
  _id?: string;
  name: string;
  email: string;
  role: UserRole;
  isActive: boolean;
  createdAt?: string;
}

export interface Company {
  _id: string;
  recruiterId: string | User;
  name: string;
  description: string;
  website?: string;
  location: string;
  industry: string;
  companySize?: string;
  logoUrl?: string;
  createdAt?: string;
  jobCount?: number;
}

export interface SalaryRange {
  min: number;
  max: number;
  currency: string;
}

export interface JobPosting {
  _id: string;
  companyId: Company;
  recruiterId: User | string;
  title: string;
  description: string;
  skills: string[];
  location: string;
  employmentType: 'Full-time' | 'Part-time' | 'Contract' | 'Internship' | 'Remote';
  experienceRequired: string;
  experienceYearsMin: number;
  salaryRange: SalaryRange;
  status: 'Draft' | 'Published' | 'Closed';
  createdAt: string;
  updatedAt: string;
  isSaved?: boolean;
  hasApplied?: boolean;
  applicantsCount?: number;
}

export interface EducationItem {
  degree: string;
  institution: string;
  yearOfCompletion: number;
  fieldOfStudy: string;
  grade?: string;
}

export interface CandidateProfile {
  _id?: string;
  userId: string;
  fullName: string;
  phone: string;
  location: string;
  skills: string[];
  education: EducationItem[];
  experienceYears: number;
  experienceSummary: string;
  resumeSummary: string;
  resumeFileName?: string;
  portfolioUrl?: string;
  linkedinUrl?: string;
  updatedAt?: string;
}

export type ApplicationStage = 'Applied' | 'Shortlisted' | 'Interview' | 'Offered' | 'Hired' | 'Rejected';

export interface StageHistoryItem {
  stage: ApplicationStage;
  changedAt: string;
  changedBy?: string;
  note?: string;
}

export interface Application {
  _id: string;
  jobId: JobPosting;
  candidateId: User;
  recruiterId: string;
  stage: ApplicationStage;
  status: 'Active' | 'Withdrawn' | 'Archived';
  coverNote?: string;
  appliedAt: string;
  stageHistory: StageHistoryItem[];
  createdAt: string;
}

export interface Interview {
  _id: string;
  applicationId: string | Application;
  jobId: JobPosting;
  candidateId: User;
  recruiterId: User | string;
  scheduledAt: string;
  mode: 'Online' | 'In-Person';
  meetingLinkOrLocation: string;
  interviewer: string;
  feedback?: string;
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  createdAt: string;
}

export interface SavedJobItem {
  _id: string;
  candidateId: string;
  jobId: JobPosting;
  createdAt: string;
}

export interface JobAlertItem {
  _id: string;
  candidateId: string;
  title: string;
  keywords: string[];
  skills: string[];
  location?: string;
  employmentType?: string;
  isActive: boolean;
  createdAt: string;
}

export interface OfferItem {
  _id: string;
  applicationId: string;
  jobId: JobPosting;
  candidateId: User;
  recruiterId: User;
  position: string;
  salary: number;
  currency: string;
  joiningDate: string;
  offerStatus: 'Draft' | 'Sent' | 'Accepted' | 'Declined';
  notes?: string;
  createdAt: string;
}

export interface RecruiterDashboardData {
  summary: {
    totalJobs: number;
    publishedJobs: number;
    draftJobs: number;
    closedJobs: number;
    totalApplications: number;
    hires: number;
    totalInterviews: number;
    upcomingInterviews: number;
    completedInterviews: number;
    totalOffers: number;
    acceptedOffers: number;
    pendingOffers: number;
  };
  applicationsByStage: { stage: ApplicationStage; count: number }[];
  recentApplications: Application[];
}

export interface FunnelStep {
  step: string;
  count: number;
  percentageOfTotal: number;
  conversionFromPrevious: number;
}

export interface AdminAnalyticsData {
  users: {
    total: number;
    candidates: number;
    recruiters: number;
    admins: number;
  };
  companies: {
    total: number;
  };
  jobs: {
    total: number;
    published: number;
    draft: number;
    closed: number;
  };
  applications: {
    total: number;
    byStage: Record<ApplicationStage, number>;
    hires: number;
    rejections: number;
  };
  interviews: {
    total: number;
  };
  offers: {
    total: number;
    accepted: number;
  };
  funnel: FunnelStep[];
}
