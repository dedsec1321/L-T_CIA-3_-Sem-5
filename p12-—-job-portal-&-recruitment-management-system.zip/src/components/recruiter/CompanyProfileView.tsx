import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Company } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Building2,
  Globe,
  MapPin,
  Users,
  FileText,
  Save,
  Image,
} from 'lucide-react';

export const CompanyProfileView: React.FC = () => {
  const { notify } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [company, setCompany] = useState<Partial<Company>>({
    name: '',
    industry: 'Enterprise SaaS & Cloud Infrastructure',
    location: 'San Francisco, CA',
    website: 'https://nexuscloud.io',
    size: '100-500',
    description: '',
    logoUrl: 'https://images.unsplash.com/photo-1542744094-3a31f272c490?w=200&auto=format&fit=crop&q=80',
  });

  const fetchCompany = async () => {
    setLoading(true);
    try {
      const res = await api.company.getMyCompany();
      if (res.success && res.data) {
        setCompany(res.data);
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to load company profile');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCompany();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (company._id) {
        await api.company.update(company._id, company);
        notify('success', 'Company profile updated successfully');
      } else {
        const res = await api.company.create(company as any);
        if (res.success) {
          setCompany(res.data);
          notify('success', 'Company profile created successfully');
        }
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to save company profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="py-20 text-center text-slate-400 text-sm">Loading company profile...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
          <Building2 className="w-6 h-6 text-indigo-400" />
          Hiring Organization Profile
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Brand identity, company overview, website credentials, and employer details visible to candidates.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-6 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row items-center gap-4 pb-6 border-b border-slate-800">
          {company.logoUrl ? (
            <img
              src={company.logoUrl}
              alt={company.name || 'Company'}
              className="w-20 h-20 rounded-xl object-cover border border-slate-700 shrink-0"
            />
          ) : (
            <div className="w-20 h-20 rounded-xl bg-indigo-950 border border-indigo-800 flex items-center justify-center text-indigo-300 font-bold text-2xl shrink-0">
              {company.name?.charAt(0) || 'C'}
            </div>
          )}

          <div className="flex-1 w-full">
            <label className="block text-xs font-medium text-slate-300 mb-1">Company Logo URL</label>
            <div className="relative">
              <Image className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="url"
                value={company.logoUrl || ''}
                onChange={(e) => setCompany({ ...company, logoUrl: e.target.value })}
                placeholder="https://example.com/logo.png"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Company Name</label>
            <input
              type="text"
              required
              value={company.name || ''}
              onChange={(e) => setCompany({ ...company, name: e.target.value })}
              placeholder="Nexus Cloud Systems"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Primary Industry</label>
            <input
              type="text"
              required
              value={company.industry || ''}
              onChange={(e) => setCompany({ ...company, industry: e.target.value })}
              placeholder="Enterprise SaaS, Cloud Infrastructure"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Headquarters Location</label>
            <input
              type="text"
              required
              value={company.location || ''}
              onChange={(e) => setCompany({ ...company, location: e.target.value })}
              placeholder="San Francisco, CA"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Official Website</label>
            <input
              type="url"
              required
              value={company.website || ''}
              onChange={(e) => setCompany({ ...company, website: e.target.value })}
              placeholder="https://company.com"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Company Size</label>
            <select
              value={company.size || '50-100'}
              onChange={(e) => setCompany({ ...company, size: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="1-10">1-10 employees (Seed)</option>
              <option value="10-50">10-50 employees (Startup)</option>
              <option value="50-200">50-200 employees (Growth)</option>
              <option value="200-1000">200-1000 employees (Mid-Market)</option>
              <option value="1000+">1000+ employees (Enterprise)</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            Company Bio & Mission Statement
          </label>
          <textarea
            rows={4}
            required
            value={company.description || ''}
            onChange={(e) => setCompany({ ...company, description: e.target.value })}
            placeholder="Tell candidates about your engineering culture, mission, and benefits..."
            className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-indigo-500 leading-relaxed"
          />
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shadow flex items-center gap-2 transition disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Saving...' : 'Save Organization Profile'}
          </button>
        </div>
      </form>
    </div>
  );
};
