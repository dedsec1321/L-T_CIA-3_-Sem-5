import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { OfferItem, Application } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Award,
  Plus,
  DollarSign,
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  Building2,
  X,
} from 'lucide-react';

interface OfferManagementViewProps {
  preselectedApp?: Application | null;
  onClearPreselectedApp?: () => void;
}

export const OfferManagementView: React.FC<OfferManagementViewProps> = ({
  preselectedApp,
  onClearPreselectedApp,
}) => {
  const { notify } = useAuth();
  const [offers, setOffers] = useState<OfferItem[]>([]);
  const [eligibleApps, setEligibleApps] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);

  // Issue Offer Modal
  const [showModal, setShowModal] = useState(false);
  const [selectedAppId, setSelectedAppId] = useState('');
  const [position, setPosition] = useState('');
  const [salary, setSalary] = useState(125000);
  const [currency, setCurrency] = useState('USD');
  const [joiningDate, setJoiningDate] = useState('');
  const [notes, setNotes] = useState('Standard comprehensive medical, vision, 401(k), and equity package included.');
  const [submitting, setSubmitting] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [offersRes, appsRes] = await Promise.all([
        api.offers.getMyOffers(),
        api.applications.getAllRecruiterApplicants(),
      ]);
      if (offersRes.success) setOffers(offersRes.data);
      if (appsRes.success) {
        // eligible candidates are those in Interview or Offered stage
        setEligibleApps(appsRes.data.filter((a) => a.stage === 'Interview' || a.stage === 'Offered'));
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to load offers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (preselectedApp) {
      setSelectedAppId(preselectedApp._id);
      setPosition(preselectedApp.jobId?.title || '');
      setShowModal(true);
    }
  }, [preselectedApp]);

  const handleOpenModal = () => {
    if (eligibleApps.length === 0) {
      notify('info', 'No candidates currently in Interview or Offered stage to extend an offer');
    }
    const defaultJoining = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    setJoiningDate(defaultJoining);
    if (eligibleApps.length > 0) {
      setSelectedAppId(eligibleApps[0]._id);
      setPosition(eligibleApps[0].jobId?.title || '');
    }
    setShowModal(true);
  };

  const handleSelectApp = (appId: string) => {
    setSelectedAppId(appId);
    const found = eligibleApps.find((a) => a._id === appId);
    if (found) {
      setPosition(found.jobId?.title || '');
    }
  };

  const handleIssueSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAppId) {
      notify('error', 'Please select an eligible candidate');
      return;
    }

    setSubmitting(true);
    try {
      await api.offers.create({
        applicationId: selectedAppId,
        position,
        salary: Number(salary),
        currency,
        joiningDate,
        notes,
      });
      notify('success', 'Formal employment offer issued to candidate!');
      setShowModal(false);
      if (onClearPreselectedApp) onClearPreselectedApp();
      loadData();
    } catch (err: any) {
      notify('error', err.message || 'Failed to issue offer');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
            <Award className="w-6 h-6 text-indigo-400" />
            Recruiter Offer Letter Management
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Issue legally binding employment packages, track candidate responses, and advance stage to Hired.
          </p>
        </div>

        <button
          onClick={handleOpenModal}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow flex items-center gap-1.5 transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Issue New Job Offer
        </button>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400 text-sm">Loading offers...</div>
      ) : offers.length === 0 ? (
        <div className="py-20 text-center bg-slate-900 border border-slate-800 rounded-xl p-8">
          <Award className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-200">No offers issued yet</h3>
          <p className="text-sm text-slate-400 mt-1 mb-4">
            Candidates who clear technical interviews can be extended formal offers here.
          </p>
          <button
            onClick={handleOpenModal}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium"
          >
            Issue Offer
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {offers.map((offer) => {
            const isAccepted = offer.offerStatus === 'Accepted';
            const isDeclined = offer.offerStatus === 'Declined';
            const isSent = offer.offerStatus === 'Sent';

            return (
              <div
                key={offer._id}
                className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-bold text-white">{offer.candidateId?.name}</h3>
                    <p className="text-xs text-indigo-300 font-semibold">{offer.position}</p>
                    <p className="text-xs text-slate-400">{offer.candidateId?.email}</p>
                  </div>

                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                      isAccepted
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : isDeclined
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {offer.offerStatus}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
                  <div className="bg-slate-800/60 p-2.5 rounded border border-slate-700/80">
                    <span className="text-slate-400 block text-[10px] uppercase">Offered Annual Salary</span>
                    <span className="text-sm font-bold text-emerald-400">
                      ${offer.salary?.toLocaleString()} {offer.currency}
                    </span>
                  </div>

                  <div className="bg-slate-800/60 p-2.5 rounded border border-slate-700/80">
                    <span className="text-slate-400 block text-[10px] uppercase">Joining Date</span>
                    <span className="text-xs font-semibold text-white">
                      {new Date(offer.joiningDate).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {offer.notes && (
                  <div className="text-xs text-slate-400 bg-slate-800/30 p-2.5 rounded border border-slate-800">
                    <span className="font-semibold text-slate-300 block mb-0.5">Offer Notes:</span>
                    <p className="italic">{offer.notes}</p>
                  </div>
                )}

                <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-800 flex justify-between">
                  <span>Issued on: {new Date(offer.issuedAt).toLocaleDateString()}</span>
                  <span>Recruiter: {offer.recruiterId?.name}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Issue Offer Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative text-slate-100">
            <button
              onClick={() => {
                setShowModal(false);
                if (onClearPreselectedApp) onClearPreselectedApp();
              }}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-white mb-1">Issue Formal Employment Offer</h3>
            <p className="text-xs text-slate-400 mb-4">
              Transfers candidate into the Offered pipeline stage and sends terms.
            </p>

            <form onSubmit={handleIssueSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Select Candidate</label>
                <select
                  required
                  value={selectedAppId}
                  onChange={(e) => handleSelectApp(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="">Select candidate from interview pipeline</option>
                  {eligibleApps.map((a) => (
                    <option key={a._id} value={a._id}>
                      {a.candidateId?.name} — {a.jobId?.title} ({a.stage})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Position Title</label>
                <input
                  type="text"
                  required
                  value={position}
                  onChange={(e) => setPosition(e.target.value)}
                  placeholder="e.g. Senior Software Engineer"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Annual Salary</label>
                  <input
                    type="number"
                    required
                    step="1000"
                    value={salary}
                    onChange={(e) => setSalary(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Currency</label>
                  <input
                    type="text"
                    required
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Scheduled Joining Date</label>
                <input
                  type="date"
                  required
                  value={joiningDate}
                  onChange={(e) => setJoiningDate(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Terms & Compensation Notes
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Medical benefits, 401(k), paid time off..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow transition disabled:opacity-50"
                >
                  {submitting ? 'Issuing...' : 'Issue Formal Offer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
