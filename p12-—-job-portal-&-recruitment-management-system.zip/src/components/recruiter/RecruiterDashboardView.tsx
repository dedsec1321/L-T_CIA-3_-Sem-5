import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { RecruiterDashboardData, ApplicationStage } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Briefcase,
  Users,
  Award,
  Calendar,
  Clock,
  TrendingUp,
  Building2,
  CheckCircle2,
  ChevronRight,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface RecruiterDashboardViewProps {
  onNavigateToPipeline: () => void;
  onNavigateToJobs: () => void;
}

const STAGE_COLORS: Record<string, string> = {
  Applied: '#6366f1',
  Shortlisted: '#3b82f6',
  Interview: '#0ea5e9',
  Offered: '#eab308',
  Hired: '#10b981',
  Rejected: '#ef4444',
};

export const RecruiterDashboardView: React.FC<RecruiterDashboardViewProps> = ({
  onNavigateToPipeline,
  onNavigateToJobs,
}) => {
  const { notify } = useAuth();
  const [data, setData] = useState<RecruiterDashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchDashboard = async () => {
    setLoading(true);
    try {
      const res = await api.recruiter.getDashboard();
      if (res.success) {
        setData(res.data);
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to load recruiter metrics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  if (loading) {
    return <div className="py-20 text-center text-slate-400 text-sm">Loading recruiter analytics dashboard...</div>;
  }

  if (!data) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Recruiter Talent & Pipeline Dashboard
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Real-time hiring velocity, candidate stages, interview calendars, and employment offers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onNavigateToJobs}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition"
          >
            Manage Jobs
          </button>
          <button
            onClick={onNavigateToPipeline}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow transition flex items-center gap-1.5"
          >
            <span>Open Kanban Pipeline</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Jobs</span>
            <Briefcase className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white">{data.summary.totalJobs}</div>
          <div className="text-[11px] text-slate-400 mt-1">{data.summary.publishedJobs} Published</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Applicants</span>
            <Users className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white">{data.summary.totalApplications}</div>
          <div className="text-[11px] text-blue-400 mt-1">Active candidates</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Interviews</span>
            <Calendar className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-bold text-white">{data.summary.totalInterviews}</div>
          <div className="text-[11px] text-sky-400 mt-1">{data.summary.upcomingInterviews} Upcoming</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Offers Sent</span>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white">{data.summary.totalOffers}</div>
          <div className="text-[11px] text-amber-400 mt-1">{data.summary.pendingOffers} Awaiting response</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Hires Made</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white">{data.summary.hires}</div>
          <div className="text-[11px] text-emerald-400 mt-1">Completed conversions</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Closed Jobs</span>
            <Clock className="w-4 h-4 text-slate-500" />
          </div>
          <div className="text-2xl font-bold text-white">{data.summary.closedJobs}</div>
          <div className="text-[11px] text-slate-400 mt-1">Archived positions</div>
        </div>
      </div>

      {/* Chart Section: Applications by Pipeline Stage */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
              Applicant Pipeline Stage Distribution (MongoDB Aggregation)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Live count of job candidates across each milestone of your recruitment workflow.
            </p>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.applicationsByStage} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <XAxis dataKey="stage" stroke="#94a3b8" fontSize={12} tickLine={false} />
              <YAxis stroke="#94a3b8" fontSize={12} allowDecimals={false} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: '1px solid #334155',
                  borderRadius: '8px',
                  color: '#f8fafc',
                  fontSize: '12px',
                }}
              />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                {data.applicationsByStage.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={STAGE_COLORS[entry.stage] || '#6366f1'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Applications Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">Recent Candidate Submissions</h3>
          <button
            onClick={onNavigateToPipeline}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
          >
            <span>View All Applicants</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {data.recentApplications.length === 0 ? (
          <p className="text-xs text-slate-400 py-4 italic">No applications received yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-800/60 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Candidate</th>
                  <th className="py-3 px-4">Target Job</th>
                  <th className="py-3 px-4">Current Stage</th>
                  <th className="py-3 px-4">Applied Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {data.recentApplications.map((app) => (
                  <tr key={app._id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4 font-semibold text-white">
                      <div>{app.candidateId?.name}</div>
                      <div className="text-[11px] text-slate-400 font-normal">{app.candidateId?.email}</div>
                    </td>
                    <td className="py-3 px-4">{app.jobId?.title}</td>
                    <td className="py-3 px-4">
                      <span
                        className="px-2 py-0.5 rounded text-[11px] font-semibold border"
                        style={{
                          backgroundColor: `${STAGE_COLORS[app.stage]}15`,
                          borderColor: `${STAGE_COLORS[app.stage]}40`,
                          color: STAGE_COLORS[app.stage],
                        }}
                      >
                        {app.stage}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      {new Date(app.appliedAt).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={onNavigateToPipeline}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-700 text-[11px] font-medium transition"
                      >
                        Manage in Pipeline
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
