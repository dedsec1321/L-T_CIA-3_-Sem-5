import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Application, ApplicationStage, JobPosting, CandidateProfile } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Layers,
  ArrowRight,
  User,
  Calendar,
  Award,
  Filter,
  X,
  Clock,
  Briefcase,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';

const PIPELINE_COLUMNS: { stage: ApplicationStage; label: string; color: string }[] = [
  { stage: 'Applied', label: 'Applied', color: 'border-indigo-600/60 bg-indigo-950/20' },
  { stage: 'Shortlisted', label: 'Shortlisted', color: 'border-blue-600/60 bg-blue-950/20' },
  { stage: 'Interview', label: 'Interview', color: 'border-sky-600/60 bg-sky-950/20' },
  { stage: 'Offered', label: 'Offered', color: 'border-amber-600/60 bg-amber-950/20' },
  { stage: 'Hired', label: 'Hired', color: 'border-emerald-600/60 bg-emerald-950/20' },
  { stage: 'Rejected', label: 'Rejected', color: 'border-rose-600/60 bg-rose-950/20' },
];

const VALID_NEXT_STAGES: Record<ApplicationStage, ApplicationStage[]> = {
  Applied: ['Shortlisted', 'Rejected'],
  Shortlisted: ['Interview', 'Rejected'],
  Interview: ['Offered', 'Rejected'],
  Offered: ['Hired', 'Rejected'],
  Hired: [],
  Rejected: [],
};

interface ApplicantPipelineViewProps {
  onScheduleInterviewFor?: (app: Application) => void;
  onIssueOfferFor?: (app: Application) => void;
}

export const ApplicantPipelineView: React.FC<ApplicantPipelineViewProps> = ({
  onScheduleInterviewFor,
  onIssueOfferFor,
}) => {
  const { notify } = useAuth();
  const [applications, setApplications] = useState<Application[]>([]);
  const [jobs, setJobs] = useState<JobPosting[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<string>('All');
  const [loading, setLoading] = useState(true);

  // Transition stage modal
  const [transitioningApp, setTransitioningApp] = useState<Application | null>(null);
  const [targetStage, setTargetStage] = useState<ApplicationStage | ''>('');
  const [transitionNote, setTransitionNote] = useState('');
  const [submittingTransition, setSubmittingTransition] = useState(false);

  // Candidate inspection profile modal
  const [inspectingCandidateId, setInspectingCandidateId] = useState<string | null>(null);
  const [candidateProfile, setCandidateProfile] = useState<CandidateProfile | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [appsRes, jobsRes] = await Promise.all([
        api.applications.getAllRecruiterApplicants(),
        api.jobs.getMyJobs(),
      ]);
      if (appsRes.success) setApplications(appsRes.data);
      if (jobsRes.success) setJobs(jobsRes.data);
    } catch (err: any) {
      notify('error', err.message || 'Failed to load applicant pipeline');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredApplications = applications.filter((app) => {
    if (selectedJobId === 'All') return true;
    const jId = typeof app.jobId === 'object' ? app.jobId?._id : app.jobId;
    return jId === selectedJobId;
  });

  const handleOpenTransition = (app: Application) => {
    setTransitioningApp(app);
    const valid = VALID_NEXT_STAGES[app.stage];
    setTargetStage(valid.length > 0 ? valid[0] : '');
    setTransitionNote('');
  };

  const handleExecuteTransition = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transitioningApp || !targetStage) return;

    setSubmittingTransition(true);
    try {
      const res = await api.applications.updateStage(
        transitioningApp._id,
        targetStage as ApplicationStage,
        transitionNote
      );
      notify('success', `Candidate moved to ${targetStage}!`);
      setTransitioningApp(null);
      fetchData();
    } catch (err: any) {
      // Show server-side validation/409 error message
      notify('error', err.message || 'Stage transition failed');
    } finally {
      setSubmittingTransition(false);
    }
  };

  const handleInspectCandidate = async (userId: string) => {
    setInspectingCandidateId(userId);
    setLoadingProfile(true);
    try {
      const res = await api.candidate.getById(userId);
      if (res.success) {
        setCandidateProfile(res.data);
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to retrieve candidate profile');
    } finally {
      setLoadingProfile(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header and Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
            <Layers className="w-6 h-6 text-indigo-400" />
            Applicant Pipeline Kanban
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Enforces strict state transitions: Applied &rarr; Shortlisted &rarr; Interview &rarr; Offered &rarr; Hired (or Rejected).
          </p>
        </div>

        {/* Job Selector Filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={selectedJobId}
            onChange={(e) => setSelectedJobId(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
          >
            <option value="All">All Jobs ({jobs.length})</option>
            {jobs.map((j) => (
              <option key={j._id} value={j._id}>
                {j.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400 text-sm">Loading applicant pipeline...</div>
      ) : (
        /* Kanban Columns */
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3 min-h-[600px] overflow-x-auto pb-4">
          {PIPELINE_COLUMNS.map((col) => {
            const colApps = filteredApplications.filter((a) => a.stage === col.stage);

            return (
              <div
                key={col.stage}
                className={`bg-slate-900/90 rounded-xl p-3 border flex flex-col ${col.color}`}
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-800">
                  <span className="text-xs font-bold text-white tracking-wide">{col.label}</span>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-800 text-slate-300">
                    {colApps.length}
                  </span>
                </div>

                {/* Cards in Column */}
                <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[650px] pr-1">
                  {colApps.length === 0 ? (
                    <div className="text-[11px] text-slate-500 text-center py-8 italic">
                      No candidates in {col.label}
                    </div>
                  ) : (
                    colApps.map((app) => {
                      const validNext = VALID_NEXT_STAGES[app.stage];
                      const canAdvance = validNext.length > 0;

                      return (
                        <div
                          key={app._id}
                          className="bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 rounded-lg p-3 shadow transition text-xs space-y-2"
                        >
                          {/* Candidate Name & Job */}
                          <div>
                            <div className="font-bold text-white leading-tight">
                              {app.candidateId?.name}
                            </div>
                            <div className="text-[11px] text-slate-400 truncate mt-0.5">
                              {app.candidateId?.email}
                            </div>
                            <div className="text-[11px] font-medium text-indigo-300 mt-1 truncate">
                              {app.jobId?.title}
                            </div>
                          </div>

                          {/* Cover Note snippet if exists */}
                          {app.coverNote && (
                            <div className="bg-slate-900/80 p-2 rounded text-[11px] text-slate-300 line-clamp-2 italic border border-slate-800">
                              &ldquo;{app.coverNote}&rdquo;
                            </div>
                          )}

                          <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                            <span>{new Date(app.appliedAt).toLocaleDateString()}</span>
                            <button
                              onClick={() => handleInspectCandidate(app.candidateId?._id || (app.candidateId as any))}
                              className="text-indigo-400 hover:text-indigo-300 font-medium underline flex items-center gap-0.5"
                            >
                              <User className="w-3 h-3" /> Profile
                            </button>
                          </div>

                          {/* Action Buttons */}
                          <div className="pt-2 border-t border-slate-700/70 flex flex-col gap-1.5">
                            {canAdvance && (
                              <button
                                onClick={() => handleOpenTransition(app)}
                                className="w-full py-1 px-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded font-medium text-[11px] transition flex items-center justify-center gap-1 shadow-sm"
                              >
                                <span>Move Stage</span>
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            )}

                            {app.stage === 'Shortlisted' && onScheduleInterviewFor && (
                              <button
                                onClick={() => onScheduleInterviewFor(app)}
                                className="w-full py-1 px-2 bg-sky-950 hover:bg-sky-900 text-sky-300 border border-sky-800/60 rounded font-medium text-[10px] transition flex items-center justify-center gap-1"
                              >
                                <Calendar className="w-3 h-3" />
                                Schedule Interview
                              </button>
                            )}

                            {(app.stage === 'Interview' || app.stage === 'Offered') && onIssueOfferFor && (
                              <button
                                onClick={() => onIssueOfferFor(app)}
                                className="w-full py-1 px-2 bg-amber-950 hover:bg-amber-900 text-amber-300 border border-amber-800/60 rounded font-medium text-[10px] transition flex items-center justify-center gap-1"
                              >
                                <Award className="w-3 h-3" />
                                Issue Job Offer
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Stage Transition Modal */}
      {transitioningApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative text-slate-100">
            <button
              onClick={() => setTransitioningApp(null)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-white mb-1">
              Transition Candidate Pipeline Stage
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Moving <span className="text-white font-semibold">{transitioningApp.candidateId?.name}</span> for {transitioningApp.jobId?.title}.
            </p>

            <form onSubmit={handleExecuteTransition} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Current Stage</label>
                <div className="px-3 py-2 bg-slate-800/80 border border-slate-700 rounded-lg text-xs font-bold text-indigo-400">
                  {transitioningApp.stage}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Target Stage (Enforced Business Rules)
                </label>
                <select
                  required
                  value={targetStage}
                  onChange={(e) => setTargetStage(e.target.value as ApplicationStage)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-semibold"
                >
                  {VALID_NEXT_STAGES[transitioningApp.stage]?.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-400 mt-1">
                  Direct jumps (e.g. Applied &rarr; Hired) are strictly prohibited by server-side state machine.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Recruiter Transition Audit Note
                </label>
                <textarea
                  rows={3}
                  value={transitionNote}
                  onChange={(e) => setTransitionNote(e.target.value)}
                  placeholder="Reason or feedback for moving candidate to this stage..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setTransitioningApp(null)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingTransition || !targetStage}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow transition disabled:opacity-50 flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {submittingTransition ? 'Saving...' : `Confirm Move to ${targetStage}`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Candidate Profile Inspector Modal */}
      {inspectingCandidateId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative text-slate-100 max-h-[85vh] overflow-y-auto">
            <button
              onClick={() => {
                setInspectingCandidateId(null);
                setCandidateProfile(null);
              }}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
              <User className="w-5 h-5 text-indigo-400" />
              Candidate Verified Profile & Resume
            </h3>

            {loadingProfile ? (
              <div className="py-12 text-center text-slate-400 text-xs">Loading profile from database...</div>
            ) : !candidateProfile ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                Candidate has not submitted a complete profile yet.
              </div>
            ) : (
              <div className="space-y-4 text-xs text-slate-300 mt-4">
                <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700">
                  <div className="text-sm font-bold text-white">{candidateProfile.fullName}</div>
                  <div className="text-slate-400">{candidateProfile.location} &bull; {candidateProfile.phone}</div>
                  <div className="text-indigo-300 mt-1">
                    Industry Experience: {candidateProfile.experienceYears} Years
                  </div>
                </div>

                <div>
                  <span className="font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Skills & Competencies:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {candidateProfile.skills?.map((s, i) => (
                      <span key={i} className="px-2 py-0.5 bg-indigo-950 text-indigo-300 rounded border border-indigo-800">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                    Experience Summary:
                  </span>
                  <p className="bg-slate-800/40 p-3 rounded border border-slate-800 leading-relaxed">
                    {candidateProfile.experienceSummary}
                  </p>
                </div>

                <div>
                  <span className="font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                    Resume Bio:
                  </span>
                  <p className="bg-slate-800/40 p-3 rounded border border-slate-800 leading-relaxed">
                    {candidateProfile.resumeSummary}
                  </p>
                </div>

                {candidateProfile.education && candidateProfile.education.length > 0 && (
                  <div>
                    <span className="font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                      Academic Degrees:
                    </span>
                    <div className="space-y-2">
                      {candidateProfile.education.map((edu, i) => (
                        <div key={i} className="bg-slate-800/40 p-2.5 rounded border border-slate-800">
                          <div className="font-bold text-white">{edu.degree}</div>
                          <div className="text-slate-400">{edu.institution} &bull; Class of {edu.yearOfCompletion}</div>
                          {edu.grade && <div className="text-emerald-400 mt-0.5">{edu.grade}</div>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
