import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { JobPosting, Company } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Briefcase,
  Plus,
  Edit2,
  Trash2,
  MapPin,
  DollarSign,
  Clock,
  CheckCircle2,
  AlertTriangle,
  X,
} from 'lucide-react';

export const RecruiterJobsView: React.FC = () => {
  const { notify } = useAuth();
  const [jobs, setJobs] = useState<JobPosting[]>([]);
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);

  // Form modal state
  const [showModal, setShowModal] = useState(false);
  const [editingJob, setEditingJob] = useState<JobPosting | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [skillsStr, setSkillsStr] = useState('');
  const [location, setLocation] = useState('');
  const [employmentType, setEmploymentType] = useState('Full-time');
  const [experienceRequired, setExperienceRequired] = useState('2+ years');
  const [minSalary, setMinSalary] = useState(90000);
  const [maxSalary, setMaxSalary] = useState(130000);
  const [status, setStatus] = useState<'Draft' | 'Published' | 'Closed'>('Published');
  const [submitting, setSubmitting] = useState(false);

  const fetchJobs = async () => {
    setLoading(true);
    try {
      const [jobsRes, companyRes] = await Promise.all([
        api.jobs.getMyJobs(),
        api.company.getMyCompany(),
      ]);
      if (jobsRes.success) setJobs(jobsRes.data);
      if (companyRes.success) setCompany(companyRes.data);
    } catch (err: any) {
      notify('error', err.message || 'Failed to fetch jobs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const handleOpenCreate = () => {
    if (!company) {
      notify('error', 'Please configure your Company Profile first before posting jobs');
    }
    setEditingJob(null);
    setTitle('');
    setDescription('');
    setSkillsStr('');
    setLocation('Remote');
    setEmploymentType('Full-time');
    setExperienceRequired('2+ years');
    setMinSalary(95000);
    setMaxSalary(140000);
    setStatus('Published');
    setShowModal(true);
  };

  const handleOpenEdit = (job: JobPosting) => {
    setEditingJob(job);
    setTitle(job.title);
    setDescription(job.description);
    setSkillsStr(job.skills.join(', '));
    setLocation(job.location);
    setEmploymentType(job.employmentType);
    setExperienceRequired(job.experienceRequired);
    setMinSalary(job.salaryRange.min);
    setMaxSalary(job.salaryRange.max);
    setStatus(job.status);
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!company && !editingJob) {
      notify('error', 'Please configure your company profile first');
      return;
    }

    setSubmitting(true);
    const skills = skillsStr
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    try {
      if (editingJob) {
        await api.jobs.update(editingJob._id, {
          title,
          description,
          skills,
          location,
          employmentType: employmentType as any,
          experienceRequired,
          salaryRange: { min: Number(minSalary), max: Number(maxSalary), currency: 'USD' },
          status,
        });
        notify('success', 'Job posting updated successfully');
      } else {
        await api.jobs.create({
          companyId: company!._id,
          title,
          description,
          skills,
          location,
          employmentType: employmentType as any,
          experienceRequired,
          salaryRange: { min: Number(minSalary), max: Number(maxSalary), currency: 'USD' },
          status,
        });
        notify('success', 'New job posting published successfully');
      }
      setShowModal(false);
      fetchJobs();
    } catch (err: any) {
      notify('error', err.message || 'Failed to save job posting');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string, jobTitle: string) => {
    if (!window.confirm(`Delete job posting "${jobTitle}"? This will also remove associated applications.`))
      return;
    try {
      await api.jobs.delete(id);
      notify('info', 'Job posting deleted');
      fetchJobs();
    } catch (err: any) {
      notify('error', err.message || 'Failed to delete job');
    }
  };

  const handleQuickStatus = async (job: JobPosting, newStatus: 'Draft' | 'Published' | 'Closed') => {
    try {
      await api.jobs.update(job._id, { status: newStatus });
      notify('success', `Job status updated to ${newStatus}`);
      fetchJobs();
    } catch (err: any) {
      notify('error', err.message || 'Failed to update job status');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
            <Briefcase className="w-6 h-6 text-indigo-400" />
            Recruiter Job Postings
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Author and publish career requisitions, specify salary compensation, and manage publication states.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow flex items-center gap-1.5 transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Post New Job
        </button>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400 text-sm">Loading job requisitions...</div>
      ) : jobs.length === 0 ? (
        <div className="py-20 text-center bg-slate-900 border border-slate-800 rounded-xl p-8">
          <Briefcase className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-200">No jobs posted yet</h3>
          <p className="text-sm text-slate-400 mt-1 mb-4">
            Click &ldquo;Post New Job&rdquo; to create your first open position.
          </p>
          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium"
          >
            Create Job Now
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {jobs.map((job) => (
            <div
              key={job._id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-1.5">
                <div className="flex items-center gap-2.5">
                  <h3 className="text-base font-bold text-white">{job.title}</h3>
                  <span
                    className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                      job.status === 'Published'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : job.status === 'Draft'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {job.status}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-500" />
                    {job.location}
                  </span>
                  <span>{job.employmentType}</span>
                  <span className="text-emerald-400 font-medium">
                    ${(job.salaryRange.min / 1000).toFixed(0)}k - ${(job.salaryRange.max / 1000).toFixed(0)}k
                  </span>
                  <span>Exp: {job.experienceRequired}</span>
                </div>

                <div className="flex flex-wrap gap-1 pt-1">
                  {job.skills.map((s, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded text-[10px] border border-slate-700"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Status and Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <select
                  value={job.status}
                  onChange={(e) => handleQuickStatus(job, e.target.value as any)}
                  className="bg-slate-800 border border-slate-700 text-slate-300 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-indigo-500 font-medium"
                >
                  <option value="Draft">Draft</option>
                  <option value="Published">Published</option>
                  <option value="Closed">Closed</option>
                </select>

                <button
                  onClick={() => handleOpenEdit(job)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
                  title="Edit requisition"
                >
                  <Edit2 className="w-4 h-4" />
                </button>

                <button
                  onClick={() => handleDelete(job._id, job.title)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-rose-400 border border-slate-700 transition"
                  title="Delete requisition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Job Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative text-slate-100 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-1">
              {editingJob ? 'Edit Job Requisition' : 'Post New Job Requisition'}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Company: <span className="text-indigo-300 font-semibold">{company?.name || 'Your Company'}</span>
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Job Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Senior Full Stack Engineer (MERN)"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Location</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Remote or Austin, TX"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Employment Type</label>
                  <select
                    value={employmentType}
                    onChange={(e) => setEmploymentType(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                    <option value="Contract">Contract</option>
                    <option value="Internship">Internship</option>
                    <option value="Remote">Remote</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Exp Required</label>
                  <input
                    type="text"
                    placeholder="e.g. 2+ years"
                    value={experienceRequired}
                    onChange={(e) => setExperienceRequired(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Min Salary ($/yr)</label>
                  <input
                    type="number"
                    required
                    step="1000"
                    value={minSalary}
                    onChange={(e) => setMinSalary(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Max Salary ($/yr)</label>
                  <input
                    type="number"
                    required
                    step="1000"
                    value={maxSalary}
                    onChange={(e) => setMaxSalary(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Publish Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-medium"
                  >
                    <option value="Published">Published</option>
                    <option value="Draft">Draft</option>
                    <option value="Closed">Closed</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Required Skills (comma-separated)
                </label>
                <input
                  type="text"
                  required
                  placeholder="React, TypeScript, Node.js, Express, MongoDB"
                  value={skillsStr}
                  onChange={(e) => setSkillsStr(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Detailed Job Description & Requirements
                </label>
                <textarea
                  rows={6}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Outline core responsibilities, qualifications, team expectations..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-indigo-500 leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white text-xs font-medium transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow transition disabled:opacity-50"
                >
                  {submitting ? 'Saving...' : editingJob ? 'Update Requisition' : 'Publish Requisition'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
