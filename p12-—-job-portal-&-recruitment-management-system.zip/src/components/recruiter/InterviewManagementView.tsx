import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Interview, Application } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Calendar,
  Plus,
  Video,
  Clock,
  CheckCircle2,
  XCircle,
  MessageSquare,
  User,
  X,
  Building2,
} from 'lucide-react';

interface InterviewManagementViewProps {
  preselectedApp?: Application | null;
  onClearPreselectedApp?: () => void;
}

export const InterviewManagementView: React.FC<InterviewManagementViewProps> = ({
  preselectedApp,
  onClearPreselectedApp,
}) => {
  const { user, notify } = useAuth();
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);

  // Schedule modal
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [selectedAppId, setSelectedAppId] = useState('');
  const [scheduledAt, setScheduledAt] = useState('');
  const [mode, setMode] = useState<'Online' | 'In-Person'>('Online');
  const [meetingLink, setMeetingLink] = useState('https://meet.google.com/cia3-interview-round');
  const [interviewer, setInterviewer] = useState(user?.name || 'Technical Hiring Panel');
  const [submitting, setSubmitting] = useState(false);

  // Feedback modal
  const [editingInterview, setEditingInterview] = useState<Interview | null>(null);
  const [feedbackStatus, setFeedbackStatus] = useState<'Scheduled' | 'Completed' | 'Cancelled'>('Completed');
  const [feedbackText, setFeedbackText] = useState('');

  const loadData = async () => {
    setLoading(true);
    try {
      const [invRes, appsRes] = await Promise.all([
        api.interviews.getMyInterviews(),
        api.applications.getAllRecruiterApplicants(),
      ]);
      if (invRes.success) setInterviews(invRes.data);
      if (appsRes.success) {
        // eligible candidates are those in Shortlisted or Interview stage
        setApplications(appsRes.data.filter((a) => a.stage === 'Shortlisted' || a.stage === 'Interview'));
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to load interviews');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (preselectedApp) {
      setSelectedAppId(preselectedApp._id);
      setShowScheduleModal(true);
    }
  }, [preselectedApp]);

  const handleOpenSchedule = () => {
    if (applications.length === 0) {
      notify('info', 'No candidates in Shortlisted or Interview stage to schedule');
    }
    const defaultDate = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().slice(0, 16);
    setScheduledAt(defaultDate);
    if (!selectedAppId && applications.length > 0) {
      setSelectedAppId(applications[0]._id);
    }
    setShowScheduleModal(true);
  };

  const handleScheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAppId) {
      notify('error', 'Please select an eligible candidate application');
      return;
    }
    setSubmitting(true);
    try {
      await api.interviews.schedule({
        applicationId: selectedAppId,
        scheduledAt,
        mode,
        meetingLinkOrLocation: meetingLink,
        interviewer,
      });
      notify('success', 'Interview session scheduled successfully!');
      setShowScheduleModal(false);
      if (onClearPreselectedApp) onClearPreselectedApp();
      loadData();
    } catch (err: any) {
      notify('error', err.message || 'Failed to schedule interview');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenFeedback = (inv: Interview) => {
    setEditingInterview(inv);
    setFeedbackStatus(inv.status);
    setFeedbackText(inv.feedback || '');
  };

  const handleSaveFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingInterview) return;
    try {
      await api.interviews.updateFeedback(editingInterview._id, feedbackStatus, feedbackText);
      notify('success', 'Interview feedback updated successfully');
      setEditingInterview(null);
      loadData();
    } catch (err: any) {
      notify('error', err.message || 'Failed to update feedback');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
            <Calendar className="w-6 h-6 text-indigo-400" />
            Recruiter Interview Schedule & Evaluation
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Coordinate technical panels, virtual meetings, and record structured evaluation feedback.
          </p>
        </div>

        <button
          onClick={handleOpenSchedule}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow flex items-center gap-1.5 transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Schedule New Interview
        </button>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400 text-sm">Loading interview calendar...</div>
      ) : interviews.length === 0 ? (
        <div className="py-20 text-center bg-slate-900 border border-slate-800 rounded-xl p-8">
          <Calendar className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-200">No interviews scheduled yet</h3>
          <p className="text-sm text-slate-400 mt-1 mb-4">
            Select shortlisted candidates in your pipeline to schedule technical rounds.
          </p>
          <button
            onClick={handleOpenSchedule}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium"
          >
            Schedule Interview
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {interviews.map((inv) => (
            <div
              key={inv._id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-bold text-white">
                      {inv.candidateId?.name}
                    </h3>
                    <p className="text-xs text-indigo-300 font-medium mt-0.5">
                      {inv.jobId?.title}
                    </p>
                    <p className="text-xs text-slate-400">{inv.candidateId?.email}</p>
                  </div>

                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                      inv.status === 'Completed'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : inv.status === 'Cancelled'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : 'bg-sky-950 text-sky-300 border border-sky-800'
                    }`}
                  >
                    {inv.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-300 pt-3 border-t border-slate-800/80">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>
                      {new Date(inv.scheduledAt).toLocaleString(undefined, {
                        dateStyle: 'medium',
                        timeStyle: 'short',
                      })}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span>Interviewer: {inv.interviewer}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Video className="w-3.5 h-3.5 text-slate-400" />
                    <span>{inv.mode}: </span>
                    <span className="text-indigo-300 truncate font-mono">{inv.meetingLinkOrLocation}</span>
                  </div>
                </div>

                {inv.feedback && (
                  <div className="mt-3 bg-slate-800/50 p-3 rounded-lg border border-slate-800 text-xs text-slate-300">
                    <div className="font-semibold text-slate-400 uppercase text-[10px] mb-1">
                      Panel Evaluation Notes:
                    </div>
                    <p className="italic leading-relaxed">{inv.feedback}</p>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end">
                <button
                  onClick={() => handleOpenFeedback(inv)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition flex items-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  Update Status & Feedback
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Schedule Interview Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative text-slate-100">
            <button
              onClick={() => {
                setShowScheduleModal(false);
                if (onClearPreselectedApp) onClearPreselectedApp();
              }}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-white mb-1">Schedule Candidate Interview</h3>
            <p className="text-xs text-slate-400 mb-4">
              Create calendar meeting and update candidate pipeline.
            </p>

            <form onSubmit={handleScheduleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Target Candidate & Job
                </label>
                <select
                  required
                  value={selectedAppId}
                  onChange={(e) => setSelectedAppId(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="">Select an applicant</option>
                  {applications.map((a) => (
                    <option key={a._id} value={a._id}>
                      {a.candidateId?.name} — {a.jobId?.title} ({a.stage})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Scheduled Date & Time
                </label>
                <input
                  type="datetime-local"
                  required
                  value={scheduledAt}
                  onChange={(e) => setScheduledAt(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Interview Mode</label>
                  <select
                    value={mode}
                    onChange={(e) => setMode(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Online">Online Video</option>
                    <option value="In-Person">In-Person</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Interviewer Name</label>
                  <input
                    type="text"
                    required
                    value={interviewer}
                    onChange={(e) => setInterviewer(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Meeting Link or Physical Venue
                </label>
                <input
                  type="text"
                  required
                  value={meetingLink}
                  onChange={(e) => setMeetingLink(e.target.value)}
                  placeholder="https://meet.google.com/xyz or Room 402"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowScheduleModal(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow transition disabled:opacity-50"
                >
                  {submitting ? 'Scheduling...' : 'Confirm Schedule'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Update Feedback Modal */}
      {editingInterview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative text-slate-100">
            <button
              onClick={() => setEditingInterview(null)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-white mb-1">Record Interview Feedback</h3>
            <p className="text-xs text-slate-400 mb-4">
              For candidate <span className="text-white font-semibold">{editingInterview.candidateId?.name}</span>
            </p>

            <form onSubmit={handleSaveFeedback} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Interview Status</label>
                <select
                  value={feedbackStatus}
                  onChange={(e) => setFeedbackStatus(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-medium"
                >
                  <option value="Scheduled">Scheduled</option>
                  <option value="Completed">Completed</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Panel Evaluation Notes & Ratings
                </label>
                <textarea
                  rows={4}
                  required
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  placeholder="Strong system design performance, solved binary search problem cleanly..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingInterview(null)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow transition"
                >
                  Save Evaluation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
