import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { OfferItem, Interview } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Award,
  Calendar,
  DollarSign,
  CheckCircle2,
  XCircle,
  Clock,
  Video,
  Building2,
  MapPin,
  ExternalLink,
  PartyPopper,
} from 'lucide-react';

export const OffersAndInterviewsView: React.FC = () => {
  const { notify } = useAuth();
  const [offers, setOffers] = useState<OfferItem[]>([]);
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [loading, setLoading] = useState(true);
  const [respondingId, setRespondingId] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const [offersRes, interviewsRes] = await Promise.all([
        api.offers.getMyOffers(),
        api.interviews.getMyInterviews(),
      ]);
      if (offersRes.success) setOffers(offersRes.data);
      if (interviewsRes.success) setInterviews(interviewsRes.data);
    } catch (err: any) {
      notify('error', err.message || 'Failed to load offers and interviews');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRespondToOffer = async (id: string, action: 'accept' | 'decline') => {
    if (
      !window.confirm(
        `Are you sure you want to ${action.toUpperCase()} this job offer? ${
          action === 'accept' ? 'Your recruitment stage will instantly advance to Hired!' : ''
        }`
      )
    )
      return;

    setRespondingId(id);
    try {
      const res = await api.offers.respond(id, action);
      notify('success', res.message);
      loadData();
    } catch (err: any) {
      notify('error', err.message || 'Failed to respond to offer');
    } finally {
      setRespondingId(null);
    }
  };

  if (loading) {
    return <div className="py-20 text-center text-slate-400 text-sm">Loading offers and interviews...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Employment Offers & Interview Schedule
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Review formal offer letters extended by employers and view upcoming technical interview rounds.
        </p>
      </div>

      {/* Section 1: Formal Employment Offers */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Award className="w-5 h-5 text-indigo-400" />
          <h2 className="text-lg font-bold text-white">Formal Job Offers</h2>
        </div>

        {offers.length === 0 ? (
          <p className="text-slate-400 text-xs py-4 italic">
            No formal job offers have been issued to your account yet. Complete technical interviews to receive offer letters.
          </p>
        ) : (
          <div className="space-y-4">
            {offers.map((offer) => {
              const isAccepted = offer.offerStatus === 'Accepted';
              const isDeclined = offer.offerStatus === 'Declined';
              const isPending = offer.offerStatus === 'Sent';

              return (
                <div
                  key={offer._id}
                  className={`border rounded-xl p-5 shadow-sm transition ${
                    isAccepted
                      ? 'bg-emerald-950/20 border-emerald-800/60'
                      : isDeclined
                      ? 'bg-rose-950/10 border-rose-900/50'
                      : 'bg-slate-800/40 border-slate-700'
                  }`}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                    <div>
                      <div className="flex items-center gap-3">
                        <h3 className="text-lg font-bold text-white">{offer.position}</h3>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                            isAccepted
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : isDeclined
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 animate-pulse'
                          }`}
                        >
                          {offer.offerStatus}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                        <span>Organization: {offer.jobId?.companyId?.name || 'Hiring Employer'}</span>
                        <span>&bull;</span>
                        <span>Offered By: {offer.recruiterId?.name}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {isPending && (
                        <>
                          <button
                            onClick={() => handleRespondToOffer(offer._id, 'decline')}
                            disabled={respondingId === offer._id}
                            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-rose-400 border border-slate-700 text-xs font-semibold rounded-lg transition"
                          >
                            Decline
                          </button>
                          <button
                            onClick={() => handleRespondToOffer(offer._id, 'accept')}
                            disabled={respondingId === offer._id}
                            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow transition flex items-center gap-1.5"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            Accept Job Offer
                          </button>
                        </>
                      )}
                      {isAccepted && (
                        <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5 bg-emerald-950/60 px-3 py-1.5 rounded-lg border border-emerald-800/60">
                          <CheckCircle2 className="w-4 h-4" />
                          Accepted &bull; Officially Hired!
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Compensation & Joining Info */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 text-xs">
                    <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block mb-1">Offered Compensation</span>
                      <span className="text-base font-bold text-emerald-400 flex items-center">
                        <DollarSign className="w-4 h-4" />
                        {offer.salary?.toLocaleString()} {offer.currency} / year
                      </span>
                    </div>

                    <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block mb-1">Scheduled Joining Date</span>
                      <span className="text-sm font-semibold text-white flex items-center gap-1.5">
                        <Calendar className="w-4 h-4 text-indigo-400" />
                        {new Date(offer.joiningDate).toLocaleDateString(undefined, {
                          month: 'long',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </span>
                    </div>

                    <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block mb-1">Recruiter Offer Notes</span>
                      <span className="text-slate-300 italic line-clamp-2">
                        {offer.notes || 'Full standard corporate benefits package included.'}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Section 2: Scheduled Interviews */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Calendar className="w-5 h-5 text-indigo-400" />
          <h2 className="text-lg font-bold text-white">Scheduled Technical Interviews</h2>
        </div>

        {interviews.length === 0 ? (
          <p className="text-slate-400 text-xs py-4 italic">
            No technical interviews currently on your calendar.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {interviews.map((inv) => (
              <div
                key={inv._id}
                className="bg-slate-800/40 border border-slate-800 p-5 rounded-xl flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <h4 className="text-sm font-bold text-white">{inv.jobId?.title}</h4>
                      <p className="text-xs text-slate-400">{inv.interviewer}</p>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                        inv.status === 'Completed'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : inv.status === 'Cancelled'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : 'bg-sky-950 text-sky-300 border border-sky-800'
                      }`}
                    >
                      {inv.status}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-300 my-3">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>
                        {new Date(inv.scheduledAt).toLocaleString(undefined, {
                          dateStyle: 'medium',
                          timeStyle: 'short',
                        })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Video className="w-3.5 h-3.5 text-slate-400" />
                      <span>Mode: {inv.mode}</span>
                    </div>
                    <div className="text-xs text-indigo-300 truncate bg-slate-900 px-2.5 py-1.5 rounded border border-slate-800">
                      Link / Venue: {inv.meetingLinkOrLocation}
                    </div>
                  </div>

                  {inv.feedback && (
                    <div className="bg-slate-900/60 p-2.5 rounded text-xs text-slate-300 border border-slate-800/60 mt-2">
                      <span className="font-semibold text-slate-400 block text-[10px] uppercase">Feedback:</span>
                      {inv.feedback}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
