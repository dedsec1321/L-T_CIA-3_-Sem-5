import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { JobPosting } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Search,
  MapPin,
  Briefcase,
  DollarSign,
  Bookmark,
  Send,
  CheckCircle2,
  Clock,
  Building2,
  Filter,
  X,
} from 'lucide-react';

export const JobBoardView: React.FC = () => {
  const { user, notify } = useAuth();
  const [jobs, setJobs] = useState<JobPosting[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [location, setLocation] = useState('');
  const [employmentType, setEmploymentType] = useState('All');
  const [sortBy, setSortBy] = useState('newest');
  const [selectedJob, setSelectedJob] = useState<JobPosting | null>(null);
  const [applyingJob, setApplyingJob] = useState<JobPosting | null>(null);
  const [coverNote, setCoverNote] = useState('');
  const [submittingApply, setSubmittingApply] = useState(false);
  const [savedJobIds, setSavedJobIds] = useState<Set<string>>(new Set());

  const fetchJobs = async () => {
    setLoading(true);
    try {
      const res = await api.jobs.list({
        search,
        location,
        employmentType: employmentType !== 'All' ? employmentType : undefined,
        sortBy,
      });
      if (res.success) {
        setJobs(res.data);
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to fetch job postings');
    } finally {
      setLoading(false);
    }
  };

  const fetchSavedJobs = async () => {
    if (!user || user.role !== 'Candidate') return;
    try {
      const res = await api.savedJobs.list();
      if (res.success) {
        const ids = new Set(res.data.map((item) => (typeof item.jobId === 'object' ? item.jobId._id : item.jobId)));
        setSavedJobIds(ids);
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetchJobs();
    fetchSavedJobs();
  }, [search, location, employmentType, sortBy]);

  const handleToggleSave = async (jobId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      notify('info', 'Please sign in as Candidate to save jobs');
      return;
    }
    const isSaved = savedJobIds.has(jobId);
    try {
      if (isSaved) {
        await api.savedJobs.unsave(jobId);
        setSavedJobIds((prev) => {
          const next = new Set(prev);
          next.delete(jobId);
          return next;
        });
        notify('info', 'Job removed from saved list');
      } else {
        await api.savedJobs.save(jobId);
        setSavedJobIds((prev) => new Set(prev).add(jobId));
        notify('success', 'Job bookmarked successfully');
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to update saved job');
    }
  };

  const handleApplySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!applyingJob) return;
    setSubmittingApply(true);
    try {
      await api.applications.apply(applyingJob._id, coverNote);
      notify('success', `Application submitted successfully for ${applyingJob.title}!`);
      setApplyingJob(null);
      setCoverNote('');
      fetchJobs();
    } catch (err: any) {
      notify('error', err.message || 'Failed to submit application');
    } finally {
      setSubmittingApply(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Header Banner */}
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Explore Job Opportunities
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Search real open positions across verified tech employers, submit applications, and track progress.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6 shadow-sm">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Keyword Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Job title, skills (e.g. React, MERN)"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Location filter */}
          <div className="relative">
            <MapPin className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Location (e.g. Remote, SF, Austin)"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Employment Type */}
          <div className="relative">
            <select
              value={employmentType}
              onChange={(e) => setEmploymentType(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="All">All Employment Types</option>
              <option value="Full-time">Full-time</option>
              <option value="Part-time">Part-time</option>
              <option value="Contract">Contract</option>
              <option value="Internship">Internship</option>
              <option value="Remote">Remote</option>
            </select>
          </div>

          {/* Sort By */}
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="newest">Sort: Newest First</option>
              <option value="salary">Sort: Salary (High to Low)</option>
              <option value="experience">Sort: Experience (Low to High)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Grid: Job Cards */}
      {loading ? (
        <div className="py-20 text-center text-slate-400 text-sm">Loading active job listings...</div>
      ) : jobs.length === 0 ? (
        <div className="py-20 text-center bg-slate-900 border border-slate-800 rounded-xl p-8">
          <Briefcase className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-200">No matching job listings found</h3>
          <p className="text-sm text-slate-400 mt-1">
            Try adjusting your search keywords, location filters, or employment criteria.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {jobs.map((job) => {
            const isSaved = savedJobIds.has(job._id);
            return (
              <div
                key={job._id}
                onClick={() => setSelectedJob(job)}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-5 shadow-sm transition hover:shadow-md cursor-pointer flex flex-col justify-between group relative"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-start gap-3">
                      {job.companyId?.logoUrl ? (
                        <img
                          src={job.companyId.logoUrl}
                          alt={job.companyId.name}
                          className="w-10 h-10 rounded-lg object-cover border border-slate-700 shrink-0"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-lg bg-indigo-950 border border-indigo-800/60 flex items-center justify-center shrink-0 text-indigo-300 font-bold text-sm">
                          {job.companyId?.name?.charAt(0) || 'C'}
                        </div>
                      )}
                      <div>
                        <h3 className="text-base font-semibold text-white group-hover:text-indigo-300 transition">
                          {job.title}
                        </h3>
                        <p className="text-xs text-slate-400 font-medium">
                          {job.companyId?.name || 'Company Confirmed'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => handleToggleSave(job._id, e)}
                      title={isSaved ? 'Remove from saved' : 'Save job'}
                      className={`p-2 rounded-lg border transition ${
                        isSaved
                          ? 'bg-amber-950/40 border-amber-600/60 text-amber-400'
                          : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                    </button>
                  </div>

                  <p className="text-xs text-slate-300 line-clamp-2 my-3 leading-relaxed">
                    {job.description}
                  </p>

                  {/* Badges & Meta */}
                  <div className="flex flex-wrap items-center gap-2 mb-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {job.location}
                    </span>
                    <span className="flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                      <Briefcase className="w-3 h-3 text-slate-400" />
                      {job.employmentType}
                    </span>
                    <span className="flex items-center gap-1 bg-emerald-950/40 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800/40 font-medium">
                      <DollarSign className="w-3 h-3 text-emerald-400" />
                      ${(job.salaryRange.min / 1000).toFixed(0)}k - ${(job.salaryRange.max / 1000).toFixed(0)}k
                    </span>
                  </div>

                  {/* Skills tags */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {job.skills.map((skill, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] bg-slate-800/60 text-slate-300 px-2 py-0.5 rounded border border-slate-700"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-800/80 text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    Exp: {job.experienceRequired}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedJob(job);
                      }}
                      className="px-2.5 py-1 text-slate-300 hover:text-white text-xs font-medium"
                    >
                      View Details
                    </button>
                    {user?.role === 'Candidate' && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setApplyingJob(job);
                        }}
                        className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium transition flex items-center gap-1 shadow-sm"
                      >
                        <Send className="w-3 h-3" />
                        Apply
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Job Details Modal */}
      {selectedJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative text-slate-100 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedJob(null)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-start gap-4 mb-6">
              {selectedJob.companyId?.logoUrl ? (
                <img
                  src={selectedJob.companyId.logoUrl}
                  alt={selectedJob.companyId.name}
                  className="w-14 h-14 rounded-xl object-cover border border-slate-700 shrink-0"
                />
              ) : (
                <div className="w-14 h-14 rounded-xl bg-indigo-950 border border-indigo-800/60 flex items-center justify-center shrink-0 text-indigo-300 font-bold text-lg">
                  {selectedJob.companyId?.name?.charAt(0) || 'C'}
                </div>
              )}
              <div>
                <h2 className="text-xl font-bold text-white">{selectedJob.title}</h2>
                <p className="text-sm text-slate-400">{selectedJob.companyId?.name}</p>
                <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {selectedJob.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                    {selectedJob.employmentType}
                  </span>
                  <span className="text-emerald-400 font-medium">
                    ${selectedJob.salaryRange.min.toLocaleString()} - ${selectedJob.salaryRange.max.toLocaleString()} USD
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-4 text-sm text-slate-300 mb-6">
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  Job Description & Responsibilities
                </h4>
                <p className="leading-relaxed bg-slate-800/40 p-3.5 rounded-xl border border-slate-800 whitespace-pre-line">
                  {selectedJob.description}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  Required Technologies & Skills
                </h4>
                <div className="flex flex-wrap gap-2">
                  {selectedJob.skills.map((skill, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 bg-indigo-950/60 border border-indigo-800/60 text-indigo-200 text-xs rounded-lg font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {selectedJob.companyId?.description && (
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                    About {selectedJob.companyId.name}
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed bg-slate-800/40 p-3.5 rounded-xl border border-slate-800">
                    {selectedJob.companyId.description}
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setSelectedJob(null)}
                className="px-4 py-2 text-slate-400 hover:text-white text-sm font-medium transition"
              >
                Close
              </button>
              {user?.role === 'Candidate' && (
                <button
                  type="button"
                  onClick={() => {
                    setApplyingJob(selectedJob);
                    setSelectedJob(null);
                  }}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-medium shadow flex items-center gap-2 transition"
                >
                  <Send className="w-4 h-4" />
                  Apply for Position
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Apply Modal */}
      {applyingJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative text-slate-100">
            <button
              onClick={() => setApplyingJob(null)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-1">
              Apply for {applyingJob.title}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              At {applyingJob.companyId?.name}. Your Candidate profile details and resume summary will be included automatically.
            </p>

            <form onSubmit={handleApplySubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Candidate Note / Cover Letter (Optional)
                </label>
                <textarea
                  rows={4}
                  value={coverNote}
                  onChange={(e) => setCoverNote(e.target.value)}
                  placeholder="Introduce yourself, mention key relevant projects or why you're a great fit for this team..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="bg-slate-800/40 border border-slate-800 p-3 rounded-lg text-xs text-slate-400 space-y-1">
                <div className="font-semibold text-slate-300">Application Snapshot:</div>
                <div>&bull; Applicant: {user?.name} ({user?.email})</div>
                <div>&bull; Initial Pipeline Stage: Applied</div>
                <div>&bull; Enforces duplicate prevention (1 application per job)</div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setApplyingJob(null)}
                  className="px-4 py-2 text-slate-400 hover:text-white text-xs font-medium transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingApply}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium shadow flex items-center gap-2 transition disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  {submittingApply ? 'Submitting...' : 'Confirm & Submit Application'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
