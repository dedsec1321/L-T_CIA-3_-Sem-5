import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Application, ApplicationStage } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  FileText,
  Clock,
  Building2,
  MapPin,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  History,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

const STAGES: ApplicationStage[] = ['Applied', 'Shortlisted', 'Interview', 'Offered', 'Hired'];

export const MyApplicationsView: React.FC = () => {
  const { notify } = useAuth();
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchApplications = async () => {
    setLoading(true);
    try {
      const res = await api.applications.getMyApplications();
      if (res.success) {
        setApplications(res.data);
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to fetch applications');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const handleWithdraw = async (id: string, jobTitle: string) => {
    if (!window.confirm(`Are you sure you want to withdraw your application for "${jobTitle}"?`)) return;
    try {
      await api.applications.withdraw(id);
      notify('info', 'Application withdrawn successfully');
      fetchApplications();
    } catch (err: any) {
      notify('error', err.message || 'Failed to withdraw application');
    }
  };

  const getStageIndex = (stage: ApplicationStage): number => {
    if (stage === 'Rejected') return -1;
    return STAGES.indexOf(stage);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          My Applications & Pipeline Status
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Monitor your real-time recruitment progression across applicant review, technical interviews, and job offers.
        </p>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400 text-sm">Loading applications...</div>
      ) : applications.length === 0 ? (
        <div className="py-20 text-center bg-slate-900 border border-slate-800 rounded-xl p-8">
          <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-200">No applications submitted yet</h3>
          <p className="text-sm text-slate-400 mt-1">
            Browse the active job board to apply for open positions.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {applications.map((app) => {
            const isExpanded = expandedId === app._id;
            const isRejected = app.stage === 'Rejected';
            const isWithdrawn = app.status === 'Withdrawn';
            const currentIndex = getStageIndex(app.stage);

            return (
              <div
                key={app._id}
                className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm hover:border-slate-700 transition"
              >
                {/* Header row */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-bold text-white">
                        {app.jobId?.title || 'Position'}
                      </h3>
                      {isWithdrawn && (
                        <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-800 text-slate-400 border border-slate-700">
                          Withdrawn
                        </span>
                      )}
                      {isRejected && (
                        <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-950 text-rose-300 border border-rose-800">
                          Rejected
                        </span>
                      )}
                      {app.stage === 'Hired' && (
                        <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Hired
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5 text-slate-400" />
                        {app.jobId?.companyId?.name || 'Company'}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {app.jobId?.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        Applied: {new Date(app.appliedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {!isWithdrawn && app.stage !== 'Hired' && !isRejected && (
                      <button
                        onClick={() => handleWithdraw(app._id, app.jobId?.title || 'Position')}
                        className="px-3 py-1.5 text-xs font-medium text-rose-300 hover:text-rose-200 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/40 rounded-lg transition"
                      >
                        Withdraw
                      </button>
                    )}
                    <button
                      onClick={() => setExpandedId(isExpanded ? null : app._id)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition flex items-center gap-1"
                    >
                      <span>Timeline & Notes</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* Pipeline Progression Bar */}
                <div className="py-5">
                  <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                    Recruitment Pipeline Status:
                  </div>

                  {isRejected ? (
                    <div className="p-3 rounded-lg bg-rose-950/30 border border-rose-800/50 flex items-center gap-2 text-rose-300 text-xs">
                      <XCircle className="w-4 h-4 shrink-0 text-rose-400" />
                      <span>This application was reviewed and marked as Rejected by the hiring team.</span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-5 gap-2 relative">
                      {STAGES.map((step, idx) => {
                        const isDone = currentIndex >= idx;
                        const isCurrent = currentIndex === idx;

                        return (
                          <div key={step} className="flex flex-col items-center text-center relative">
                            {/* Circle Indicator */}
                            <div
                              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition border z-10 ${
                                isCurrent
                                  ? 'bg-indigo-600 text-white border-indigo-400 ring-4 ring-indigo-500/20 shadow-md'
                                  : isDone
                                  ? 'bg-emerald-600 text-white border-emerald-400'
                                  : 'bg-slate-800 text-slate-500 border-slate-700'
                              }`}
                            >
                              {isDone && !isCurrent ? (
                                <CheckCircle2 className="w-4 h-4" />
                              ) : (
                                idx + 1
                              )}
                            </div>

                            <span
                              className={`text-[11px] mt-2 font-medium ${
                                isCurrent
                                  ? 'text-indigo-400 font-bold'
                                  : isDone
                                  ? 'text-slate-200'
                                  : 'text-slate-500'
                              }`}
                            >
                              {step}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Expanded Stage History and Notes */}
                {isExpanded && (
                  <div className="mt-2 pt-4 border-t border-slate-800/80 bg-slate-950/40 p-4 rounded-xl border">
                    <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">
                      <History className="w-4 h-4 text-indigo-400" />
                      Stage Transition History & Notes (Real MongoDB Audit Log)
                    </div>

                    {app.coverNote && (
                      <div className="mb-4 bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs">
                        <span className="font-semibold text-slate-400 block mb-1">Your Submission Note:</span>
                        <p className="text-slate-300 leading-relaxed italic">{app.coverNote}</p>
                      </div>
                    )}

                    <div className="space-y-3">
                      {app.stageHistory?.map((hist, idx) => (
                        <div key={idx} className="flex items-start gap-3 text-xs border-l-2 border-indigo-700/60 pl-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-white px-2 py-0.5 rounded bg-indigo-950/80 text-indigo-300 border border-indigo-800/60 text-[11px]">
                                {hist.stage}
                              </span>
                              <span className="text-slate-400 text-[11px]">
                                {new Date(hist.changedAt).toLocaleString()}
                              </span>
                            </div>
                            {hist.note && (
                              <p className="text-slate-300 mt-1 leading-relaxed">{hist.note}</p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
