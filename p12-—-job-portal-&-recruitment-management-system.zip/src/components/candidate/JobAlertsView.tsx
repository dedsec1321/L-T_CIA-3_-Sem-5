import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { JobAlertItem, SavedJobItem, JobPosting } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Bell,
  Bookmark,
  Plus,
  Trash2,
  Briefcase,
  MapPin,
  Sparkles,
  ExternalLink,
  CheckCircle2,
} from 'lucide-react';

export const JobAlertsView: React.FC = () => {
  const { notify } = useAuth();
  const [alerts, setAlerts] = useState<JobAlertItem[]>([]);
  const [savedJobs, setSavedJobs] = useState<SavedJobItem[]>([]);
  const [matchingJobs, setMatchingJobs] = useState<JobPosting[]>([]);
  const [loading, setLoading] = useState(true);

  // New alert form state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [title, setTitle] = useState('');
  const [keywords, setKeywords] = useState('');
  const [skills, setSkills] = useState('');
  const [location, setLocation] = useState('');
  const [employmentType, setEmploymentType] = useState('Any');
  const [creating, setCreating] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [alertsRes, savedRes, matchRes] = await Promise.all([
        api.jobAlerts.list(),
        api.savedJobs.list(),
        api.jobAlerts.matches(),
      ]);
      if (alertsRes.success) setAlerts(alertsRes.data);
      if (savedRes.success) setSavedJobs(savedRes.data);
      if (matchRes.success) setMatchingJobs(matchRes.data);
    } catch (err: any) {
      notify('error', err.message || 'Failed to load saved items and alerts');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    try {
      await api.jobAlerts.create({
        title,
        keywords,
        skills,
        location,
        employmentType,
      });
      notify('success', 'Job alert preference created successfully!');
      setShowCreateModal(false);
      setTitle('');
      setKeywords('');
      setSkills('');
      setLocation('');
      setEmploymentType('Any');
      loadData();
    } catch (err: any) {
      notify('error', err.message || 'Failed to create job alert');
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteAlert = async (id: string) => {
    try {
      await api.jobAlerts.delete(id);
      notify('info', 'Job alert deleted');
      setAlerts((prev) => prev.filter((a) => a._id !== id));
      // Refresh matches
      const matchRes = await api.jobAlerts.matches();
      if (matchRes.success) setMatchingJobs(matchRes.data);
    } catch (err: any) {
      notify('error', err.message || 'Failed to delete alert');
    }
  };

  const handleUnsaveJob = async (jobId: string) => {
    try {
      await api.savedJobs.unsave(jobId);
      notify('info', 'Job removed from saved list');
      setSavedJobs((prev) =>
        prev.filter((item) => (typeof item.jobId === 'object' ? item.jobId._id : item.jobId) !== jobId)
      );
    } catch (err: any) {
      notify('error', err.message || 'Failed to remove saved job');
    }
  };

  if (loading) {
    return <div className="py-20 text-center text-slate-400 text-sm">Loading saved jobs & alerts...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Saved Jobs & Smart Alerts
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Configure automated career notifications and track bookmarked positions.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-medium shadow flex items-center gap-2 self-start sm:self-auto transition"
        >
          <Plus className="w-4 h-4" />
          Create Job Alert
        </button>
      </div>

      {/* Section 1: Active Job Alerts */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Bell className="w-5 h-5 text-indigo-400" />
          <h2 className="text-lg font-bold text-white">Configured Job Alerts</h2>
        </div>

        {alerts.length === 0 ? (
          <p className="text-slate-400 text-xs py-4 italic">
            No job alerts configured. Click &quot;Create Job Alert&quot; to set skill and location preferences.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {alerts.map((alert) => (
              <div
                key={alert._id}
                className="bg-slate-800/50 border border-slate-800 p-4 rounded-xl flex items-start justify-between gap-3"
              >
                <div>
                  <h4 className="text-sm font-semibold text-white mb-1">{alert.title}</h4>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {alert.keywords?.map((k, i) => (
                      <span key={i} className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                        {k}
                      </span>
                    ))}
                    {alert.skills?.map((s, i) => (
                      <span key={i} className="text-[10px] bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded border border-indigo-800">
                        {s}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400">
                    {alert.location && <span>Location: {alert.location}</span>}
                    {alert.employmentType && <span>Type: {alert.employmentType}</span>}
                  </div>
                </div>

                <button
                  onClick={() => handleDeleteAlert(alert._id)}
                  className="text-slate-500 hover:text-rose-400 transition p-1"
                  title="Delete alert"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Section 2: Real Matching Jobs based on Alerts */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-bold text-white">Live Matching Jobs for Your Alerts</h2>
        </div>
        <p className="text-xs text-slate-400 mb-4">
          Filtered dynamically from MongoDB based on your active alert skills and keywords.
        </p>

        {matchingJobs.length === 0 ? (
          <p className="text-slate-400 text-xs py-4 italic">
            No current job postings match your active alert preferences.
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {matchingJobs.map((job) => (
              <div
                key={job._id}
                className="bg-slate-800/40 border border-slate-800 hover:border-slate-700 p-4 rounded-xl transition"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-semibold text-white">{job.title}</h4>
                    <p className="text-xs text-slate-400 mt-0.5">{job.companyId?.name}</p>
                  </div>
                  <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-medium">
                    ${(job.salaryRange.min / 1000).toFixed(0)}k - ${(job.salaryRange.max / 1000).toFixed(0)}k
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-400 mt-2">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-500" />
                    {job.location}
                  </span>
                  <span>{job.employmentType}</span>
                </div>

                <div className="flex flex-wrap gap-1 mt-3">
                  {job.skills.map((skill, i) => (
                    <span key={i} className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Section 3: Saved / Bookmarked Jobs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Bookmark className="w-5 h-5 text-amber-400 fill-current" />
          <h2 className="text-lg font-bold text-white">Bookmarked Jobs</h2>
        </div>

        {savedJobs.length === 0 ? (
          <p className="text-slate-400 text-xs py-4 italic">
            You haven&apos;t bookmarked any jobs yet. Browse the job board and click the bookmark icon on any job card.
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {savedJobs.map((item) => {
              const job = item.jobId;
              if (!job) return null;
              return (
                <div
                  key={item._id}
                  className="bg-slate-800/40 border border-slate-800 p-4 rounded-xl flex items-start justify-between gap-3"
                >
                  <div>
                    <h4 className="text-sm font-semibold text-white">{job.title}</h4>
                    <p className="text-xs text-slate-400 mt-0.5">{job.companyId?.name}</p>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {job.location}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleUnsaveJob(job._id)}
                    className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-rose-400 border border-slate-700 transition"
                    title="Remove bookmark"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Create Alert Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative text-slate-100">
            <h3 className="text-lg font-bold text-white mb-1">Create New Job Alert</h3>
            <p className="text-xs text-slate-400 mb-4">
              Get notified when new jobs match your chosen titles and skillsets.
            </p>

            <form onSubmit={handleCreateAlert} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Alert Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. MERN Full Stack Roles"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Keywords (comma-separated)
                </label>
                <input
                  type="text"
                  placeholder="Full Stack, Developer, Senior"
                  value={keywords}
                  onChange={(e) => setKeywords(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Required Skills (comma-separated)
                </label>
                <input
                  type="text"
                  placeholder="React, Node.js, MongoDB"
                  value={skills}
                  onChange={(e) => setSkills(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Preferred Location</label>
                  <input
                    type="text"
                    placeholder="Remote or City"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Employment Type</label>
                  <select
                    value={employmentType}
                    onChange={(e) => setEmploymentType(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Any">Any</option>
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                    <option value="Contract">Contract</option>
                    <option value="Internship">Internship</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium shadow transition disabled:opacity-50"
                >
                  {creating ? 'Saving...' : 'Save Job Alert'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
