import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { CandidateProfile, EducationItem } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  User,
  Mail,
  Phone,
  MapPin,
  GraduationCap,
  Briefcase,
  FileText,
  Globe,
  Linkedin,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
} from 'lucide-react';

export const CandidateProfileView: React.FC = () => {
  const { user, notify } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newSkill, setNewSkill] = useState('');

  const [formData, setFormData] = useState<Partial<CandidateProfile>>({
    fullName: user?.name || '',
    phone: '',
    location: '',
    skills: [],
    education: [],
    experienceYears: 0,
    experienceSummary: '',
    resumeSummary: '',
    resumeFileName: '',
    portfolioUrl: '',
    linkedinUrl: '',
  });

  const fetchProfile = async () => {
    setLoading(true);
    try {
      const res = await api.candidate.getProfile();
      if (res.success && res.data) {
        setFormData(res.data);
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSkill.trim()) return;
    const skill = newSkill.trim();
    if (!formData.skills?.includes(skill)) {
      setFormData((prev) => ({
        ...prev,
        skills: [...(prev.skills || []), skill],
      }));
    }
    setNewSkill('');
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills?.filter((s) => s !== skillToRemove) || [],
    }));
  };

  const handleAddEducation = () => {
    const newEdu: EducationItem = {
      degree: 'B.S. in Computer Science',
      institution: 'University',
      yearOfCompletion: 2024,
      fieldOfStudy: 'Software Engineering',
      grade: '3.8 GPA',
    };
    setFormData((prev) => ({
      ...prev,
      education: [...(prev.education || []), newEdu],
    }));
  };

  const handleRemoveEducation = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      education: prev.education?.filter((_, i) => i !== index),
    }));
  };

  const handleEduChange = (index: number, field: keyof EducationItem, value: any) => {
    setFormData((prev) => {
      const updated = [...(prev.education || [])];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, education: updated };
    });
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.candidate.updateProfile(formData);
      notify('success', 'Candidate profile updated successfully!');
    } catch (err: any) {
      notify('error', err.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="py-20 text-center text-slate-400 text-sm">Loading candidate profile...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Candidate Profile & Resume Data
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Maintain your professional qualifications, verified skills, academic degrees, and resume summary.
          </p>
        </div>
      </div>

      <form onSubmit={handleSaveProfile} className="space-y-6">
        {/* Personal & Contact Details */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-base font-semibold text-white mb-4 flex items-center gap-2">
            <User className="w-4 h-4 text-indigo-400" />
            Personal & Contact Information
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={formData.fullName || ''}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Email Address</label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full bg-slate-800/50 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-400 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Phone Number</label>
              <input
                type="text"
                required
                placeholder="+1 (555) 000-0000"
                value={formData.phone || ''}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Location / Residence</label>
              <input
                type="text"
                required
                placeholder="City, State (e.g. San Francisco, CA)"
                value={formData.location || ''}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Portfolio Website URL</label>
              <input
                type="url"
                placeholder="https://myportfolio.dev"
                value={formData.portfolioUrl || ''}
                onChange={(e) => setFormData({ ...formData, portfolioUrl: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">LinkedIn Profile URL</label>
              <input
                type="url"
                placeholder="https://linkedin.com/in/username"
                value={formData.linkedinUrl || ''}
                onChange={(e) => setFormData({ ...formData, linkedinUrl: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Technical Skills */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-base font-semibold text-white mb-2 flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-indigo-400" />
            Core Technical Skills & Stacks
          </h3>
          <p className="text-xs text-slate-400 mb-4">
            Add your primary programming languages, frameworks, databases, and development tools.
          </p>

          <div className="flex gap-2 mb-3">
            <input
              type="text"
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              placeholder="e.g. React, Docker, MongoDB, Node.js"
              className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddSkill(e);
                }
              }}
            />
            <button
              type="button"
              onClick={handleAddSkill}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-sm font-medium transition flex items-center gap-1"
            >
              <Plus className="w-4 h-4" />
              Add Skill
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            {formData.skills?.map((skill) => (
              <span
                key={skill}
                className="px-3 py-1 bg-indigo-950/70 border border-indigo-700/60 text-indigo-200 text-xs rounded-lg font-medium flex items-center gap-1.5"
              >
                {skill}
                <button
                  type="button"
                  onClick={() => handleRemoveSkill(skill)}
                  className="hover:text-rose-400 transition"
                >
                  &times;
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Professional Summary & Resume */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
          <h3 className="text-base font-semibold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-400" />
            Professional Experience & Resume Metadata
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Total Years of Industry Experience
              </label>
              <input
                type="number"
                min="0"
                max="50"
                value={formData.experienceYears || 0}
                onChange={(e) => setFormData({ ...formData, experienceYears: Number(e.target.value) })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Uploaded Resume Filename
              </label>
              <input
                type="text"
                placeholder="Alex_Rivera_Software_Engineer_CV.pdf"
                value={formData.resumeFileName || ''}
                onChange={(e) => setFormData({ ...formData, resumeFileName: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Work Experience Summary
            </label>
            <textarea
              rows={3}
              required
              value={formData.experienceSummary || ''}
              onChange={(e) => setFormData({ ...formData, experienceSummary: e.target.value })}
              placeholder="Outline your recent roles, responsibilities, architectural accomplishments..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Resume Executive Bio / Objective
            </label>
            <textarea
              rows={3}
              required
              value={formData.resumeSummary || ''}
              onChange={(e) => setFormData({ ...formData, resumeSummary: e.target.value })}
              placeholder="A concise 2-3 sentence overview highlighting your core strengths and career focus..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Education History */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-indigo-400" />
              Education & Degrees
            </h3>
            <button
              type="button"
              onClick={handleAddEducation}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Degree
            </button>
          </div>

          <div className="space-y-4">
            {formData.education?.map((edu, index) => (
              <div
                key={index}
                className="bg-slate-800/50 border border-slate-800 p-4 rounded-xl relative space-y-3"
              >
                <button
                  type="button"
                  onClick={() => handleRemoveEducation(index)}
                  className="absolute top-3 right-3 text-slate-400 hover:text-rose-400 transition"
                  title="Remove degree"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pr-8">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1">Degree</label>
                    <input
                      type="text"
                      value={edu.degree}
                      onChange={(e) => handleEduChange(index, 'degree', e.target.value)}
                      placeholder="e.g. B.S. in Computer Science"
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1">Institution</label>
                    <input
                      type="text"
                      value={edu.institution}
                      onChange={(e) => handleEduChange(index, 'institution', e.target.value)}
                      placeholder="e.g. University of California, Berkeley"
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1">Year of Completion</label>
                    <input
                      type="number"
                      value={edu.yearOfCompletion}
                      onChange={(e) => handleEduChange(index, 'yearOfCompletion', Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1">Grade / Honors</label>
                    <input
                      type="text"
                      value={edu.grade || ''}
                      onChange={(e) => handleEduChange(index, 'grade', e.target.value)}
                      placeholder="e.g. 3.8 GPA"
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Save button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold shadow-md flex items-center gap-2 transition disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Saving Profile...' : 'Save Profile Changes'}
          </button>
        </div>
      </form>
    </div>
  );
};
