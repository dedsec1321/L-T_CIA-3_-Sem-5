import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Company, JobPosting } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  Building2,
  Briefcase,
  ExternalLink,
  MapPin,
  DollarSign,
  Globe,
  Users,
} from 'lucide-react';

export const AdminPlatformOverviewView: React.FC = () => {
  const { notify } = useAuth();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [jobs, setJobs] = useState<JobPosting[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const [compRes, jobsRes] = await Promise.all([
        api.admin.getCompanies(),
        api.jobs.list({}),
      ]);
      if (compRes.success) setCompanies(compRes.data);
      if (jobsRes.success) setJobs(jobsRes.data);
    } catch (err: any) {
      notify('error', err.message || 'Failed to load directory');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading) {
    return <div className="py-20 text-center text-slate-400 text-sm">Loading system directory...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
          <Building2 className="w-6 h-6 text-indigo-400" />
          Platform Employers & Job Directory
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          System audit of registered corporate employers, active requisitions, and employer profiles.
        </p>
      </div>

      {/* Section 1: Companies */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
          <Building2 className="w-4 h-4 text-indigo-400" />
          Registered Corporate Employers ({companies.length})
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {companies.map((c) => (
            <div
              key={c._id}
              className="bg-slate-800/40 border border-slate-800 p-4 rounded-xl space-y-3"
            >
              <div className="flex items-center gap-3">
                {c.logoUrl ? (
                  <img
                    src={c.logoUrl}
                    alt={c.name}
                    className="w-10 h-10 rounded-lg object-cover border border-slate-700 shrink-0"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-lg bg-indigo-950 border border-indigo-800 flex items-center justify-center text-indigo-300 font-bold text-sm shrink-0">
                    {c.name.charAt(0)}
                  </div>
                )}
                <div>
                  <h4 className="text-sm font-bold text-white">{c.name}</h4>
                  <p className="text-[11px] text-slate-400">{c.industry}</p>
                </div>
              </div>

              <div className="text-xs text-slate-300 space-y-1">
                <div className="flex items-center gap-1.5 text-slate-400">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{c.location}</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Users className="w-3.5 h-3.5" />
                  <span>Size: {c.size || 'Startup'}</span>
                </div>
                {c.website && (
                  <div className="flex items-center gap-1.5 text-indigo-400 truncate">
                    <Globe className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{c.website}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Section 2: All Jobs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-indigo-400" />
          Active Portal Requisitions ({jobs.length})
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/80 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Position Title</th>
                <th className="py-3 px-4">Organization</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4">Compensation</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {jobs.map((j) => (
                <tr key={j._id} className="hover:bg-slate-800/40 transition">
                  <td className="py-3 px-4 font-bold text-white">{j.title}</td>
                  <td className="py-3 px-4">{j.companyId?.name}</td>
                  <td className="py-3 px-4 text-slate-400">{j.location}</td>
                  <td className="py-3 px-4 text-emerald-400 font-medium">
                    ${(j.salaryRange.min / 1000).toFixed(0)}k - ${(j.salaryRange.max / 1000).toFixed(0)}k
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {j.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
