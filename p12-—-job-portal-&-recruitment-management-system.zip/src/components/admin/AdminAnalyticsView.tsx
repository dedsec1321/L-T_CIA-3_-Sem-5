import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { AdminAnalyticsData } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  BarChart3,
  Users,
  Briefcase,
  Building2,
  FileText,
  TrendingUp,
  RefreshCw,
  CheckCircle2,
  Filter,
  Layers,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
} from 'recharts';

const STAGE_COLORS: Record<string, string> = {
  Applied: '#6366f1',
  Shortlisted: '#3b82f6',
  Interview: '#0ea5e9',
  Offered: '#eab308',
  Hired: '#10b981',
  Rejected: '#ef4444',
};

export const AdminAnalyticsView: React.FC = () => {
  const { notify } = useAuth();
  const [data, setData] = useState<AdminAnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [resetting, setResetting] = useState(false);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const res = await api.admin.getAnalytics();
      if (res.success) {
        setData(res.data);
      }
    } catch (err: any) {
      notify('error', err.message || 'Failed to load system analytics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const handleResetDatabase = async () => {
    if (
      !window.confirm(
        'Execute database reset? This will restore clean CIA-3 academic seed accounts, test jobs, candidate profiles, and pipeline stages.'
      )
    )
      return;

    setResetting(true);
    try {
      const res = await api.admin.resetDatabase();
      notify('success', res.message);
      fetchAnalytics();
    } catch (err: any) {
      notify('error', err.message || 'Failed to reset database');
    } finally {
      setResetting(false);
    }
  };

  if (loading) {
    return <div className="py-20 text-center text-slate-400 text-sm">Loading platform analytics...</div>;
  }

  if (!data) return null;

  // Prepare Pie Chart data for user roles
  const userRoleData = [
    { name: 'Candidates', value: data.users.candidates, fill: '#10b981' },
    { name: 'Recruiters', value: data.users.recruiters, fill: '#3b82f6' },
    { name: 'Admins', value: data.users.admins, fill: '#8b5cf6' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-indigo-400" />
            Platform Analytics & Recruitment Funnel
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            System-wide telemetry, user breakdown, and recruitment conversion funnel.
          </p>
        </div>

        <button
          onClick={handleResetDatabase}
          disabled={resetting}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-2 transition disabled:opacity-50 self-start sm:self-auto"
        >
          <RefreshCw className={`w-4 h-4 ${resetting ? 'animate-spin text-indigo-400' : ''}`} />
          <span>{resetting ? 'Re-seeding MongoDB...' : 'Reset Demo Seed Data'}</span>
        </button>
      </div>

      {/* Top Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Users</span>
            <Users className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-3xl font-bold text-white">{data.users.total}</div>
          <div className="text-xs text-slate-400 mt-1">
            {data.users.candidates} Candidates &bull; {data.users.recruiters} Recruiters
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Organizations</span>
            <Building2 className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-3xl font-bold text-white">{data.companies.total}</div>
          <div className="text-xs text-blue-400 mt-1">Verified employer accounts</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Job Postings</span>
            <Briefcase className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-3xl font-bold text-white">{data.jobs.total}</div>
          <div className="text-xs text-emerald-400 mt-1">
            {data.jobs.published} Live &bull; {data.jobs.draft} Drafts
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Applications</span>
            <FileText className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-bold text-white">{data.applications.total}</div>
          <div className="text-xs text-emerald-400 mt-1">
            {data.applications.hires || 0} Successful Hires
          </div>
        </div>
      </div>

      {/* Recruitment Funnel Visualization (MANDATORY REQUIREMENT) */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-indigo-400" />
              Recruitment Conversion Funnel (Real Pipeline Progression)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Calculated dynamically from MongoDB applications tracking candidates from Applied to Hired.
            </p>
          </div>
        </div>

        <div className="space-y-4 py-3">
          {data.funnel.map((step) => {
            return (
              <div key={step.step} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white w-24">{step.step}</span>
                    <span className="text-slate-400">({step.count} candidates)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-400 text-[11px]">
                      Percentage of pool: <span className="font-semibold text-white">{step.percentageOfTotal}%</span>
                    </span>
                    <span className="text-indigo-400 text-[11px]">
                      Step Conversion: {step.conversionFromPrevious}%
                    </span>
                  </div>
                </div>

                <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden border border-slate-700/60">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.max(step.percentageOfTotal, 4)}%`,
                      backgroundColor: STAGE_COLORS[step.step] || '#6366f1',
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Visual Charts Grid: Stage Distribution & User Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Stage Bar Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-base font-bold text-white mb-2">Stage Volume Distribution</h3>
          <p className="text-xs text-slate-400 mb-4">Total candidate records across each workflow status.</p>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={Object.entries(data.applications.byStage).map(([stage, count]) => ({ stage, count }))}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <XAxis dataKey="stage" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#f8fafc',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {Object.entries(data.applications.byStage).map(([stage], index) => (
                    <Cell key={`cell-${index}`} fill={STAGE_COLORS[stage] || '#6366f1'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* User Breakdown Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-base font-bold text-white mb-2">Platform Role Demographics</h3>
          <p className="text-xs text-slate-400 mb-4">Distribution of registered RBAC accounts.</p>

          <div className="h-60 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={userRoleData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {userRoleData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#f8fafc',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
