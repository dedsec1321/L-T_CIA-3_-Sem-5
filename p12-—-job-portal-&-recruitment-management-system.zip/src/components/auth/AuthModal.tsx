import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';
import { X, Lock, Mail, User, ShieldCheck, Briefcase, GraduationCap } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register';
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, initialMode = 'login' }) => {
  const { login, register, quickLogin, notify } = useAuth();
  const [isLogin, setIsLogin] = useState(initialMode === 'login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>('Candidate');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isLogin) {
        await login(email, password);
      } else {
        await register(name, email, password, role);
      }
      onClose();
    } catch (err: any) {
      notify('error', err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const handleQuick = async (targetRole: 'Admin' | 'Recruiter' | 'Candidate') => {
    setLoading(true);
    try {
      await quickLogin(targetRole);
      onClose();
    } catch (err: any) {
      notify('error', err.message || 'Quick login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative text-slate-100 animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition p-1.5 rounded-lg hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Academic CIA-3 Notice Badge */}
        <div className="flex items-center gap-2 mb-4 bg-indigo-950/60 border border-indigo-700/40 px-3 py-1.5 rounded-lg text-xs text-indigo-300 font-medium">
          <ShieldCheck className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>CIA-3 Project Authentication &bull; MongoDB Atlas &bull; Real JWT &bull; RBAC</span>
        </div>

        <h2 className="text-2xl font-bold tracking-tight text-white mb-1">
          {isLogin ? 'Sign In to Your Account' : 'Create New Account'}
        </h2>
        <p className="text-slate-400 text-sm mb-6">
          {isLogin
            ? 'Enter your credentials to access the recruitment portal'
            : 'Register as a Candidate or Recruiter with verified role permissions'}
        </p>

        {/* Faculty / Evaluator 1-Click Fast Switch Section */}
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 mb-6">
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
            Faculty Evaluation Quick Sign-In:
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => handleQuick('Admin')}
              className="flex flex-col items-center justify-center py-2.5 px-2 bg-purple-900/30 hover:bg-purple-900/60 border border-purple-700/40 rounded-lg text-purple-200 text-xs font-medium transition text-center"
            >
              <ShieldCheck className="w-4 h-4 mb-1 text-purple-400" />
              <span className="font-semibold">Admin</span>
              <span className="text-[10px] text-purple-300/70">Dr. Vance</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuick('Recruiter')}
              className="flex flex-col items-center justify-center py-2.5 px-2 bg-blue-900/30 hover:bg-blue-900/60 border border-blue-700/40 rounded-lg text-blue-200 text-xs font-medium transition text-center"
            >
              <Briefcase className="w-4 h-4 mb-1 text-blue-400" />
              <span className="font-semibold">Recruiter</span>
              <span className="text-[10px] text-blue-300/70">Sarah (Nexus)</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuick('Candidate')}
              className="flex flex-col items-center justify-center py-2.5 px-2 bg-emerald-900/30 hover:bg-emerald-900/60 border border-emerald-700/40 rounded-lg text-emerald-200 text-xs font-medium transition text-center"
            >
              <GraduationCap className="w-4 h-4 mb-1 text-emerald-400" />
              <span className="font-semibold">Candidate</span>
              <span className="text-[10px] text-emerald-300/70">Alex Rivera</span>
            </button>
          </div>
        </div>

        <div className="relative flex py-2 items-center mb-4">
          <div className="flex-grow border-t border-slate-800"></div>
          <span className="flex-shrink mx-3 text-xs text-slate-500 uppercase tracking-wider">
            Or Use Custom Credentials
          </span>
          <div className="flex-grow border-t border-slate-800"></div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Eleanor Vance"
                    className="w-full bg-slate-800/80 border border-slate-700 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Account Role</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('Candidate')}
                    className={`py-2 px-3 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 transition ${
                      role === 'Candidate'
                        ? 'bg-indigo-600 border-indigo-500 text-white'
                        : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <GraduationCap className="w-4 h-4" />
                    Candidate
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('Recruiter')}
                    className={`py-2 px-3 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 transition ${
                      role === 'Recruiter'
                        ? 'bg-indigo-600 border-indigo-500 text-white'
                        : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <Briefcase className="w-4 h-4" />
                    Recruiter
                  </button>
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-slate-800/80 border border-slate-700 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;"
                className="w-full bg-slate-800/80 border border-slate-700 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm rounded-lg shadow transition disabled:opacity-50 mt-2"
          >
            {loading ? 'Processing...' : isLogin ? 'Sign In' : 'Register Account'}
          </button>
        </form>

        <div className="mt-5 text-center text-xs text-slate-400">
          {isLogin ? "Don't have an account? " : 'Already have an account? '}
          <button
            type="button"
            onClick={() => setIsLogin(!isLogin)}
            className="text-indigo-400 hover:text-indigo-300 font-semibold underline ml-1"
          >
            {isLogin ? 'Register now' : 'Sign in here'}
          </button>
        </div>
      </div>
    </div>
  );
};
