import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Briefcase,
  UserCheck,
  ShieldAlert,
  LogOut,
  LogIn,
  RefreshCw,
  Bell,
  Award,
  Layers,
  Calendar,
  Building2,
  Users,
  BarChart3,
  Search,
  FileText,
  User as UserIcon,
} from 'lucide-react';
import { api } from '../services/api';

interface NavbarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenAuth: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, onSelectTab, onOpenAuth }) => {
  const { user, role, isAuthenticated, logout, quickLogin, notify } = useAuth();
  const [resetting, setResetting] = React.useState(false);

  const handleResetDatabase = async () => {
    if (!window.confirm('Reset database to clean CIA-3 academic seed dataset?')) return;
    setResetting(true);
    try {
      await api.admin.resetDatabase();
      notify('success', 'Database re-seeded with demo records successfully');
      window.location.reload();
    } catch (err: any) {
      notify('error', err.message || 'Failed to re-seed database');
    } finally {
      setResetting(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur border-b border-slate-800 text-slate-100 shadow-md">
      {/* Top Academic Banner */}
      <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 px-4 py-1.5 border-b border-slate-800/80 text-xs flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-slate-300">
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            CIA-3 Project P12
          </span>
          <span className="hidden sm:inline font-medium text-slate-300">
            HR Tech &bull; Job Portal & Recruitment Management System
          </span>
        </div>

        {/* Quick Role Switcher for Evaluator */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 hidden md:inline text-[11px] font-medium">1-Click Role Switch:</span>
          <button
            onClick={() => quickLogin('Candidate')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition border ${
              role === 'Candidate'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
            }`}
          >
            Candidate (Alex)
          </button>
          <button
            onClick={() => quickLogin('Recruiter')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition border ${
              role === 'Recruiter'
                ? 'bg-blue-500/20 text-blue-300 border-blue-500/40 shadow-sm'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
            }`}
          >
            Recruiter (Sarah)
          </button>
          <button
            onClick={() => quickLogin('Admin')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition border ${
              role === 'Admin'
                ? 'bg-purple-500/20 text-purple-300 border-purple-500/40 shadow-sm'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
            }`}
          >
            Admin (Dr. Vance)
          </button>

          <button
            onClick={handleResetDatabase}
            disabled={resetting}
            title="Reset to clean demo data"
            className="ml-2 px-2 py-0.5 rounded text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center gap-1 transition"
          >
            <RefreshCw className={`w-3 h-3 ${resetting ? 'animate-spin' : ''}`} />
            <span className="hidden lg:inline">Reset Seed</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3 cursor-pointer shrink-0" onClick={() => onSelectTab(role === 'Recruiter' ? 'recruiter-dashboard' : role === 'Admin' ? 'admin-analytics' : 'candidate-jobs')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center shadow-lg shadow-indigo-600/20">
              <Briefcase className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold text-base tracking-tight text-white flex items-center gap-2">
                JobPulse
                <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                  MERN / RBAC
                </span>
              </div>
              <div className="text-xs text-slate-400 font-normal">Recruitment & ATS Platform</div>
            </div>
          </div>

          {/* Navigation Links based on Current Role */}
          <nav className="hidden md:flex items-center gap-1 overflow-x-auto py-1">
            {/* Candidate Navigation */}
            {role === 'Candidate' && (
              <>
                <button
                  onClick={() => onSelectTab('candidate-jobs')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'candidate-jobs'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Search className="w-4 h-4" />
                  Browse Jobs
                </button>
                <button
                  onClick={() => onSelectTab('candidate-apps')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'candidate-apps'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  My Applications
                </button>
                <button
                  onClick={() => onSelectTab('candidate-offers')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'candidate-offers'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Award className="w-4 h-4" />
                  Offers & Interviews
                </button>
                <button
                  onClick={() => onSelectTab('candidate-alerts')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'candidate-alerts'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Bell className="w-4 h-4" />
                  Saved & Alerts
                </button>
                <button
                  onClick={() => onSelectTab('candidate-profile')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'candidate-profile'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <UserIcon className="w-4 h-4" />
                  My Profile
                </button>
              </>
            )}

            {/* Recruiter Navigation */}
            {role === 'Recruiter' && (
              <>
                <button
                  onClick={() => onSelectTab('recruiter-dashboard')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'recruiter-dashboard'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  Dashboard
                </button>
                <button
                  onClick={() => onSelectTab('recruiter-pipeline')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'recruiter-pipeline'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Layers className="w-4 h-4" />
                  Applicant Pipeline
                </button>
                <button
                  onClick={() => onSelectTab('recruiter-jobs')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'recruiter-jobs'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Briefcase className="w-4 h-4" />
                  Manage Jobs
                </button>
                <button
                  onClick={() => onSelectTab('recruiter-interviews')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'recruiter-interviews'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Calendar className="w-4 h-4" />
                  Interviews
                </button>
                <button
                  onClick={() => onSelectTab('recruiter-offers')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'recruiter-offers'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Award className="w-4 h-4" />
                  Offers
                </button>
                <button
                  onClick={() => onSelectTab('recruiter-company')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'recruiter-company'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Building2 className="w-4 h-4" />
                  Company
                </button>
              </>
            )}

            {/* Admin Navigation */}
            {role === 'Admin' && (
              <>
                <button
                  onClick={() => onSelectTab('admin-analytics')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'admin-analytics'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  Platform Analytics & Funnel
                </button>
                <button
                  onClick={() => onSelectTab('admin-users')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'admin-users'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  User RBAC Management
                </button>
                <button
                  onClick={() => onSelectTab('admin-directory')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition ${
                    currentTab === 'admin-directory'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Building2 className="w-4 h-4" />
                  Jobs & Companies
                </button>
              </>
            )}
          </nav>

          {/* User Status / Auth Buttons */}
          <div className="flex items-center gap-3 shrink-0">
            {isAuthenticated && user ? (
              <div className="flex items-center gap-3">
                <div className="hidden sm:block text-right">
                  <div className="text-xs font-semibold text-white leading-tight">{user.name}</div>
                  <div className="text-[11px] text-slate-400 flex items-center justify-end gap-1">
                    <span
                      className={`inline-block w-1.5 h-1.5 rounded-full ${
                        role === 'Admin'
                          ? 'bg-purple-400'
                          : role === 'Recruiter'
                          ? 'bg-blue-400'
                          : 'bg-emerald-400'
                      }`}
                    ></span>
                    {user.role}
                  </div>
                </div>

                <button
                  onClick={logout}
                  title="Sign Out"
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="py-2 px-4 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg shadow flex items-center gap-2 transition"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Nav Bar */}
      <div className="md:hidden border-t border-slate-800 px-4 py-2 flex items-center gap-2 overflow-x-auto bg-slate-900">
        {role === 'Candidate' && (
          <>
            <button
              onClick={() => onSelectTab('candidate-jobs')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'candidate-jobs' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Browse
            </button>
            <button
              onClick={() => onSelectTab('candidate-apps')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'candidate-apps' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Applications
            </button>
            <button
              onClick={() => onSelectTab('candidate-offers')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'candidate-offers' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Offers
            </button>
            <button
              onClick={() => onSelectTab('candidate-alerts')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'candidate-alerts' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Alerts
            </button>
            <button
              onClick={() => onSelectTab('candidate-profile')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'candidate-profile' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Profile
            </button>
          </>
        )}

        {role === 'Recruiter' && (
          <>
            <button
              onClick={() => onSelectTab('recruiter-dashboard')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'recruiter-dashboard' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => onSelectTab('recruiter-pipeline')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'recruiter-pipeline' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Pipeline
            </button>
            <button
              onClick={() => onSelectTab('recruiter-jobs')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'recruiter-jobs' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Jobs
            </button>
            <button
              onClick={() => onSelectTab('recruiter-interviews')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'recruiter-interviews' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Interviews
            </button>
            <button
              onClick={() => onSelectTab('recruiter-offers')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'recruiter-offers' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Offers
            </button>
            <button
              onClick={() => onSelectTab('recruiter-company')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'recruiter-company' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Company
            </button>
          </>
        )}

        {role === 'Admin' && (
          <>
            <button
              onClick={() => onSelectTab('admin-analytics')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'admin-analytics' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Analytics & Funnel
            </button>
            <button
              onClick={() => onSelectTab('admin-users')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'admin-users' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Users & RBAC
            </button>
            <button
              onClick={() => onSelectTab('admin-directory')}
              className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
                currentTab === 'admin-directory' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Directory
            </button>
          </>
        )}
      </div>
    </header>
  );
};
